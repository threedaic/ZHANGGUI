import{a1 as a}from"./index-D04-DSrf.js";const n={chat(t){return a.post("/ai/chat",t)},getConfig(){return a.get("/ai/config")},updateConfig(t){return a.put("/ai/config",t)}};export{n as a};
