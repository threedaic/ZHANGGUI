import{a1 as a}from"./index-D04-DSrf.js";const o={getDashboard(){return a.get("/dashboard")}};export{o as d};
