from fastapi import Request
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy import text
from app.config import get_settings

settings = get_settings()

engine = create_async_engine(
    settings.DATABASE_URL,
    echo=settings.DEBUG,
    pool_size=10,
    max_overflow=0,
    pool_pre_ping=True,
    pool_recycle=3600,
    connect_args={"ssl": False},
)

AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


async def set_session_context(
    session: AsyncSession,
    store_id: int | None = None,
    user_id: int | None = None,
    role: str | None = None,
) -> None:
    """Set PostgreSQL session variables for Row-Level Security.

    Called on every session checkout so that PG RLS policies can use
    current_setting('app.current_store_id') etc.
    """
    # NOTE: PG SET does not support parameterised placeholders ($1).
    # Values are already sanitised: store_id/user_id cast through int(),
    # role filtered to alphanumeric only.
    if store_id is not None:
        await session.execute(text(f"SET app.current_store_id = '{int(store_id)}'"))
    else:
        await session.execute(text("SET app.current_store_id = '0'"))

    if user_id is not None:
        await session.execute(text(f"SET app.current_user_id = '{int(user_id)}'"))
    else:
        await session.execute(text("SET app.current_user_id = '0'"))

    if role is not None:
        safe_role = "".join(c for c in role if c.isalnum() or c == "_")
        await session.execute(text(f"SET app.role = '{safe_role}'"))
    else:
        await session.execute(text("SET app.role = ''"))


async def get_db(request: Request = None) -> AsyncSession:
    """Yield a database session with RLS context set from request.

    If a Request is available (normal API call), reads store_id/user_id/role
    from request.state (set by RLSMiddleware) and sets PG session variables
    so that Row-Level Security policies can filter rows automatically.
    """
    async with AsyncSessionLocal() as session:
        # Set PG session context for RLS if request is available
        if request is not None:
            store_id = getattr(request.state, "store_id", None)
            user_id = getattr(request.state, "user_id", None)
            role = getattr(request.state, "role", None)
            await set_session_context(session, store_id, user_id, role)
        # async with context manager auto-closes on exit; no explicit close needed
        yield session
