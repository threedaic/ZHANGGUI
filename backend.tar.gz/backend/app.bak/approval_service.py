"""
统一审批 Service
- 请假、补卡、调班、加班、报销
- 审批通过后联动排班/考勤/工资
"""
from datetime import date, datetime
from typing import Any
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.approval import ApprovalRequest
from app.models.attendance import AttendanceRecord
from app.repositories.approval import ApprovalRepository
from app.repositories.attendance import AttendanceRepository
from app.utils.exceptions import NotFoundError, ForbiddenError, ValidationError
from app.services.attendance_push import push_approval_notification


class ApprovalService:
    """审批 Service"""

    def __init__(self, session: AsyncSession, store_id: int):
        self.session = session
        self.store_id = store_id
        self.repo = ApprovalRepository(session, store_id)
        self.attendance_repo = AttendanceRepository(session, store_id)

    async def create_approval(
        self,
        employee_id: int,
        approval_type: str,
        start_date: date | None,
        end_date: date | None,
        reason: str,
        extra: dict[str, Any] | None = None,
    ) -> ApprovalRequest:
        if approval_type not in ("leave", "makeup", "swap", "overtime", "expense"):
            raise ValidationError(f"不支持的审批类型: {approval_type}")

        approval = ApprovalRequest(
            store_id=self.store_id,
            employee_id=employee_id,
            type=approval_type,
            status="pending",
            start_date=start_date,
            end_date=end_date,
            reason=reason,
            extra=extra or {},
        )
        result = await self.repo.create_approval(approval)

        # 通知审批人
        try:
            TYPE_LABELS = {"leave": "请假", "makeup": "补卡", "swap": "调班", "overtime": "加班", "expense": "报销"}
            type_label = TYPE_LABELS.get(approval_type, approval_type)
            await push_approval_notification(
                self.session, self.store_id, "approval",
                f"新的{type_label}审批",
                f"员工申请{type_label}，点击查看详情",
            )
        except Exception:
            pass

        return result

    async def approve(self, approval_id: int, approver_id: int) -> ApprovalRequest:
        approval = await self.repo.get_approval_by_id(approval_id)
        if not approval:
            raise NotFoundError("审批记录不存在")

        approval = await self.repo.update_approval(
            approval,
            status="approved",
            approver_id=approver_id,
            approved_at=datetime.now(),
        )

        # 联动处理
        await self._apply_approval(approval)

        # 通知提交人
        try:
            TYPE_LABELS = {"leave": "请假", "makeup": "补卡", "swap": "调班", "overtime": "加班", "expense": "报销"}
            type_label = TYPE_LABELS.get(approval.type, approval.type)
            user_ids = await self._resolve_user_ids(approval.employee_id)
            if user_ids:
                await push_approval_notification(
                    self.session, self.store_id, "approval",
                    f"{type_label}审批已通过",
                    f"您的{type_label}申请已通过",
                    target_user_ids=user_ids,
                )
        except Exception:
            pass

        return approval

    async def reject(self, approval_id: int, approver_id: int, reject_reason: str | None = None) -> ApprovalRequest:
        approval = await self.repo.get_approval_by_id(approval_id)
        if not approval:
            raise NotFoundError("审批记录不存在")

        approval = await self.repo.update_approval(
            approval,
            status="rejected",
            approver_id=approver_id,
            approved_at=datetime.now(),
            reject_reason=reject_reason,
        )

        # 通知提交人
        try:
            TYPE_LABELS = {"leave": "请假", "makeup": "补卡", "swap": "调班", "overtime": "加班", "expense": "报销"}
            type_label = TYPE_LABELS.get(approval.type, approval.type)
            user_ids = await self._resolve_user_ids(approval.employee_id)
            content = f"您的{type_label}申请已被驳回"
            if reject_reason:
                content += f"，原因：{reject_reason}"
            if user_ids:
                await push_approval_notification(
                    self.session, self.store_id, "approval",
                    f"{type_label}审批已驳回",
                    content,
                    target_user_ids=user_ids,
                )
        except Exception:
            pass

        return approval

    async def _resolve_user_ids(self, employee_id: int) -> list[int]:
        from sqlalchemy import select as sa_select, and_
        from app.models.user import User
        stmt = sa_select(User.id).where(
            and_(User.employee_id == employee_id, User.is_active.is_(True))
        )
        result = await self.session.execute(stmt)
        return [row[0] for row in result.all()]

    async def _apply_approval(self, approval: ApprovalRequest) -> None:
        """审批通过后联动业务数据"""
        if approval.type == "leave" and approval.start_date and approval.end_date:
            current = approval.start_date
            while current <= approval.end_date:
                existing = await self.attendance_repo.get_record_by_employee_date(
                    approval.employee_id, current
                )
                if existing:
                    existing.scheduled_shift = "请假"
                    existing.status = "leave"
                else:
                    record = AttendanceRecord(
                        store_id=self.store_id,
                        employee_id=approval.employee_id,
                        date=current,
                        scheduled_shift="请假",
                        status="leave",
                        source="manual",
                    )
                    self.session.add(record)
                current += date.resolution

            # 扣减假期余额
            try:
                from app.repositories.leave_balance import LeaveBalanceRepository
                lb_repo = LeaveBalanceRepository(self.session, self.store_id)
                leave_type_bal = approval.extra.get("leave_type", "annual") if approval.extra else "annual"
                leave_days = ((approval.end_date - approval.start_date).days) + 1
                await lb_repo.deduct_leave(approval.employee_id, approval.start_date.year, leave_type_bal, float(leave_days))
            except Exception:
                pass

        elif approval.type == "makeup" and approval.extra:
            target_date = approval.extra.get("date")
            clock_in = approval.extra.get("clock_in")
            clock_out = approval.extra.get("clock_out")
            if target_date:
                # 校验日期格式
                try:
                    if isinstance(target_date, str):
                        target_date = date.fromisoformat(target_date)
                    elif not isinstance(target_date, date):
                        raise ValueError
                except (ValueError, TypeError):
                    raise ValidationError(f"补签日期格式无效: {target_date}")
                existing = await self.attendance_repo.get_record_by_employee_date(
                    approval.employee_id, target_date
                )
                if existing:
                    if clock_in:
                        existing.clock_in = clock_in
                    if clock_out:
                        existing.clock_out = clock_out
                    existing.source = "makeup"
                else:
                    record = AttendanceRecord(
                        store_id=self.store_id,
                        employee_id=approval.employee_id,
                        date=target_date,
                        clock_in=clock_in,
                        clock_out=clock_out,
                        source="makeup",
                        status="unknown",
                    )
                    self.session.add(record)

        elif approval.type == "swap" and approval.extra:
            # 调班：交换双方某天的排班
            from_employee_id = approval.employee_id
            to_employee_id = approval.extra.get("to_employee_id")
            swap_date = approval.extra.get("date")
            if from_employee_id and to_employee_id and swap_date:
                from_record = await self.attendance_repo.get_record_by_employee_date(
                    from_employee_id, swap_date
                )
                to_record = await self.attendance_repo.get_record_by_employee_date(
                    to_employee_id, swap_date
                )
                from_shift = from_record.scheduled_shift if from_record else "休息"
                to_shift = to_record.scheduled_shift if to_record else "休息"

                if from_record:
                    from_record.scheduled_shift = to_shift
                else:
                    self.session.add(AttendanceRecord(
                        store_id=self.store_id,
                        employee_id=from_employee_id,
                        date=swap_date,
                        scheduled_shift=to_shift,
                        status="unknown",
                    ))

                if to_record:
                    to_record.scheduled_shift = from_shift
                else:
                    self.session.add(AttendanceRecord(
                        store_id=self.store_id,
                        employee_id=to_employee_id,
                        date=swap_date,
                        scheduled_shift=from_shift,
                        status="unknown",
                    ))

        elif approval.type == "overtime" and approval.extra:
            # 加班记录，工资模块读取 extra 中的时长和倍数
            pass

        await self.session.flush()
