"""Shared FastAPI dependency functions.

Provides reusable dependency callables for store/role/employee extraction
from JWT-authenticated request context.  All router modules should import
these from here instead of defining their own copies.
"""

import uuid
from fastapi import Request

from app.utils.exceptions import UnauthorizedError, ForbiddenError


def make_response(code: int = 0, message: str = "ok", data=None, request: Request | None = None) -> dict:
    """Standardized API response dict with optional request_id (m-009 fix).

    Usage:
        return make_response(data=result)
        return make_response(message="创建成功", data=item)
    """
    request_id = getattr(request.state, "request_id", None) if request else None
    return {
        "code": code,
        "message": message,
        "data": data,
        "request_id": request_id,
    }


def get_user_id(request: Request) -> int:
    """Extract the current user ID from request context.

    Raises 403 (ForbiddenError) when no user identity is bound.
    Moved from attendance.py per m-010 fix.
    """
    user_id = getattr(request.state, "user_id", None)
    if user_id is None:
        raise ForbiddenError("无法获取用户信息")
    return user_id


def get_store_id(request: Request) -> int:
    """Extract the current store ID from JWT-decoded request context.

    Raises 401 (UnauthorizedError) when no store_id is present, which
    means the caller is not authenticated or the token has expired.
    """
    store_id = getattr(request.state, "store_id", None)
    if store_id is None:
        raise UnauthorizedError("未登录或Token已过期，请重新登录")
    return store_id


def require_role(request: Request, allowed: list[str]) -> None:
    """Check that the current user's role is in *allowed*.

    Raises 403 (ForbiddenError) when the role is not permitted.
    """
    role = getattr(request.state, "role", None)
    if role not in allowed:
        raise ForbiddenError("无权执行此操作")


def get_employee_id(request: Request) -> int:
    """Extract the current employee ID from request context.

    Raises 403 (ForbiddenError) when no employee identity is bound.
    """
    employee_id = getattr(request.state, "employee_id", None)
    if not employee_id:
        raise ForbiddenError("需要绑定员工身份")
    return employee_id


# Alias for backward compatibility (used by kpi.py, payroll.py)
require_employee_id = get_employee_id
