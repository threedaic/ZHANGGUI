"""
统一消息通知 Service
- 站内信
- 企微应用消息
"""
from typing import Any
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from app.models.notification import Notification, NotificationSetting
from app.repositories.notification import NotificationRepository
from app.models.user import User
from app.models.employee import Employee
from app.services.wework import get_access_token
from app.utils.http_client import http_client
from app.utils.redis_client import get_redis


WECOM_API = "https://qyapi.weixin.qq.com/cgi-bin"


class NotificationService:
    """通知 Service"""

    def __init__(self, session: AsyncSession, store_id: int):
        self.session = session
        self.store_id = store_id
        self.repo = NotificationRepository(session, store_id)

    async def send(
        self,
        notification_type: str,
        title: str,
        content: str,
        target_user_ids: list[int] | None = None,
        channel: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> list[Notification]:
        """发送通知

        target_user_ids: 指定接收用户，None 表示按 setting 中 target_roles 发送
        channel: 强制渠道，None 则读取 setting
        """
        setting = await self.repo.get_setting_by_key(notification_type)
        if setting and not setting.enabled:
            return []

        if channel is None:
            channel = setting.channel if setting else "in_app"

        if target_user_ids is None:
            target_roles = setting.target_roles if setting else ["boss", "store_manager"]
            target_user_ids = await self._resolve_user_ids_by_roles(target_roles)

        notifications = []
        for user_id in target_user_ids:
            notification = Notification(
                store_id=self.store_id,
                user_id=user_id,
                type=notification_type,
                title=title,
                content=content,
                channel=channel,
                extra=extra,
            )
            notifications.append(await self.repo.create_notification(notification))

        # 企微推送
        if channel in ("wecom", "all"):
            await self._push_wecom_to_users(target_user_ids, title, content)

        return notifications

    async def _resolve_user_ids_by_roles(self, roles: list[str]) -> list[int]:
        """根据角色解析用户 ID 列表"""
        from sqlalchemy import select, and_
        stmt = select(User).join(Employee, User.employee_id == Employee.id).where(
            and_(
                Employee.store_id == self.store_id,
                User.role.in_(roles),
                User.is_active.is_(True),
            )
        )
        result = await self.session.execute(stmt)
        return [u.id for u in result.scalars().all()]

    async def _push_wecom_to_users(
        self,
        user_ids: list[int],
        title: str,
        content: str,
    ) -> None:
        """通过企微应用消息推送给指定用户"""
        try:
            from sqlalchemy import select, and_
            stmt = select(User).join(Employee, User.employee_id == Employee.id).where(
                and_(
                    User.id.in_(user_ids),
                    Employee.store_id == self.store_id,
                )
            )
            result = await self.session.execute(stmt)
            users = result.scalars().all()

            # 收集有 employee 关联的 wework_userid
            emp_stmt = select(Employee).join(User, User.employee_id == Employee.id).where(
                and_(
                    Employee.store_id == self.store_id,
                    User.id.in_(user_ids),
                    Employee.wework_userid.isnot(None),
                )
            )
            emp_result = await self.session.execute(emp_stmt)
            userids = [e.wework_userid for e in emp_result.scalars().all()]

            if not userids:
                return

            token = await get_access_token(self.session, self.store_id)
            url = f"{WECOM_API}/message/send?access_token={token}"
            body = {
                "touser": "|".join(userids),
                "msgtype": "textcard",
                "agentid": await self._get_agent_id(),
                "textcard": {
                    "title": title,
                    "description": content,
                    "url": "https://zhanggui.crushserver.cloud/notifications",
                },
            }
            resp = await http_client.post(url, json_body=body)
            data = resp.json()
            if data.get("errcode") != 0:
                logger.error(f"企微消息推送失败: {data}")
        except Exception as e:
            logger.error(f"企微推送异常: {e}")

    async def _get_agent_id(self) -> int:
        from sqlalchemy import select
        from app.models.store import Store
        stmt = select(Store).where(Store.id == self.store_id)
        result = await self.session.execute(stmt)
        store = result.scalar_one_or_none()
        return store.wework_agent_id if store and store.wework_agent_id else 0

    async def get_settings(self) -> list[NotificationSetting]:
        return await self.repo.get_settings()

    async def save_setting(self, data: dict[str, Any]) -> NotificationSetting:
        setting_key = data["setting_key"]
        existing = await self.repo.get_setting_by_key(setting_key)
        if existing:
            for key in ["enabled", "channel", "target_roles", "schedule_time"]:
                if key in data:
                    setattr(existing, key, data[key])
            await self.session.flush()
            await self.session.refresh(existing)
            return existing

        new_setting = NotificationSetting(store_id=self.store_id, **data)
        return await self.repo.save_setting(new_setting)
