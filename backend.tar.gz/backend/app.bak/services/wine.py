"""
存酒管理业务逻辑层
- 瓶身码生成
- 存酒 + 云打印机出标签 + 短信通知
- 服务员取酒（分批）
- 客人自助取酒 + 云打印机出小票
"""
import secrets
from datetime import date, datetime
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger
from app.models.wine_storage import WineStorage
from app.repositories.wine import WineRepository
from app.utils.http_client import http_client
from app.utils.exceptions import NotFoundError, ConflictError, ValidationError
from app.services.cloud_printer import print_label, print_retrieve_receipt

SMS_API_URL = "https://api.example.com/sms/send"


def generate_bottle_label(store_id: int) -> str:
    suffix = secrets.randbelow(10000)
    return f"C{store_id:03d}-{suffix:04d}"


async def generate_unique_label(repo: WineRepository) -> str:
    for _ in range(100):
        label = generate_bottle_label(repo.store_id)
        existing = await repo.get_by_bottle_label(label)
        if not existing:
            return label
    ts = int(datetime.now().timestamp() * 1000) % 100000
    return f"C{repo.store_id:03d}-{ts:05d}"


# ==================== 存酒 ====================

async def store_wine(
    session: AsyncSession,
    store_id: int,
    customer_name: str,
    phone: str,
    wine_name: str,
    remaining_ml: int,
    quantity: int = 1,
    cabinet_no: str | None = None,
    notes: str | None = None,
) -> WineStorage:
    """存酒：生成瓶身码 → 自动分配柜号 → 入库（支持多瓶） → 云打印标签 → 短信通知"""
    repo = WineRepository(session, store_id)
    last_wine = None

    for _ in range(max(quantity, 1)):
        bottle_label = await generate_unique_label(repo)

        if not cabinet_no:
            cabinet_no = await repo.next_cabinet_no()

        wine = WineStorage(
            store_id=store_id,
            customer_name=customer_name,
            phone=phone,
            wine_name=wine_name,
            bottle_label=bottle_label,
            date_stored=date.today().isoformat(),
            initial_ml=remaining_ml,
            remaining_ml=remaining_ml,
            cabinet_no=cabinet_no,
            status="stored",
            notes=notes,
        )
        await repo.create(wine)
        last_wine = wine

        # 每瓶异步出标签
        from asyncio import create_task
        create_task(_safe_print_label(bottle_label, customer_name, wine_name, remaining_ml, date.today().isoformat(), cabinet_no, store_id))

    # 短信只发一次
    from asyncio import create_task
    create_task(_safe_send_sms(phone, customer_name, wine_name, last_wine.bottle_label, remaining_ml))

    qty = max(quantity, 1)
    logger.info(f"存酒成功: x{qty} {customer_name} {wine_name} {remaining_ml}ml")
    return last_wine


async def _safe_print_label(bottle_label: str, customer_name: str, wine_name: str,
                            remaining_ml: int, date_stored: str, cabinet_no: str, store_id: int):
    try:
        await print_label(bottle_label, customer_name, wine_name, remaining_ml, date_stored, cabinet_no, store_id)
    except Exception as e:
        logger.error(f"打印标签失败（不影响存酒）: {e}")


async def _safe_send_sms(phone: str, customer_name: str, wine_name: str,
                          bottle_label: str, remaining_ml: int):
    try:
        await send_stored_sms(phone, customer_name, wine_name, bottle_label, remaining_ml)
    except Exception as e:
        logger.error(f"短信发送失败（不影响存酒）: {e}")


# ==================== 服务员取酒 ====================

async def staff_retrieve(
    session: AsyncSession,
    store_id: int,
    bottle_label: str,
    retrieve_ml: int,
    table_no: str | None = None,
) -> WineStorage:
    """服务员取酒：查瓶身码 → 扣减 → 短信通知"""
    repo = WineRepository(session, store_id)
    wine = await repo.get_by_bottle_label(bottle_label)

    if not wine:
        raise NotFoundError(f"未找到瓶身码 {bottle_label}")

    if wine.status == "retrieved":
        raise ConflictError("该瓶酒已全部取完")

    current = wine.remaining_ml or 0
    if retrieve_ml > current:
        raise ValidationError(f"剩余 {current}ml，无法取出 {retrieve_ml}ml")

    wine = await repo.partial_retrieve(wine, retrieve_ml, table_no)

    from asyncio import create_task
    create_task(send_retrieved_sms(wine.phone, wine.customer_name, wine.wine_name, retrieve_ml, bottle_label))

    logger.info(f"服务员取酒: {bottle_label} {wine.customer_name} {retrieve_ml}ml 桌号={table_no}")
    return wine


# ==================== 客人自助取酒 ====================

async def self_retrieve(
    session: AsyncSession,
    bottle_label: str,
    retrieve_ml: int,
    table_no: str | None = None,
) -> WineStorage:
    """客人自助取酒：查瓶身码（不限门店）→ 扣减 → 云打印机出小票"""
    from sqlalchemy import select
    from app.models.wine_storage import WineStorage

    stmt = select(WineStorage).where(WineStorage.bottle_label == bottle_label)
    result = await session.execute(stmt)
    wine = result.scalar_one_or_none()

    if not wine:
        raise NotFoundError(f"未找到瓶身码 {bottle_label}")

    if wine.status == "retrieved":
        raise ConflictError("该瓶酒已全部取完")

    current = wine.remaining_ml or 0
    if retrieve_ml > current:
        raise ValidationError(f"剩余 {current}ml，无法取出 {retrieve_ml}ml")

    wine.remaining_ml = current - retrieve_ml

    if table_no:
        wine.table_no = table_no

    if wine.remaining_ml == 0:
        wine.status = "retrieved"
        wine.retrieved_at = datetime.now().isoformat()

    await session.flush()

    # 云打印机出取酒小票
    from asyncio import create_task
    create_task(print_retrieve_receipt(
        bottle_label, wine.customer_name, wine.wine_name, retrieve_ml, table_no or "-", wine.store_id
    ))

    logger.info(f"客人自助取酒: {bottle_label} {wine.customer_name} {retrieve_ml}ml 桌号={table_no}")
    return wine


# ==================== 短信通知 ====================

async def send_stored_sms(phone: str, customer_name: str, wine_name: str,
                          bottle_label: str, remaining_ml: int) -> bool:
    capacity_map = {750: "满瓶", 562: "大半瓶", 375: "半瓶", 187: "小半瓶"}
    capacity = capacity_map.get(remaining_ml, f"{remaining_ml}ml")
    content = (
        f"【Crush酒吧】{customer_name}您好，您的{wine_name}({capacity})已存好。"
        f"取酒点这里 z.cn/w/{bottle_label}"
    )
    try:
        await http_client.post(SMS_API_URL, json_body={"phone": phone, "content": content})
        return True
    except Exception as e:
        logger.error(f"存酒短信失败 phone={phone}: {e}")
        return False


async def send_retrieved_sms(phone: str, customer_name: str, wine_name: str,
                             retrieve_ml: int, bottle_label: str) -> bool:
    content = (
        f"【Crush酒吧】{customer_name}您好，您的{wine_name}已取出 {retrieve_ml}ml。"
        f"瓶身码: {bottle_label}。感谢光临！"
    )
    try:
        await http_client.post(SMS_API_URL, json_body={"phone": phone, "content": content})
        return True
    except Exception as e:
        logger.error(f"取酒短信失败 phone={phone}: {e}")
        return False
