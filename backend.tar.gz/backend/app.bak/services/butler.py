"""
智能管家模块业务逻辑层
- AI Provider 抽象（DummyProvider）
- 会话创建与管理
- 照片上传与 AI 判定
- 临时加项
"""
import os
import uuid
from datetime import datetime
from typing import Protocol
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from app.repositories.butler import ButlerRepository
from app.models.butler import ClosingSession
from app.utils.exceptions import NotFoundError, ValidationError


# ==================== AI Provider 抽象层 ====================

class AIProvider(Protocol):
    """AI 图像判定提供者接口"""

    async def analyze_photo(self, photo_path: str, item_name: str) -> dict:
        """分析照片，返回 {'pass': bool, 'confidence': float, 'reason': str}"""
        ...


class DummyProvider:
    """占位 AI Provider：所有照片标记为人工复核"""

    async def analyze_photo(self, photo_path: str, item_name: str) -> dict:
        return {
            "pass": None,
            "confidence": 0.0,
            "reason": "AI 服务未配置，需人工复核",
            "provider": "dummy",
        }


# 单例
_ai_provider: AIProvider = DummyProvider()


def get_ai_provider() -> AIProvider:
    return _ai_provider


def set_ai_provider(provider: AIProvider) -> None:
    global _ai_provider
    _ai_provider = provider


# ==================== 照片上传 ====================

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "uploads", "closing")

def _ensure_upload_dir():
    os.makedirs(UPLOAD_DIR, exist_ok=True)


async def save_uploaded_photo(file_content: bytes, filename: str) -> str:
    """保存上传的检查照片，返回访问路径"""
    _ensure_upload_dir()
    ext = filename.rsplit(".", 1)[-1] if "." in filename else "jpg"
    safe_name = f"{uuid.uuid4().hex}.{ext}"
    filepath = os.path.join(UPLOAD_DIR, safe_name)
    with open(filepath, "wb") as f:
        f.write(file_content)
    return f"/uploads/closing/{safe_name}"


# ==================== 会话管理 ====================

async def start_session(
    db: AsyncSession,
    store_id: int,
    user_id: int,
    session_type: str,
) -> dict:
    """创建开店/闭店会话，自动拉取所有相关模板并预创建检查项"""
    repo = ButlerRepository(db, store_id)

    # 检查是否已有进行中的同类型会话
    existing = await repo.get_active_session(session_type)
    if existing:
        raise ValidationError(f"已有进行中的{session_type}检查，请先完成或结束当前会话")

    # 拉取本店所有匹配类型的活跃模板
    templates_raw = await repo.list_templates(session_type=session_type)
    templates = [t for t in templates_raw if t.get("is_active")]

    if not templates:
        raise ValidationError(f"本店尚未配置{session_type}检查清单模板，请在设置中创建")

    # 创建会话
    total_items = sum(len(t.get("items", [])) for t in templates)
    session = await repo.create_session({
        "store_id": store_id,
        "session_type": session_type,
        "operator_user_id": user_id,
        "status": "in_progress",
        "started_at": datetime.utcnow(),
        "total_items": total_items,
        "completed_items": 0,
    })

    # 为每个模板的每个项预创建 result（pending 状态）
    results = []
    for tpl in templates:
        for item in tpl.get("items", []):
            results.append({
                "session_id": session.id,
                "template_id": tpl["id"],
                "item_id": item["id"],
                "item_name": item.get("item_name"),
                "item_type": item.get("item_type", "checkbox"),
                "review_status": "pending",
            })

    if results:
        result_objs = await repo.create_results_batch(results)

    logger.info(f"会话已创建: id={session.id} type={session_type} store={store_id} items={total_items}")
    return await _build_session_detail(repo, session.id)


async def _build_session_detail(repo: ButlerRepository, session_id: int) -> dict:
    """组装会话详情（含模板和检查结果分组）"""
    session = await repo.get_session(session_id)
    if not session:
        raise NotFoundError("会话不存在")

    results = await repo.get_results_by_session(session_id)

    # 按模板分组结果
    template_groups: dict[int, list] = {}
    for r in results:
        tid = r.template_id or 0  # 0 = 临时加项
        if tid not in template_groups:
            template_groups[tid] = []
        template_groups[tid].append(r)

    # 构建模板列表
    templates_output = []
    templates_raw = await repo.list_templates(session_type=session.session_type)

    for tpl in templates_raw:
        tid = tpl["id"]
        tpl_results = template_groups.pop(tid, [])
        tpl["results"] = [
            {
                "id": r.id,
                "session_id": r.session_id,
                "template_id": r.template_id,
                "item_id": r.item_id,
                "item_name": r.item_name,
                "item_type": r.item_type,
                "completed_by": r.completed_by,
                "photo_url": r.photo_url,
                "ai_result": r.ai_result,
                "review_status": r.review_status,
                "review_comment": r.review_comment,
                "completed_at": r.completed_at.isoformat() if r.completed_at else None,
            }
            for r in tpl_results
        ]
        templates_output.append(tpl)

    # 临时加项（template_id=0 或 NULL）
    if 0 in template_groups:
        adhoc_results = template_groups[0]
        templates_output.append({
            "id": 0,
            "store_id": session.store_id,
            "name": "临时加项",
            "session_type": session.session_type,
            "role_tag": "all",
            "sort_order": 999,
            "is_active": True,
            "items": [],
            "results": [
                {
                    "id": r.id,
                    "session_id": r.session_id,
                    "template_id": None,
                    "item_id": None,
                    "item_name": r.item_name,
                    "item_type": r.item_type,
                    "completed_by": r.completed_by,
                    "photo_url": r.photo_url,
                    "ai_result": r.ai_result,
                    "review_status": r.review_status,
                    "review_comment": r.review_comment,
                    "completed_at": r.completed_at.isoformat() if r.completed_at else None,
                }
                for r in adhoc_results
            ],
        })

    return {
        "id": session.id,
        "store_id": session.store_id,
        "session_type": session.session_type,
        "operator_user_id": session.operator_user_id,
        "status": session.status,
        "started_at": session.started_at.isoformat() if session.started_at else None,
        "completed_at": session.completed_at.isoformat() if session.completed_at else None,
        "total_items": session.total_items,
        "completed_items": session.completed_items,
        "templates": templates_output,
    }


async def _check_session_complete(repo: ButlerRepository, session_id: int) -> None:
    """检查会话是否所有项都已完成，如果是则自动标记 completed"""
    session = await repo.get_session(session_id)
    if not session or session.status != "in_progress":
        return

    results = await repo.get_results_by_session(session_id)
    all_done = all(r.review_status != "pending" for r in results)

    if all_done:
        await repo.update_session(session, status="completed", completed_at=datetime.utcnow())
        logger.info(f"会话已完成: id={session_id}")


# ==================== 检查项操作 ====================

async def confirm_item(
    db: AsyncSession,
    store_id: int,
    session_id: int,
    result_id: int,
    user_id: int,
    comment: str | None = None,
) -> dict:
    """打勾确认一个检查项（checkbox 类型）"""
    repo = ButlerRepository(db, store_id)
    result = await repo.get_result(result_id, session_id)
    if not result:
        raise NotFoundError("检查项不存在")

    if result.review_status != "pending":
        raise ValidationError("该检查项已完成，不能重复提交")

    await repo.update_result(
        result,
        review_status="passed",
        completed_by=user_id,
        review_comment=comment,
        completed_at=datetime.utcnow(),
    )

    # 更新会话进度
    session = await repo.get_session(session_id)
    if session:
        await repo.update_session(session, completed_items=session.completed_items + 1)

    await _check_session_complete(repo, session_id)
    return {
        "id": result.id,
        "review_status": "passed",
        "completed_at": datetime.utcnow().isoformat(),
    }


async def upload_photo(
    db: AsyncSession,
    store_id: int,
    session_id: int,
    result_id: int,
    user_id: int,
    file_content: bytes,
    filename: str,
) -> dict:
    """拍照上传一个检查项（photo 类型）—— AI 判定 + 保存"""
    repo = ButlerRepository(db, store_id)
    result = await repo.get_result(result_id, session_id)
    if not result:
        raise NotFoundError("检查项不存在")

    if result.review_status != "pending":
        raise ValidationError("该检查项已完成，不能重复提交")

    # 保存照片
    photo_url = await save_uploaded_photo(file_content, filename)

    # AI 判定
    item_name = result.item_name or "未知检查项"
    photo_path = os.path.join(UPLOAD_DIR, os.path.basename(photo_url))
    ai = get_ai_provider()
    ai_result = await ai.analyze_photo(photo_path, item_name)

    # 根据 AI 置信度决定状态
    # DummyProvider 始终返回 confidence=0，走人工复核
    if ai_result.get("pass") is True and ai_result.get("confidence", 0) >= 0.85:
        review_status = "auto_passed"
    elif ai_result.get("pass") is False:
        review_status = "manual_reviewing"
    else:
        review_status = "manual_reviewing"

    await repo.update_result(
        result,
        photo_url=photo_url,
        ai_result=ai_result,
        review_status=review_status,
        completed_by=user_id,
        completed_at=datetime.utcnow(),
    )

    # 更新会话进度
    session = await repo.get_session(session_id)
    if session:
        await repo.update_session(session, completed_items=session.completed_items + 1)

    await _check_session_complete(repo, session_id)
    return {
        "id": result.id,
        "photo_url": photo_url,
        "ai_result": ai_result,
        "review_status": review_status,
        "completed_at": datetime.utcnow().isoformat(),
    }


async def add_adhoc_item(
    db: AsyncSession,
    store_id: int,
    session_id: int,
    item_name: str,
    item_type: str,
) -> dict:
    """在会话中临时添加一个检查项"""
    repo = ButlerRepository(db, store_id)
    session = await repo.get_session(session_id)
    if not session:
        raise NotFoundError("会话不存在")
    if session.status != "in_progress":
        raise ValidationError("会话已结束，不能再添加检查项")

    result = await repo.create_result({
        "session_id": session_id,
        "template_id": None,
        "item_id": None,
        "item_name": item_name,
        "item_type": item_type,
        "review_status": "pending",
    })

    # 更新会话总数
    await repo.update_session(session, total_items=session.total_items + 1)

    return {
        "id": result.id,
        "session_id": result.session_id,
        "item_name": result.item_name,
        "item_type": result.item_type,
        "review_status": result.review_status,
    }
