"""
工资计算业务逻辑层

公式: 实发 = 合同月薪 - 考勤扣款 + 提成(10%)
每月 5 号自动生成，依赖考勤(attendance) + KPI(占位)

考勤扣款规则:
  - 迟到: 每分钟 5 元
  - 旷工: 每天扣 3 倍日薪
  - 早退: 每次 100 元

提成规则:
  - 开瓶提成(commission_bottle) + 开卡提成(commission_card)
  - 提成总额 = (开瓶 + 开卡) * 1.10
"""
from datetime import datetime
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger

from app.models.payroll import PayrollRecord
from app.repositories.payroll import PayrollRepository
from app.utils.exceptions import (
    AppError,
    NotFoundError,
    ConflictError,
    ValidationError,
)

# 考勤扣款单价
LATE_DEDUCTION_PER_MINUTE = 5.0      # 迟到每分钟 5 元
ABSENT_DEDUCTION_FACTOR = 3.0         # 旷工扣 3 倍日薪
EARLY_DEDUCTION_PER_TIME = 100.0      # 早退每次 100 元

# 提成系数
COMMISSION_MULTIPLIER = 1.10          # 提成上浮 10%

# 按 30 天计算日薪
DAYS_PER_MONTH = 30


class PayrollService:
    """工资计算 Service。每个请求创建新实例。"""

    def __init__(self, session: AsyncSession, store_id: int):
        self.repo = PayrollRepository(session, store_id)
        self.session = session
        self.store_id = store_id

    # ==================== 生成工资 ====================

    async def generate(
        self, period: str, employee_ids: list[int] | None = None
    ) -> list[PayrollRecord]:
        """
        为指定员工生成月度工资记录。

        流程:
          1. 取在职员工列表
          2. 逐人计算: base_salary(合同月薪) / KPI系数(占位) / 提成 / 考勤扣款
          3. 公式: net_pay = base_salary - deduction_total + commission_total
          4. 写入 payroll_records (upsert, 可重复生成覆盖)
        """
        if employee_ids:
            all_employees = await self.repo.get_active_employees()
            employees = [e for e in all_employees if e.id in employee_ids]
            if not employees:
                raise ValidationError("指定的员工均不在职")
        else:
            employees = await self.repo.get_active_employees()

        if not employees:
            raise NotFoundError("门店没有在职员工")

        records: list[PayrollRecord] = []
        now = datetime.now().isoformat()

        for emp in employees:
            base_salary = emp.base_salary

            # KPI 系数（占位：未确认默认 1.00）
            kpi_coefficient = await self.repo.get_monthly_kpi_coefficient(
                emp.id, period
            )

            # 提成（占位：后续从营收系统拉取）
            commission_bottle = 0.0
            commission_card = 0.0
            commission_total = round(
                (commission_bottle + commission_card) * COMMISSION_MULTIPLIER, 2
            )

            # 考勤扣款
            att_summary = await self.repo.get_monthly_attendance_summary(
                emp.id, period
            )
            deduction_late = round(
                float(att_summary.get("total_late_minutes", 0)) * LATE_DEDUCTION_PER_MINUTE, 2
            )
            deduction_absent = round(
                float(att_summary.get("absent_count", 0))
                * (base_salary / DAYS_PER_MONTH)
                * ABSENT_DEDUCTION_FACTOR,
                2,
            )
            deduction_early = round(
                float(att_summary.get("early_count", 0)) * EARLY_DEDUCTION_PER_TIME, 2
            )
            deduction_total = round(deduction_late + deduction_absent + deduction_early, 2)

            # 核心公式: 实发 = 合同月薪 - 考勤扣款 + 提成总额
            net_pay = round(base_salary - deduction_total + commission_total, 2)

            record = PayrollRecord(
                employee_id=emp.id,
                store_id=self.store_id,
                period=period,
                base_salary=base_salary,
                kpi_coefficient=kpi_coefficient,
                commission_bottle=commission_bottle,
                commission_card=commission_card,
                commission_total=commission_total,
                deduction_late=deduction_late,
                deduction_absent=deduction_absent,
                deduction_other=deduction_early,
                deduction_total=deduction_total,
                net_pay=net_pay,
                status="draft",
                generated_at=now,
            )

            await self.repo.upsert_record(record)
            records.append(record)

            logger.info(
                f"[Payroll] {emp.name}({emp.id}) {period}: "
                f"base={base_salary} kpi_coef={kpi_coefficient} "
                f"deduction={deduction_total} commission={commission_total} "
                f"net={net_pay}"
            )

        await self.session.flush()
        await self.session.commit()
        return records

    # ==================== 工资查询 ====================

    async def get_monthly(
        self, period: str, page: int = 1, page_size: int = 50
    ) -> dict:
        """门店月度工资汇总"""
        from app.utils.pagination import PageParams
        params = PageParams(page=page, page_size=page_size)
        records, total = await self.repo.get_records(period=period, page=params)

        if not records:
            return {
                "period": period,
                "store_id": self.store_id,
                "items": [],
                "total_base_salary": 0.0,
                "total_commission": 0.0,
                "total_deduction": 0.0,
                "total_net_pay": 0.0,
                "status_summary": {},
            }

        employee_ids = [r.employee_id for r in records]
        emp_info = await self.repo.get_employee_info(employee_ids)

        total_base = 0.0
        total_comm = 0.0
        total_ded = 0.0
        total_net = 0.0
        status_summary: dict[str, int] = {}
        items = []

        for r in records:
            emp = emp_info.get(r.employee_id, {"name": "", "role": ""})
            items.append({
                "record_id": r.id,
                "employee_id": r.employee_id,
                "employee_name": emp["name"],
                "employee_role": emp["role"],
                "base_salary": r.base_salary,
                "kpi_coefficient": r.kpi_coefficient,
                "commission_total": r.commission_total,
                "deduction_total": r.deduction_total,
                "net_pay": r.net_pay,
                "status": r.status,
            })
            total_base += r.base_salary
            total_comm += r.commission_total
            total_ded += r.deduction_total
            total_net += r.net_pay
            status_summary[r.status] = status_summary.get(r.status, 0) + 1

        return {
            "period": period,
            "store_id": self.store_id,
            "items": items,
            "total_base_salary": round(total_base, 2),
            "total_commission": round(total_comm, 2),
            "total_deduction": round(total_ded, 2),
            "total_net_pay": round(total_net, 2),
            "status_summary": status_summary,
        }

    async def get_detail(self, record_id: int) -> dict:
        """单条工资详情，含考勤明细"""
        record = await self.repo.get_record_by_id(record_id)
        if not record:
            raise NotFoundError("工资记录不存在")

        emp_info = await self.repo.get_employee_info([record.employee_id])
        emp = emp_info.get(record.employee_id, {"name": "", "role": ""})

        att_summary = await self.repo.get_monthly_attendance_summary(
            record.employee_id, record.period
        )

        return {
            "id": record.id,
            "employee_id": record.employee_id,
            "store_id": record.store_id,
            "period": record.period,
            "base_salary": record.base_salary,
            "kpi_coefficient": record.kpi_coefficient,
            "commission_bottle": record.commission_bottle,
            "commission_card": record.commission_card,
            "commission_total": record.commission_total,
            "deduction_late": record.deduction_late,
            "deduction_absent": record.deduction_absent,
            "deduction_other": record.deduction_other,
            "deduction_total": record.deduction_total,
            "net_pay": record.net_pay,
            "status": record.status,
            "generated_at": record.generated_at,
            "finalized_at": record.finalized_at,
            "paid_at": record.paid_at,
            "notes": record.notes,
            "employee_name": emp["name"],
            "employee_role": emp["role"],
            "attendance_summary": att_summary,
        }

    # ==================== 工资确认 ====================

    async def finalize(self, record_ids: list[int], notes: str | None = None) -> int:
        """确认工资条，状态 draft -> confirmed"""
        records = await self.repo.get_records_by_ids(record_ids)
        if not records:
            raise NotFoundError("未找到指定的工资记录")

        not_draft = [r for r in records if r.status != "draft"]
        if not_draft:
            raise ValidationError(
                f"以下记录非草稿状态，不可确认: "
                f"{[r.id for r in not_draft]}"
            )

        now = datetime.now().isoformat()
        kwargs = {"finalized_at": now}
        if notes:
            kwargs["notes"] = notes

        count = await self.repo.batch_update_status(
            record_ids, "confirmed", **kwargs
        )
        await self.session.commit()
        logger.info(f"[Payroll] 确认 {count} 条工资记录")
        return count

    async def mark_paid(self, record_ids: list[int], paid_at: str | None = None) -> int:
        """标记已发放，状态 confirmed -> paid"""
        records = await self.repo.get_records_by_ids(record_ids)
        if not records:
            raise NotFoundError("未找到指定的工资记录")

        not_confirmed = [r for r in records if r.status != "confirmed"]
        if not_confirmed:
            raise ValidationError(
                f"以下记录非已确认状态，不可标记发放: "
                f"{[r.id for r in not_confirmed]}"
            )

        now = paid_at or datetime.now().isoformat()
        count = await self.repo.batch_update_status(
            record_ids, "paid", paid_at=now
        )
        await self.session.commit()
        logger.info(f"[Payroll] 标记 {count} 条工资已发放")
        return count
