"""
数据看板数据访问层
封装聚合 SQL 查询，返回 ORM 对象 / 原始数据。
依赖: DailyRevenue, GuestRating, Booking, Table, AttendanceRecord
"""
from datetime import date, timedelta
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.revenue import DailyRevenue
from app.models.rating import GuestRating
from app.models.booking import Booking, Table
from app.models.attendance import AttendanceRecord
from app.models.table_session import TableSession
from app.schemas.dashboard import (
    RevenueBlock, RevenueBreakdown, ChartPoint,
    RatingSummary, LowScoreAlert, BookingSummary, AttendanceSummary,
    MyPerformance,
)


class DashboardRepository:
    """数据看板 Repository"""

    def __init__(self, session: AsyncSession, store_id: int):
        self.session = session
        self.store_id = store_id

    # ==================== 营收概览 ====================

    async def get_revenue_block(self) -> RevenueBlock | None:
        """获取今日营收概览，含昨日对比"""
        today_str = str(date.today())
        yesterday_str = str(date.today() - timedelta(days=1))

        stmt = select(DailyRevenue).where(
            and_(
                DailyRevenue.store_id == self.store_id,
                DailyRevenue.date.in_([today_str, yesterday_str]),
            )
        )
        result = await self.session.execute(stmt)
        rows = {r.date: r for r in result.scalars().all()}

        today = rows.get(today_str)
        yesterday = rows.get(yesterday_str)

        if not today and not yesterday:
            return None

        today_revenue = today.total_revenue if today else 0.0
        yesterday_revenue = yesterday.total_revenue if yesterday else 0.0
        today_orders = today.total_orders if today else 0
        today_guests = today.total_guests if today else 0
        today_avg = today.avg_order_value if today else 0.0

        if yesterday_revenue > 0:
            growth_rate = round((today_revenue - yesterday_revenue) / yesterday_revenue, 4)
        elif today_revenue > 0:
            growth_rate = 1.0
        else:
            growth_rate = 0.0

        return RevenueBlock(
            today_revenue=today_revenue,
            yesterday_revenue=yesterday_revenue,
            growth_rate=growth_rate,
            total_orders=today_orders,
            total_guests=today_guests,
            avg_order_value=today_avg,
        )

    # ==================== 营收构成 ====================

    async def get_revenue_breakdown(self) -> RevenueBreakdown | None:
        """获取今日营收构成"""
        today_str = str(date.today())

        stmt = select(DailyRevenue).where(
            and_(
                DailyRevenue.store_id == self.store_id,
                DailyRevenue.date == today_str,
            )
        )
        result = await self.session.execute(stmt)
        row = result.scalar_one_or_none()

        if not row:
            return None

        total = row.total_revenue
        bottle = row.bottle_sales
        card = row.card_sales
        other = total - bottle - card
        if other < 0:
            other = 0.0

        return RevenueBreakdown(
            bottle_sales=bottle,
            card_sales=card,
            other_sales=other,
            total=total,
            bottle_pct=round(bottle / total, 4) if total > 0 else 0.0,
            card_pct=round(card / total, 4) if total > 0 else 0.0,
            other_pct=round(other / total, 4) if total > 0 else 0.0,
        )

    # ==================== 7天趋势 ====================

    async def get_7day_revenue(self) -> list[ChartPoint]:
        """获取最近 7 天营收趋势"""
        today = date.today()
        dates = [(today - timedelta(days=i)).isoformat() for i in range(6, -1, -1)]

        stmt = select(DailyRevenue).where(
            and_(
                DailyRevenue.store_id == self.store_id,
                DailyRevenue.date.in_(dates),
            )
        )
        result = await self.session.execute(stmt)
        rows = {r.date: r for r in result.scalars().all()}

        weekday_map = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]

        chart = []
        for d in dates:
            dt = date.fromisoformat(d)
            day_label = d[-5:]  # MM-DD
            wd = weekday_map[dt.weekday()]
            row = rows.get(d)
            chart.append(ChartPoint(
                date=day_label,
                weekday=wd,
                revenue=row.total_revenue if row else 0.0,
                orders=row.total_orders if row else 0,
            ))

        return chart

    # ==================== 顾客评分 ====================

    async def get_ratings_summary(self) -> RatingSummary:
        """获取今日评分汇总 + 低分预警"""
        today_str = str(date.today())

        # 今日评分
        stmt = select(GuestRating).where(
            and_(
                GuestRating.store_id == self.store_id,
                GuestRating.created_at >= today_str,
            )
        ).order_by(GuestRating.overall_score.asc())

        result = await self.session.execute(stmt)
        ratings = list(result.scalars().all())

        if not ratings:
            # 查询近 7 天数据作为 fallback
            seven_days_ago = str(date.today() - timedelta(days=7))
            stmt = select(GuestRating).where(
                and_(
                    GuestRating.store_id == self.store_id,
                    GuestRating.created_at >= seven_days_ago,
                )
            ).order_by(GuestRating.overall_score.asc())
            result = await self.session.execute(stmt)
            ratings = list(result.scalars().all())

        if not ratings:
            return RatingSummary()

        total = len(ratings)
        avg = round(sum(r.overall_score for r in ratings) / total, 2)

        low_scores = [r for r in ratings if r.is_low_score or r.overall_score < 3.0]
        low_score_alerts = [
            LowScoreAlert(
                id=r.id,
                table_no=r.table_no,
                overall_score=r.overall_score,
                comment=r.comment or "",
                created_at=r.created_at,
            )
            for r in low_scores[:5]
        ]

        return RatingSummary(
            avg_score=avg,
            total_ratings=total,
            low_score_count=len(low_scores),
            alerts=low_score_alerts,
        )

    # ==================== 订桌概况 ====================

    async def get_booking_summary(self) -> BookingSummary:
        """获取今日订桌概况"""
        today_str = str(date.today())

        # 总桌数
        table_stmt = select(func.count()).select_from(Table).where(
            and_(
                Table.store_id == self.store_id,
                Table.status == "active",
            )
        )
        table_result = await self.session.execute(table_stmt)
        total_tables = table_result.scalar() or 0

        # 今日已确认预订
        booking_stmt = select(func.count()).select_from(Booking).where(
            and_(
                Booking.store_id == self.store_id,
                Booking.date == today_str,
                Booking.status == "confirmed",
            )
        )
        booking_result = await self.session.execute(booking_stmt)
        confirmed = booking_result.scalar() or 0

        available = max(0, total_tables - confirmed)

        return BookingSummary(
            confirmed=confirmed,
            total_tables=total_tables,
            available=available,
        )

    # ==================== 今日考勤 ====================

    async def get_attendance_summary(self) -> AttendanceSummary:
        """获取今日考勤汇总"""
        today = date.today()

        # 查询今日所有考勤记录（date 列为 PG date 类型，必须传 Python date 对象）
        stmt = select(AttendanceRecord).where(
            and_(
                AttendanceRecord.store_id == self.store_id,
                AttendanceRecord.date == today,
            )
        )
        result = await self.session.execute(stmt)
        rows = list(result.scalars().all())

        scheduled_count = 0
        actual_count = 0
        late_count = 0
        absent_count = 0
        early_count = 0
        leave_count = 0

        for r in rows:
            # 应出勤：有排班且非休息/请假
            if r.scheduled_shift and r.scheduled_shift not in ("rest", "leave", "休息", "请假"):
                scheduled_count += 1
            # 请假
            if r.scheduled_shift in ("leave", "请假"):
                leave_count += 1
            # 实际出勤：有打卡记录（clock_in 非空）
            if r.clock_in:
                actual_count += 1
            # 迟到
            if r.late_minutes and r.late_minutes > 0:
                late_count += 1
            # 旷工
            if r.status == "absent":
                absent_count += 1
            # 早退
            if r.early_minutes and r.early_minutes > 0:
                early_count += 1

        return AttendanceSummary(
            scheduled_count=scheduled_count,
            actual_count=actual_count,
            late_count=late_count,
            absent_count=absent_count,
            early_count=early_count,
            leave_count=leave_count,
        )

    # ==================== 我的业绩 ====================

    async def get_my_performance(self, employee_id: int) -> MyPerformance:
        """获取当前员工本月累计企微个人收款"""
        now = date.today()
        period = f"{now.year}-{now.month:02d}"
        month_start = f"{period}-01"

        stmt = select(func.coalesce(func.sum(TableSession.wework_pay_amount), 0)).where(
            and_(
                TableSession.store_id == self.store_id,
                TableSession.commission_employee_id == employee_id,
                TableSession.opened_at >= month_start,
            )
        )
        result = await self.session.execute(stmt)
        total = result.scalar() or 0

        return MyPerformance(
            total_wework_pay=round(float(total), 2),
            period=period,
        )

    async def get_my_performance_detail(self, employee_id: int) -> list[dict]:
        """获取当前员工本月每日企微收款明细"""
        from sqlalchemy import cast, Date
        from sqlalchemy.dialects.postgresql import TEXT

        now = date.today()
        month_start = f"{now.year}-{now.month:02d}-01"

        stmt = select(
            func.substring(TableSession.opened_at, 1, 10).label("day"),
            func.coalesce(func.sum(TableSession.wework_pay_amount), 0).label("amount"),
        ).where(
            and_(
                TableSession.store_id == self.store_id,
                TableSession.commission_employee_id == employee_id,
                TableSession.opened_at >= month_start,
            )
        ).group_by(
            func.substring(TableSession.opened_at, 1, 10)
        ).order_by(
            func.substring(TableSession.opened_at, 1, 10)
        )

        result = await self.session.execute(stmt)
        rows = result.all()

        # 填充整个月的每一天
        row_map = {row.day: float(row.amount) for row in rows}
        days_in_month = _days_in_month(now.year, now.month)
        detail = []
        total = 0
        for d in range(1, days_in_month + 1):
            day_str = f"{now.year}-{now.month:02d}-{d:02d}"
            amt = row_map.get(day_str, 0)
            total += amt
            detail.append({
                "date": day_str,
                "amount": round(amt, 2),
                "cumulative": round(total, 2),
            })

        return detail


def _days_in_month(year: int, month: int) -> int:
    import calendar
    return calendar.monthrange(year, month)[1]
