"""订桌预约数据访问层。

所有查询通过 store_id 过滤（RLS），boss 角色传入 store_id=None 查全部。
"""

from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.booking import Booking, Table
from app.utils.pagination import PageParams, paginate_query


class TableRepo:
    """桌位 CRUD。"""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(self, store_id: int, data: dict) -> Table:
        table = Table(store_id=store_id, **data)
        self.session.add(table)
        await self.session.commit()
        await self.session.refresh(table)
        return table

    async def get_by_id(self, table_id: int, store_id: int | None = None) -> Table | None:
        stmt = select(Table).where(Table.id == table_id)
        if store_id is not None:
            stmt = stmt.where(Table.store_id == store_id)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_by_store(
        self,
        store_id: int,
        *,
        area: str | None = None,
        status: str | None = "active",
        params: PageParams | None = None,
    ) -> tuple[list[Table], int]:
        base = select(Table).where(Table.store_id == store_id)
        if area:
            base = base.where(Table.area == area)
        if status:
            base = base.where(Table.status == status)
        base = base.order_by(Table.area, Table.table_no)

        if params:
            items, total = await paginate_query(self.session, base, params)
        else:
            result = await self.session.execute(base)
            items = list(result.scalars().all())
            total = len(items)
        return items, total

    async def update(self, table: Table, data: dict) -> Table:
        for k, v in data.items():
            if v is not None:
                setattr(table, k, v)
        await self.session.commit()
        await self.session.refresh(table)
        return table

    async def delete(self, table: Table) -> None:
        await self.session.delete(table)
        await self.session.commit()

    async def count_active(self, store_id: int) -> int:
        stmt = select(func.count()).where(
            Table.store_id == store_id,
            Table.status == "active",
        )
        return (await self.session.execute(stmt)).scalar_one()


class BookingRepo:
    """预约 CRUD。"""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(self, store_id: int, data: dict) -> Booking:
        booking = Booking(store_id=store_id, **data)
        self.session.add(booking)
        await self.session.commit()
        await self.session.refresh(booking)
        return booking

    async def get_by_id(
        self, booking_id: int, store_id: int | None = None
    ) -> Booking | None:
        stmt = select(Booking).where(Booking.id == booking_id)
        if store_id is not None:
            stmt = stmt.where(Booking.store_id == store_id)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_by_date(
        self,
        store_id: int,
        *,
        date: str | None = None,
        status: str | None = None,
        params: PageParams | None = None,
    ) -> tuple[list[Booking], int]:
        base = select(Booking).where(Booking.store_id == store_id)
        if date:
            base = base.where(Booking.date == date)
        if status:
            base = base.where(Booking.status == status)
        base = base.order_by(Booking.date.desc(), Booking.time_slot.asc())

        if params:
            items, total = await paginate_query(self.session, base, params)
        else:
            result = await self.session.execute(base)
            items = list(result.scalars().all())
            total = len(items)
        return items, total

    async def update(self, booking: Booking, data: dict) -> Booking:
        for k, v in data.items():
            if v is not None:
                setattr(booking, k, v)
        await self.session.commit()
        await self.session.refresh(booking)
        return booking

    async def delete(self, booking: Booking) -> None:
        await self.session.delete(booking)
        await self.session.commit()

    async def count_by_date_status(
        self, store_id: int, date: str, status: str = "confirmed"
    ) -> int:
        stmt = select(func.count()).where(
            Booking.store_id == store_id,
            Booking.date == date,
            Booking.status == status,
        )
        return (await self.session.execute(stmt)).scalar_one()

    async def find_conflict(
        self, store_id: int, date: str, table_id: int, time_slot: str | None = None
    ) -> Booking | None:
        """查找指定桌位在指定日期的冲突预约。"""
        stmt = select(Booking).where(
            Booking.store_id == store_id,
            Booking.date == date,
            Booking.table_id == table_id,
            Booking.status == "confirmed",
        )
        if time_slot:
            stmt = stmt.where(Booking.time_slot == time_slot)
        result = await self.session.execute(stmt.limit(1))
        return result.scalar_one_or_none()
