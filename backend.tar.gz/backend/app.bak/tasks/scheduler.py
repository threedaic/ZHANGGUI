"""
全局定时任务调度器 (APScheduler)
在 lifespan 中启动，所有模块在此注册定时任务。
所有时间基于 Asia/Shanghai (UTC+8)。

班次检查时间：启动时读取 shift_configs 注册 cron；保存班次时实时更新。
"""
from apscheduler.schedulers.asyncio import AsyncIOScheduler

scheduler = AsyncIOScheduler(timezone='Asia/Shanghai')


def schedule_shift_check(shift_code: str, start_time: str, shift_name: str = "") -> None:
    """注册/更新班次到岗检查 cron 任务：上班时间 + 1 小时。

    保存班次配置后由 API 直接调用，无需轮询。
    """
    from app.tasks.notification_jobs import shift_check_job
    from loguru import logger

    parts = start_time.split(":")
    h, m = int(parts[0]), int(parts[1]) + 60
    if m >= 60:
        h += 1
        m -= 60
    job_id = f"shift_check_{shift_code}"
    scheduler.add_job(
        shift_check_job,
        'cron',
        hour=h,
        minute=m,
        args=[shift_code],
        id=job_id,
        replace_existing=True,
    )
    name_str = f" ({shift_name})" if shift_name else ""
    logger.info(f"班次检查已注册: {shift_code}{name_str} -> 每天 {h:02d}:{m:02d}")


async def init_scheduler():
    """在 app lifespan startup 中调用。"""
    from app.tasks.antifraud import run_daily_antifraud_scan
    from app.tasks.notification_jobs import (
        daily_attendance_report_job,
        auto_sync_checkin_job,
    )
    from loguru import logger

    scheduler.add_job(auto_sync_checkin_job, 'cron', hour=10, minute=0, id='auto_sync_checkin_job', replace_existing=True)
    scheduler.add_job(daily_attendance_report_job, 'cron', hour=10, minute=5, id='daily_attendance_report_job', replace_existing=True)
    scheduler.add_job(run_daily_antifraud_scan, 'cron', hour=4, minute=0, id='run_daily_antifraud_scan', replace_existing=True)

    # 启动时从数据库读取所有班次配置，注册检查任务
    await _register_all_shift_checks()

    scheduler.start()

    jobs = scheduler.get_jobs()
    logger.info(f"定时任务已启动: {len(jobs)} 个")
    for job in jobs:
        logger.info(f"  - {job.name}: {job.next_run_time}")


async def _register_all_shift_checks():
    from app.database import AsyncSessionLocal
    from app.repositories.attendance import AttendanceRepository

    async with AsyncSessionLocal() as session:
        try:
            repo = AttendanceRepository(session, 1)
            configs = await repo.get_shift_configs(active_only=True)
            for cfg in configs:
                schedule_shift_check(cfg.shift_code, cfg.start_time, cfg.shift_name)
        except Exception as e:
            from loguru import logger
            logger.error(f"班次检查启动注册失败: {e}")


def shutdown_scheduler():
    scheduler.shutdown(wait=False)
