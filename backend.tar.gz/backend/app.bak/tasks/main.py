from contextlib import asynccontextmanager
import random
from datetime import date, timedelta
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import select, text
from loguru import logger
from app.config import get_settings
from app.database import engine, AsyncSessionLocal
from app.models import Base
from app.models.user import User
from app.models.company import Company
from app.models.store import Store
from app.utils.security import hash_password
from app.utils.redis_client import init_redis, close_redis
from app.utils.exceptions import AppError
from app.utils.exceptions import app_error_handler, unhandled_error_handler
from app.api.v1.auth import router as auth_router
from app.api.v1.kpi import router as kpi_router
from app.api.v1.schedules import router as schedule_router
from app.api.v1.wines import router as wines_router
from app.api.v1.tables import router as tables_router
from app.api.v1.bookings import router as bookings_router
from app.api.v1.attendance import router as attendance_router
from app.api.v1.approval import router as approval_router
from app.api.v1.notifications import router as notification_router
from app.api.v1.contracts import router as contracts_router
from app.api.v1.antifraud import router as antifraud_router
from app.api.v1.payroll import router as payroll_router
from app.api.v1.dashboard import router as dashboard_router
from app.api.v1.ai import router as ai_router
from app.api.v1.ratings import router as ratings_router
from app.api.v1.store import router as store_router
from app.middleware.rls import RLSMiddleware
from app.middleware.audit import AuditMiddleware
from app.middleware.rate_limit import RateLimitMiddleware
from app.tasks.scheduler import init_scheduler, shutdown_scheduler

import os

# Log path configurable via environment (m-008 fix)
_log_path = os.getenv("LOG_PATH", "logs/crush-zhanggui.log")
logger.add(_log_path, rotation="10 MB", retention="7 days")

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: create tables + seed data + connect Redis + start scheduler
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        await seed_default_data(conn)
    await init_redis()

    # Seed dashboard demo data (development only, once per day)
    async with AsyncSessionLocal() as db:
        await seed_dashboard_demo(db)

    await init_scheduler()
    logger.info(f"{settings.APP_NAME} v{settings.APP_VERSION} started")
    yield
    # Shutdown
    shutdown_scheduler()
    from app.utils.http_client import http_client
    await http_client.close()
    await close_redis()
    await engine.dispose()


async def seed_default_data(conn):
    """Insert demo data if tables are empty."""
    result = await conn.execute(select(User).limit(1))
    if result.scalar_one_or_none() is not None:
        return

    # Company
    await conn.execute(
        text(
            "INSERT INTO companies (name, brand, tax_id, status) "
            "VALUES ('北京跨时餐饮有限公司', 'Crush', '91110105MADYP9JH2X', 'active')"
        )
    )

    # Store
    await conn.execute(
        text(
            "INSERT INTO stores (company_id, name, store_code, address, city, status) "
            "VALUES (1, '北京三里屯店', 'BJ-SLT-001', "
            "'北京市朝阳区工人体育场北路4号80号楼一层113室', '北京', 'active')"
        )
    )

    # Admin user (boss role) — must change password on first login
    await conn.execute(
        text(
            "INSERT INTO users (username, password_hash, role, is_active, must_change_password) "
            "VALUES (:u, :p, 'boss', true, true)"
        ),
        {
            "u": settings.SEED_BOSS_USERNAME,
            "p": hash_password(settings.SEED_BOSS_PASSWORD),
        }
    )
    await conn.commit()


async def seed_dashboard_demo(db):
    """Seed demo data for dashboard when tables are empty (development only)."""
    settings = get_settings()
    if settings.APP_ENV == "production":
        return

    from sqlalchemy import select as sa_select, and_
    from app.models.revenue import DailyRevenue
    from app.models.employee import Employee

    today_str = date.today().isoformat()
    stmt = sa_select(DailyRevenue).where(
        and_(DailyRevenue.store_id == 1, DailyRevenue.date == today_str)
    )
    result = await db.execute(stmt)
    if result.scalar_one_or_none() is not None:
        return

    logger.info("Seeding dashboard demo data...")
    STORE_ID = 1
    rng = random.Random(42)

    # 1. daily_revenue (7 days)
    prev = None
    for i in range(6, -1, -1):
        d = date.today() - timedelta(days=i)
        rev = round(rng.uniform(8000, 22000) if prev is None else prev + rng.uniform(-3000, 3000), 2)
        rev = max(3000, rev)
        prev = rev
        orders = rng.randint(30, 100)
        guests = rng.randint(40, 150)
        bottle = round(rev * rng.uniform(0.4, 0.6), 2)
        card = round(rev * rng.uniform(0.1, 0.2), 2)
        avg = round(rev / orders, 2)
        await db.execute(
            text(
                "INSERT INTO daily_revenue (store_id, date, total_revenue, total_orders, "
                "total_guests, avg_order_value, bottle_sales, card_sales, data_source) "
                "VALUES (:sid, :d, :rev, :ord, :guests, :avg, :bottle, :card, 'seed')"
                "ON CONFLICT (store_id, date) DO NOTHING"
            ),
            {"sid": STORE_ID, "d": d.isoformat(), "rev": rev, "ord": orders,
             "guests": guests, "avg": avg, "bottle": bottle, "card": card},
        )

    # 2. tables (20)
    areas = ["大厅", "卡座", "包间", "吧台"]
    for i in range(20):
        await db.execute(
            text(
                "INSERT INTO tables (store_id, area, table_no, capacity, status) "
                "VALUES (:sid, :area, :tno, :cap, 'active') "
                "ON CONFLICT (store_id, table_no) DO NOTHING"
            ),
            {"sid": STORE_ID, "area": areas[i % 4], "tno": f"A{i+1}",
             "cap": rng.choice([2, 4, 6, 8])},
        )

    # 3. bookings (today, 8-15)
    names = ["张先生", "李小姐", "王先生", "赵女士", "刘先生", "陈小姐", "周先生", "吴女士"]
    slots = ["18:00", "19:00", "19:30", "20:00", "20:30", "21:00", "22:00"]
    for _ in range(rng.randint(8, 15)):
        await db.execute(
            text(
                "INSERT INTO bookings (store_id, customer_name, phone, date, "
                "time_slot, guests_count, table_no, source, status) "
                "VALUES (:sid, :name, :phone, :date, :slot, :guests, :tno, 'staff', 'confirmed')"
            ),
            {"sid": STORE_ID, "name": rng.choice(names),
             "phone": f"138{rng.randint(10000000, 99999999)}",
             "date": today_str, "slot": rng.choice(slots),
             "guests": rng.randint(1, 6), "tno": f"A{rng.randint(1, 20)}"},
        )

    # 4. guest_ratings (today, 10-25)
    good_comments = ["氛围很好", "服务周到", "鸡尾酒好喝", "下次还来", "环境棒", "菜品精致", "价格合理"]
    bad_comments = ["上菜太慢", "音乐太吵", "服务一般", "酒水偏贵"]
    for _ in range(rng.randint(10, 25)):
        low = rng.random() < 0.12
        score = round(rng.uniform(1.0, 2.9), 1) if low else round(rng.uniform(3.5, 5.0), 1)
        cmt = rng.choice(bad_comments) if low else (rng.choice(good_comments) if rng.random() < 0.5 else "")
        await db.execute(
            text(
                "INSERT INTO guest_ratings (store_id, table_no, food_quality, food_speed, "
                "drink_quality, drink_speed, service_attitude, service_speed, cleanliness, "
                "overall_score, comment, source, is_low_score, created_at) "
                "VALUES (:sid, :tno, :fq, :fs, :dq, :ds, :sa, :ss, :cl, :score, :cmt, "
                "'seed', :low, :ts)"
            ),
            {"sid": STORE_ID, "tno": f"A{rng.randint(1, 20)}",
             "fq": rng.randint(2, 5), "fs": rng.randint(2, 5),
             "dq": rng.randint(2, 5), "ds": rng.randint(2, 5),
             "sa": rng.randint(2, 5), "ss": rng.randint(2, 5),
             "cl": rng.randint(2, 5), "score": score, "cmt": cmt, "low": low,
             "ts": f"{today_str}T{rng.randint(18, 23):02d}:{rng.randint(0, 59):02d}:00"},
        )

    # 5. attendance_records (today)
    emp_stmt = sa_select(Employee).where(
        and_(Employee.store_id == STORE_ID, Employee.status == "active")
    )
    emp_result = await db.execute(emp_stmt)
    employees = list(emp_result.scalars().all())
    if not employees:
        # No employees yet, skip attendance seed
        await db.commit()
        logger.info("Dashboard demo seeded (no employees, attendance skipped)")
        return

    shifts = ["白班", "晚班"]
    statuses = ["present"] * 5 + ["late", "present", "absent", "early"]
    for emp in employees:
        shift = rng.choice(shifts)
        status = rng.choice(statuses)
        late = rng.randint(5, 45) if status == "late" else 0
        early = rng.randint(10, 60) if status == "early" else 0
        base_hour = 18 if shift == "晚班" else 12
        clock_in = f"{base_hour + (late // 60):02d}:{late % 60:02d}" if status != "absent" else None
        out_h = (base_hour + 6) % 24 - (early // 60)
        out_m = (60 - early % 60) % 60
        clock_out = f"{out_h:02d}:{out_m:02d}" if status != "absent" else None
        await db.execute(
            text(
                "INSERT INTO attendance_records (store_id, employee_id, date, "
                "scheduled_shift, clock_in, clock_out, status, late_minutes, "
                "early_minutes, source) "
                "VALUES (:sid, :eid, :d, :shift, :cin, :cout, :st, :late, :early, 'seed')"
                "ON CONFLICT (employee_id, date) DO NOTHING"
            ),
            {"sid": STORE_ID, "eid": emp.id, "d": today_str,
             "shift": shift, "cin": clock_in, "cout": clock_out,
             "st": status, "late": late, "early": early},
        )

    await db.commit()
    logger.info(f"Dashboard demo seeded: 7d revenue, 20 tables, ratings/bookings/attendance")

    # Clear Redis dashboard cache so new data takes effect immediately
    try:
        from app.utils.redis_client import get_redis as _get_redis
        _redis = await _get_redis()
        await _redis.delete("dashboard:1")
    except Exception:
        pass


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    lifespan=lifespan,
)

# Middleware: order matters
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
    allow_headers=["Authorization", "Content-Type", "X-Request-ID"],
)
app.add_middleware(GZipMiddleware, minimum_size=1024)
app.add_middleware(RateLimitMiddleware)
app.add_middleware(RLSMiddleware)
app.add_middleware(AuditMiddleware)

# Exception handlers
app.add_exception_handler(AppError, app_error_handler)
app.add_exception_handler(Exception, unhandled_error_handler)

# Request body size limit (I-002: 10 MB max)
MAX_BODY_SIZE = 10 * 1024 * 1024

@app.middleware("http")
async def limit_body_size(request: Request, call_next):
    content_length = request.headers.get("content-length")
    if content_length and int(content_length) > MAX_BODY_SIZE:
        return JSONResponse(
            status_code=413,
            content={"code": 41300, "message": "请求体过大，最大 10 MB", "data": None, "request_id": None},
        )
    return await call_next(request)

# Routes
app.include_router(auth_router, prefix="/api/v1/auth", tags=["auth"])
app.include_router(kpi_router, prefix="/api/v1/kpi", tags=["KPI考核"])
app.include_router(schedule_router, prefix="/api/v1/schedules", tags=["排班管理"])
app.include_router(wines_router, prefix="/api/v1/wines", tags=["存酒管理"])
app.include_router(tables_router, prefix="/api/v1/tables", tags=["桌位管理"])
app.include_router(bookings_router, prefix="/api/v1/bookings", tags=["订桌预约"])
app.include_router(ratings_router, prefix="/api/v1/ratings", tags=["桌面评分码"])
app.include_router(attendance_router, prefix="/api/v1/attendance", tags=["考勤管理"])
app.include_router(approval_router, prefix="/api/v1/approvals", tags=["审批管理"])
app.include_router(notification_router, prefix="/api/v1/notifications", tags=["消息通知"])
app.include_router(contracts_router, prefix="/api/v1/contracts", tags=["合同系统"])
app.include_router(antifraud_router, prefix="/api/v1/antifraud", tags=["防飞单"])
app.include_router(payroll_router, prefix="/api/v1/payroll", tags=["工资计算"])
app.include_router(dashboard_router, prefix="/api/v1/dashboard", tags=["数据看板"])
app.include_router(ai_router, prefix="/api/v1/ai", tags=["小C AI助手"])
app.include_router(store_router, prefix="/api/v1/store", tags=["门店配置"])


@app.get("/health", tags=["system"])
async def health_check():
    try:
        async with AsyncSessionLocal() as session:
            await session.execute(text("SELECT 1"))
        from app.utils.redis_client import get_redis
        redis = await get_redis()
        await redis.ping()
        return {"status": "healthy", "db": "ok", "redis": "ok"}
    except Exception as e:
        # In production, hide internal details (m-002 fix)
        is_prod = settings.APP_ENV == "production"
        error_detail = "service degraded" if is_prod else str(e)
        return {"status": "degraded", "error": error_detail}
