from sqlalchemy import String, Integer, Float, Text, ForeignKey, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import Base, TimestampMixin


class PayrollRecord(Base):
    __tablename__ = "payroll_records"
    __table_args__ = (UniqueConstraint("employee_id", "period"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    employee_id: Mapped[int] = mapped_column(Integer, ForeignKey("employees.id"))
    store_id: Mapped[int] = mapped_column(Integer, ForeignKey("stores.id"))
    period: Mapped[str] = mapped_column(String(7))
    base_salary: Mapped[float] = mapped_column(Float)
    kpi_coefficient: Mapped[float] = mapped_column(Float, default=1.00)
    commission_bottle: Mapped[float] = mapped_column(Float, default=0)
    commission_card: Mapped[float] = mapped_column(Float, default=0)
    commission_total: Mapped[float] = mapped_column(Float, default=0)
    deduction_late: Mapped[float] = mapped_column(Float, default=0)
    deduction_absent: Mapped[float] = mapped_column(Float, default=0)
    deduction_other: Mapped[float] = mapped_column(Float, default=0)
    deduction_total: Mapped[float] = mapped_column(Float, default=0)
    net_pay: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(20), default="draft")
    generated_at: Mapped[str] = mapped_column(Text, default="")
    finalized_at: Mapped[str | None] = mapped_column(Text)
    paid_at: Mapped[str | None] = mapped_column(Text)
    notes: Mapped[str | None] = mapped_column(Text)
