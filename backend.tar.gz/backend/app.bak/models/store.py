from sqlalchemy import String, Integer, Text, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.models.base import Base, TimestampMixin

class Store(TimestampMixin, Base):
    __tablename__ = "stores"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    company_id: Mapped[int] = mapped_column(Integer, ForeignKey("companies.id", ondelete="CASCADE"))
    name: Mapped[str] = mapped_column(String(100))
    store_code: Mapped[str] = mapped_column(String(20), unique=True)
    address: Mapped[str | None] = mapped_column(Text)
    city: Mapped[str | None] = mapped_column(String(50))
    status: Mapped[str] = mapped_column(String(20), default="active")
    franchisee_user_id: Mapped[int | None] = mapped_column(Integer)
    daily_booking_limit: Mapped[int | None] = mapped_column(Integer, default=30, nullable=True)
    wework_corp_id: Mapped[str | None] = mapped_column(String(100))
    wework_agent_id: Mapped[str | None] = mapped_column(String(20))
    wework_secret: Mapped[str | None] = mapped_column(Text)
    wework_department_id: Mapped[int | None] = mapped_column(Integer, nullable=True, comment="企微部门ID，通讯录同步时仅拉取该部门及其子部门成员")
    wework_token: Mapped[str | None] = mapped_column(String(100))
    wework_aes_key: Mapped[str | None] = mapped_column(String(100))
    wework_status: Mapped[str | None] = mapped_column(String(20), default="pending", nullable=True)


class StoreSettings(TimestampMixin, Base):
    __tablename__ = "store_settings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    store_id: Mapped[int] = mapped_column(Integer, ForeignKey("stores.id", ondelete="CASCADE"), unique=True)
    rest_days_per_month: Mapped[int] = mapped_column(Integer, default=4)
    rest_allowed_weekdays: Mapped[str | None] = mapped_column(Text)  # JSON array
    rest_forbidden_weekdays: Mapped[str | None] = mapped_column(Text)
    max_same_position_off: Mapped[int] = mapped_column(Integer, default=1)
    manager_order_constraint: Mapped[bool] = mapped_column(default=True)
    holiday_policy: Mapped[str] = mapped_column(String(20), default="comp_leave")
    auto_schedule_enabled: Mapped[bool] = mapped_column(default=False)
    schedule_lock_after_publish: Mapped[bool] = mapped_column(default=True)
    payroll_day_of_month: Mapped[int] = mapped_column(Integer, default=5)
    kpi_coefficient_min: Mapped[float] = mapped_column(default=0.60)
    kpi_coefficient_max: Mapped[float] = mapped_column(default=1.50)
    # ---- 合同默认配置 ----
    contract_initiator_ids: Mapped[str | None] = mapped_column(Text)  # JSON array: [1, 3, 5]
    contract_company_name: Mapped[str | None] = mapped_column(String(100))
    contract_company_phone: Mapped[str | None] = mapped_column(String(20))
    contract_company_address: Mapped[str | None] = mapped_column(Text)
    contract_base_salary: Mapped[float] = mapped_column(default=3000.0)
    contract_probation_months: Mapped[int] = mapped_column(Integer, default=6)
    contract_notice_days: Mapped[int] = mapped_column(Integer, default=45)
    contract_duration_years: Mapped[int] = mapped_column(Integer, default=3)
    # ---- AI 小C 配置 ----
    ai_api_url: Mapped[str | None] = mapped_column(Text)
    ai_api_key: Mapped[str | None] = mapped_column(Text)  # AES-encrypted
    ai_model: Mapped[str | None] = mapped_column(String(100))
    ai_temperature: Mapped[float] = mapped_column(default=0.7)
    # ---- 云打印机配置 ----
    printer_enabled: Mapped[bool] = mapped_column(default=False)
    printer_brand: Mapped[str | None] = mapped_column(String(50))   # feie / yilianyun / sunmi
    printer_api_url: Mapped[str | None] = mapped_column(Text)
    printer_sn: Mapped[str | None] = mapped_column(String(100))     # 设备编号
    printer_user: Mapped[str | None] = mapped_column(String(100))    # 账号
    printer_ukey: Mapped[str | None] = mapped_column(Text)           # 密钥
    printer_label_width: Mapped[int] = mapped_column(Integer, default=80)  # 标签宽度 mm
    printer_label_height: Mapped[int] = mapped_column(Integer, default=50)  # 标签高度 mm
    # ---- 群机器人 ----
    wecom_bot_enabled: Mapped[bool] = mapped_column(default=False)  # 是否启用群推送
    wecom_webhook_url: Mapped[str | None] = mapped_column(Text)  # 企微群机器人 webhook URL
