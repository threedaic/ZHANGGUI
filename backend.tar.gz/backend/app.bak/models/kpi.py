from sqlalchemy import String, Integer, Float, Text, Boolean, ForeignKey, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import Base, TimestampMixin


class KPITemplate(Base):
    __tablename__ = "kpi_templates"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    store_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("stores.id"))
    role: Mapped[str] = mapped_column(String(30))
    dimension: Mapped[str] = mapped_column(String(50))
    dimension_label: Mapped[str] = mapped_column(String(50))
    weight: Mapped[float] = mapped_column(Float)
    formula_type: Mapped[str] = mapped_column(String(30), default="ratio")
    formula_config: Mapped[str] = mapped_column(Text, default="{}")
    data_source: Mapped[str] = mapped_column(String(50))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[str] = mapped_column(Text, default="")


class KPIScore(Base):
    __tablename__ = "kpi_scores"
    __table_args__ = (UniqueConstraint("employee_id", "period", "dimension"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    employee_id: Mapped[int] = mapped_column(Integer, ForeignKey("employees.id"))
    store_id: Mapped[int] = mapped_column(Integer, ForeignKey("stores.id"))
    period: Mapped[str] = mapped_column(String(7))
    dimension: Mapped[str] = mapped_column(String(50))
    raw_value: Mapped[float | None] = mapped_column(Float)
    raw_description: Mapped[str | None] = mapped_column(Text)
    normalized_score: Mapped[float] = mapped_column(Float)
    weight: Mapped[float] = mapped_column(Float)
    weighted_score: Mapped[float] = mapped_column(Float)
    data_source: Mapped[str | None] = mapped_column(String(50))
    source_reference: Mapped[str | None] = mapped_column(Text)  # JSONB
    calculated_at: Mapped[str] = mapped_column(Text, default="")


class KPIResult(Base):
    __tablename__ = "kpi_results"
    __table_args__ = (UniqueConstraint("employee_id", "period"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    employee_id: Mapped[int] = mapped_column(Integer, ForeignKey("employees.id"))
    store_id: Mapped[int] = mapped_column(Integer, ForeignKey("stores.id"))
    period: Mapped[str] = mapped_column(String(7))
    total_score: Mapped[float] = mapped_column(Float)
    coefficient: Mapped[float] = mapped_column(Float, default=1.00)
    coefficient_reason: Mapped[str | None] = mapped_column(Text)
    rank_in_store: Mapped[int | None] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20), default="pending")
    confirmed_by: Mapped[int | None] = mapped_column(Integer, ForeignKey("users.id"))
    confirmed_at: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[str] = mapped_column(Text, default="")


class KPIAppeal(Base):
    __tablename__ = "kpi_appeals"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    result_id: Mapped[int] = mapped_column(Integer, ForeignKey("kpi_results.id"))
    employee_id: Mapped[int] = mapped_column(Integer, ForeignKey("employees.id"))
    dimension: Mapped[str | None] = mapped_column(String(50))
    reason: Mapped[str] = mapped_column(Text)
    evidence: Mapped[str | None] = mapped_column(Text)  # TEXT[]
    status: Mapped[str] = mapped_column(String(20), default="pending")
    reviewed_by: Mapped[int | None] = mapped_column(Integer, ForeignKey("users.id"))
    resolution: Mapped[str | None] = mapped_column(Text)
    resolved_at: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[str] = mapped_column(Text, default="")
