"""
统一审批模型
涵盖：请假、补卡、调班、加班、报销
"""
from datetime import datetime, date
from sqlalchemy import String, Integer, Date, DateTime, Text, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import Base, TimestampMixin


class ApprovalRequest(TimestampMixin, Base):
    __tablename__ = "approval_requests"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    store_id: Mapped[int] = mapped_column(Integer, ForeignKey("stores.id"))
    employee_id: Mapped[int] = mapped_column(Integer, ForeignKey("employees.id"))

    type: Mapped[str] = mapped_column(String(20))  # leave / makeup / swap / overtime / expense
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending / approved / rejected

    start_date: Mapped[date | None] = mapped_column(Date)
    end_date: Mapped[date | None] = mapped_column(Date)
    reason: Mapped[str | None] = mapped_column(Text)

    # 各类型自定义字段
    extra: Mapped[dict | None] = mapped_column(JSON)

    approver_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("users.id"))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
