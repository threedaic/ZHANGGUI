from sqlalchemy import String, Integer, Float, Text, Boolean, ForeignKey, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import Base


class GuestRating(Base):
    __tablename__ = "guest_ratings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    store_id: Mapped[int] = mapped_column(Integer, ForeignKey("stores.id"))
    table_no: Mapped[str] = mapped_column(String(10))
    food_quality: Mapped[int | None] = mapped_column(Integer)
    food_speed: Mapped[int | None] = mapped_column(Integer)
    drink_quality: Mapped[int | None] = mapped_column(Integer)
    drink_speed: Mapped[int | None] = mapped_column(Integer)
    service_attitude: Mapped[int | None] = mapped_column(Integer)
    service_speed: Mapped[int | None] = mapped_column(Integer)
    cleanliness: Mapped[int | None] = mapped_column(Integer)
    overall_score: Mapped[float] = mapped_column(Float)
    comment: Mapped[str | None] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(20), default="qr_code")
    is_low_score: Mapped[bool] = mapped_column(Boolean, default=False)
    notified: Mapped[bool] = mapped_column(Boolean, default=False)
    notified_at: Mapped[str | None] = mapped_column(Text)
    store_response: Mapped[str | None] = mapped_column(Text)
    response_by: Mapped[int | None] = mapped_column(Integer, ForeignKey("users.id"))
    responded_at: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[str] = mapped_column(Text, default="")

    __table_args__ = (
        CheckConstraint("food_quality IS NULL OR (food_quality >= 1 AND food_quality <= 5)", name="ck_food_quality"),
        CheckConstraint("food_speed IS NULL OR (food_speed >= 1 AND food_speed <= 5)", name="ck_food_speed"),
        CheckConstraint("drink_quality IS NULL OR (drink_quality >= 1 AND drink_quality <= 5)", name="ck_drink_quality"),
        CheckConstraint("drink_speed IS NULL OR (drink_speed >= 1 AND drink_speed <= 5)", name="ck_drink_speed"),
        CheckConstraint("service_attitude IS NULL OR (service_attitude >= 1 AND service_attitude <= 5)", name="ck_service_attitude"),
        CheckConstraint("service_speed IS NULL OR (service_speed >= 1 AND service_speed <= 5)", name="ck_service_speed"),
        CheckConstraint("cleanliness IS NULL OR (cleanliness >= 1 AND cleanliness <= 5)", name="ck_cleanliness"),
    )
