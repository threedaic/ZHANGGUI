from sqlalchemy import String, Integer, Float, ForeignKey, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import Base, TimestampMixin


class LeaveBalance(TimestampMixin, Base):
    __tablename__ = "leave_balances"
    __table_args__ = (UniqueConstraint("employee_id", "year", "leave_type"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    store_id: Mapped[int] = mapped_column(Integer, ForeignKey("stores.id"))
    employee_id: Mapped[int] = mapped_column(Integer, ForeignKey("employees.id"))
    year: Mapped[int] = mapped_column(Integer)
    leave_type: Mapped[str] = mapped_column(String(20))
    total_days: Mapped[float] = mapped_column(Float, default=0)
    used_days: Mapped[float] = mapped_column(Float, default=0)
