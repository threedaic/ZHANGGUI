from sqlalchemy import String, Integer, Float, Text, Boolean, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import Base, TimestampMixin


class TableSession(TimestampMixin, Base):
    __tablename__ = "table_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    store_id: Mapped[int] = mapped_column(Integer, ForeignKey("stores.id"))
    table_no: Mapped[str] = mapped_column(String(10))
    opened_by: Mapped[int] = mapped_column(Integer, ForeignKey("employees.id"))
    opened_at: Mapped[str] = mapped_column(Text, default="")  # TIMESTAMPTZ
    closed_by: Mapped[int | None] = mapped_column(Integer, ForeignKey("employees.id"))
    closed_at: Mapped[str | None] = mapped_column(Text)  # TIMESTAMPTZ
    guest_count: Mapped[int] = mapped_column(Integer, default=1)
    crmeb_order_count: Mapped[int] = mapped_column(Integer, default=0)
    crmeb_total_amount: Mapped[float] = mapped_column(Float, default=0)
    wework_pay_count: Mapped[int] = mapped_column(Integer, default=0)
    wework_pay_amount: Mapped[float] = mapped_column(Float, default=0)
    commission_employee_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("employees.id")
    )
    commission_base: Mapped[float] = mapped_column(Float, default=0)
    commission_amount: Mapped[float] = mapped_column(Float, default=0)
    is_anomaly: Mapped[bool] = mapped_column(Boolean, default=False)
    anomaly_reason: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="open")
    notes: Mapped[str | None] = mapped_column(Text)
