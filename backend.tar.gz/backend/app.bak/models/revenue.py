from app.models.base import Base
from sqlalchemy import String, Integer, Float, Text, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column


class DailyRevenue(Base):
    __tablename__ = "daily_revenue"

    store_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("stores.id"), primary_key=True
    )
    date: Mapped[str] = mapped_column(Text, primary_key=True)  # DATE
    total_revenue: Mapped[float] = mapped_column(Float)
    total_orders: Mapped[int] = mapped_column(Integer, default=0)
    total_guests: Mapped[int] = mapped_column(Integer, default=0)
    avg_order_value: Mapped[float | None] = mapped_column(Float)
    total_discounts: Mapped[float] = mapped_column(Float, default=0)
    bottle_sales: Mapped[float] = mapped_column(Float, default=0)
    card_sales: Mapped[float] = mapped_column(Float, default=0)
    data_source: Mapped[str] = mapped_column(String(30), default="crmeb")
    source_raw: Mapped[str | None] = mapped_column(Text)  # JSONB
    synced_at: Mapped[str] = mapped_column(Text, default="")
