from sqlalchemy import String, Integer, Text, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import Base, TimestampMixin


class WineStorage(TimestampMixin, Base):
    __tablename__ = "wine_storage"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    store_id: Mapped[int] = mapped_column(Integer, ForeignKey("stores.id"))
    customer_name: Mapped[str] = mapped_column(String(50))
    phone: Mapped[str] = mapped_column(String(20))
    wine_name: Mapped[str] = mapped_column(String(100))
    bottle_label: Mapped[str | None] = mapped_column(String(50))
    date_stored: Mapped[str] = mapped_column(Text)  # DATE
    initial_ml: Mapped[int | None] = mapped_column(Integer, default=0)  # 存酒时原始容量，不变
    remaining_ml: Mapped[int | None] = mapped_column(Integer)  # 当前剩余，取酒时递减
    cabinet_no: Mapped[str | None] = mapped_column(String(20))
    table_no: Mapped[str | None] = mapped_column(String(20))  # 取酒时桌号
    status: Mapped[str] = mapped_column(String(20), default="stored")  # stored / retrieved
    retrieved_at: Mapped[str | None] = mapped_column(Text)  # TIMESTAMPTZ
    notes: Mapped[str | None] = mapped_column(Text)
