"""
考勤与排班一体化数据模型

 attendance_records 同时承载：
 - scheduled_shift: 排班（白班/晚班/休息/请假）
 - clock_in/out: 实际打卡
 - status: 最终考勤状态

 班次配置由 shift_configs 表按门店隔离。
"""
from sqlalchemy import String, Integer, Date, Text, Boolean, ForeignKey, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import Base, TimestampMixin


class AttendanceRecord(TimestampMixin, Base):
    __tablename__ = "attendance_records"
    __table_args__ = (UniqueConstraint("employee_id", "date"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    store_id: Mapped[int] = mapped_column(Integer, ForeignKey("stores.id"))
    employee_id: Mapped[int] = mapped_column(Integer, ForeignKey("employees.id"))
    date: Mapped[str] = mapped_column(Date)

    # 排班信息
    scheduled_shift: Mapped[str | None] = mapped_column(String(20))
    shift_start_time: Mapped[str | None] = mapped_column(String(8))
    shift_end_time: Mapped[str | None] = mapped_column(String(8))
    is_overnight: Mapped[bool] = mapped_column(Boolean, default=False)

    # 打卡信息
    clock_in: Mapped[str | None] = mapped_column(Text)  # TIME or ISO datetime
    clock_out: Mapped[str | None] = mapped_column(Text)

    # 考勤判定
    status: Mapped[str] = mapped_column(String(20), default="unknown")
    late_minutes: Mapped[int] = mapped_column(Integer, default=0)
    early_minutes: Mapped[int] = mapped_column(Integer, default=0)

    source: Mapped[str] = mapped_column(String(20), default="manual")
    note: Mapped[str | None] = mapped_column(Text)


class ShiftConfig(TimestampMixin, Base):
    """门店班次配置。每个门店独立，老板在设置中维护。"""

    __tablename__ = "shift_configs"
    __table_args__ = (UniqueConstraint("store_id", "shift_code"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    store_id: Mapped[int] = mapped_column(Integer, ForeignKey("stores.id"))
    shift_code: Mapped[str] = mapped_column(String(20))  # day / night / custom1
    shift_name: Mapped[str] = mapped_column(String(20))  # 白班 / 晚班
    start_time: Mapped[str] = mapped_column(String(8))   # 12:00
    end_time: Mapped[str] = mapped_column(String(8))     # 20:00
    is_overnight: Mapped[bool] = mapped_column(Boolean, default=False)
    color: Mapped[str] = mapped_column(String(8), default="#FB0079")
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
