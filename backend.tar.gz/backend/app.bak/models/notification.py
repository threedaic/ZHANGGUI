"""
统一消息通知模型
"""
from sqlalchemy import String, Integer, Text, Boolean, ForeignKey, JSON, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import Base, TimestampMixin


class Notification(TimestampMixin, Base):
    __tablename__ = "notifications"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    store_id: Mapped[int] = mapped_column(Integer, ForeignKey("stores.id"))
    user_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("users.id"))

    type: Mapped[str] = mapped_column(String(40))  # daily_report / attendance_alert / shift_change / approval / reminder
    title: Mapped[str] = mapped_column(String(200))
    content: Mapped[str] = mapped_column(Text)

    channel: Mapped[str] = mapped_column(String(20), default="in_app")  # in_app / wecom / all
    is_read: Mapped[bool] = mapped_column(Boolean, default=False)
    extra: Mapped[dict | None] = mapped_column(JSON)


class NotificationSetting(TimestampMixin, Base):
    __tablename__ = "notification_settings"
    __table_args__ = (UniqueConstraint("store_id", "setting_key"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    store_id: Mapped[int] = mapped_column(Integer, ForeignKey("stores.id"))

    setting_key: Mapped[str] = mapped_column(String(40))  # daily_report / attendance_alert / shift_change / approval / reminder
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    channel: Mapped[str] = mapped_column(String(20), default="all")  # in_app / wecom / all
    target_roles: Mapped[list[str]] = mapped_column(JSON, default=list)
    schedule_time: Mapped[str | None] = mapped_column(String(8))  # 23:00
