"""
合同系统数据模型

salary_matrix: 薪资矩阵（5岗位 x 4档）
contracts:     员工劳动合同
"""
from datetime import date, datetime
from sqlalchemy import (
    String, Integer, Float, Date, DateTime, Text,
    ForeignKey, JSON, Boolean, UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import Base, TimestampMixin


class SalaryMatrix(Base):
    """薪资矩阵表：5岗位 x 4档 薪资标准"""

    __tablename__ = "salary_matrix"
    __table_args__ = (
        UniqueConstraint("position", "grade", name="uq_salary_matrix_position_grade"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    position: Mapped[str] = mapped_column(
        String(30), comment="岗位: 店长/吧员/服务员/厨师/保洁"
    )
    grade: Mapped[str] = mapped_column(
        String(20), comment="职档: 学徒/正式/副职/正职"
    )
    monthly_salary: Mapped[float] = mapped_column(
        Float, comment="月薪总额"
    )
    base_salary: Mapped[float] = mapped_column(
        Float, default=3000.0, comment="基本工资，固定3000"
    )
    meal_allowance: Mapped[float] = mapped_column(
        Float, default=400.0, comment="餐补"
    )
    is_active: Mapped[bool] = mapped_column(
        Boolean, default=True, comment="是否启用"
    )


class Contract(TimestampMixin, Base):
    """劳动合同表"""

    __tablename__ = "contracts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    store_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("stores.id", ondelete="CASCADE")
    )
    employee_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("employees.id", ondelete="CASCADE")
    )
    contract_no: Mapped[str] = mapped_column(
        String(50), unique=True, comment="合同编号"
    )
    position: Mapped[str] = mapped_column(
        String(30), comment="岗位"
    )
    grade: Mapped[str] = mapped_column(
        String(20), comment="职档"
    )
    monthly_salary: Mapped[float] = mapped_column(
        Float, comment="月薪总额"
    )
    base_salary: Mapped[float] = mapped_column(
        Float, default=3000.0, comment="基本工资"
    )
    meal_allowance: Mapped[float] = mapped_column(
        Float, default=400.0, comment="餐补"
    )
    allowance: Mapped[float] = mapped_column(
        Float, default=0.0, comment="补贴 = 月薪 - 基本工资"
    )
    start_date: Mapped[date] = mapped_column(
        Date, comment="合同开始日期"
    )
    end_date: Mapped[date | None] = mapped_column(
        Date, nullable=True, comment="合同结束日期"
    )
    status: Mapped[str] = mapped_column(
        String(30), default="draft",
        comment="draft/pending_sign/signed/expired/terminated"
    )
    esign_flow_id: Mapped[str | None] = mapped_column(
        String(100), nullable=True, comment="腾讯电子签流程 ID"
    )
    signed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True, comment="签署完成时间"
    )
    signed_by: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("users.id"), nullable=True, comment="签署人 user_id"
    )
    template_data: Mapped[dict | None] = mapped_column(
        JSON, nullable=True, comment="模板填充的完整字段（20+字段）"
    )
    created_by: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("users.id"), nullable=True, comment="创建人"
    )
