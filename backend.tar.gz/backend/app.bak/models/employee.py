from sqlalchemy import String, Integer, Float, Date, Text, ForeignKey, Boolean, ARRAY
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import Base, TimestampMixin


class Employee(TimestampMixin, Base):
    __tablename__ = "employees"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    store_id: Mapped[int] = mapped_column(Integer, ForeignKey("stores.id", ondelete="CASCADE"))
    employee_code: Mapped[str] = mapped_column(String(20), unique=True)
    name: Mapped[str] = mapped_column(String(50))
    phone: Mapped[str | None] = mapped_column(String(20))
    role: Mapped[str] = mapped_column(String(30))
    base_salary: Mapped[float] = mapped_column(Float)
    hire_date: Mapped[str] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(20), default="active")
    wework_userid: Mapped[str | None] = mapped_column(String(100))
    skill_tags: Mapped[str | None] = mapped_column(ARRAY(Text))
    is_first_manager: Mapped[bool] = mapped_column(Boolean, default=False)
    is_second_manager: Mapped[bool] = mapped_column(Boolean, default=False)
    is_third_manager: Mapped[bool] = mapped_column(Boolean, default=False)
    shift_group: Mapped[str | None] = mapped_column(String(10), nullable=True, comment="排班组: day=白班组, night=夜班组, null=夜班(默认)")
    notes: Mapped[str | None] = mapped_column(Text)
