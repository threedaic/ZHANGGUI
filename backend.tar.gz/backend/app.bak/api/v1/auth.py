from fastapi import APIRouter, Depends, Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models.user import User
from app.models.employee import Employee
from app.schemas.auth import LoginRequest, TokenResponse, RefreshRequest, UserInfo
from app.utils.security import verify_password, create_access_token, create_refresh_token, decode_token, is_token_blacklisted
from app.utils.exceptions import UnauthorizedError, ForbiddenError

router = APIRouter()


@router.post("/login", response_model=dict)
async def login(body: LoginRequest, request: Request, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.username == body.username))
    user = result.scalar_one_or_none()

    if not user or not verify_password(body.password, user.password_hash):
        raise UnauthorizedError("用户名或密码错误")

    if not user.is_active:
        raise ForbiddenError("账户已被禁用")

    # Look up store from employee record
    store_id = None
    if user.employee_id:
        emp_result = await db.execute(select(Employee).where(Employee.id == user.employee_id))
        emp = emp_result.scalar_one_or_none()
        if emp:
            store_id = emp.store_id
    token_data = {
        "user_id": user.id,
        "username": user.username,
        "role": user.role,
        "employee_id": user.employee_id,
        "store_id": store_id,
    }

    access_token = create_access_token(token_data)
    refresh_token = create_refresh_token(token_data)

    return {
        "code": 0,
        "message": "ok",
        "data": {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer",
            "must_change_password": user.must_change_password,
        },
    }


@router.post("/refresh", response_model=dict)
async def refresh(body: RefreshRequest):
    # 1. Decode token
    payload = decode_token(body.refresh_token)
    if payload.get("type") != "refresh":
        raise UnauthorizedError("无效的 refresh token")

    # 2. Check blacklist (M-001 fix)
    if await is_token_blacklisted(body.refresh_token):
        raise UnauthorizedError("token 已被登出")

    token_data = {
        "user_id": payload.get("user_id"),
        "username": payload.get("username"),
        "role": payload.get("role"),
        "employee_id": payload.get("employee_id"),
        "store_id": payload.get("store_id"),
    }
    access_token = create_access_token(token_data)

    return {
        "code": 0,
        "message": "ok",
        "data": {
            "access_token": access_token,
            "token_type": "bearer",
        },
    }


@router.get("/me", response_model=dict)
async def get_me(request: Request):
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise UnauthorizedError("未登录")

    payload = decode_token(auth_header[7:])
    if not payload:
        raise UnauthorizedError("token 无效")

    return {
        "code": 0,
        "message": "ok",
        "data": {
            "user_id": payload.get("user_id"),
            "username": payload.get("username"),
            "role": payload.get("role"),
            "employee_id": payload.get("employee_id"),
            "store_id": payload.get("store_id"),
        },
    }


# ==================== 企微 OAuth 免登录 ====================

@router.get("/wework/login")
async def wework_login(request: Request, db: AsyncSession = Depends(get_db)):
    """企微 OAuth 回调。从 code 获取用户身份，自动登录。

    企微配置: 应用主页 → 网页授权回调域名 → zhanggui.crushserver.cloud
    OAuth 入口: https://open.weixin.qq.com/connect/oauth2/authorize?
        appid=CORPID&redirect_uri=URL&response_type=code&scope=snsapi_base&state=#wechat_redirect
    """
    from fastapi.responses import RedirectResponse
    import json as _json

    code = request.query_params.get("code")
    if not code:
        return RedirectResponse(url="/login")

    # 从 stores 表获取企微配置
    from app.models.store import Store
    result = await db.execute(select(Store).order_by(Store.id.asc()).limit(1))
    store = result.scalar_one_or_none()
    if not store or not store.wework_corp_id:
        return RedirectResponse(url="/login?error=config")

    # 用 code 换取企微 userid
    from app.services.wework import get_access_token
    try:
        access_token = await get_access_token(db, store.id)
    except Exception:
        return RedirectResponse(url="/login?error=token")

    import urllib.request, urllib.parse
    info_url = f"https://qyapi.weixin.qq.com/cgi-bin/user/getuserinfo?access_token={access_token}&code={code}"
    try:
        resp = urllib.request.urlopen(info_url)
        info = _json.loads(resp.read())
    except Exception:
        return RedirectResponse(url="/login?error=network")

    if info.get("errcode", 0) != 0:
        return RedirectResponse(url="/login?error=oauth_fail")

    wework_userid = info.get("UserId") or info.get("userid")
    if not wework_userid:
        return RedirectResponse(url="/login?error=no_user")

    # 根据 wework_userid 查本地员工
    emp_result = await db.execute(
        select(Employee).where(Employee.wework_userid == wework_userid)
    )
    emp = emp_result.scalar_one_or_none()
    if not emp:
        return RedirectResponse(url=f"/login?error=not_found&uid={wework_userid}")

    # 查或建用户账号
    user_result = await db.execute(select(User).where(User.employee_id == emp.id))
    user = user_result.scalar_one_or_none()
    if not user:
        from app.utils.security import hash_password
        import secrets
        user = User(
            employee_id=emp.id,
            username=emp.name,
            password_hash=hash_password(secrets.token_urlsafe(16)),
            role=emp.role,
            is_active=True,
        )
        db.add(user)
        await db.flush()
    elif user.role != emp.role:
        # 每次 OAuth 登录时间步角色（同步后角色变更即时生效）
        user.role = emp.role
        await db.flush()

    # 签发 JWT
    token_data = {
        "user_id": user.id,
        "username": user.username,
        "role": user.role,
        "employee_id": emp.id,
        "store_id": emp.store_id,
    }
    access_token_str = create_access_token(token_data)
    refresh_token_str = create_refresh_token(token_data)

    await db.commit()

    frontend_url = (
        f"/auth-callback"
        f"?access_token={access_token_str}"
        f"&refresh_token={refresh_token_str}"
        f"&role={user.role}"
    )
    return RedirectResponse(url=frontend_url)
