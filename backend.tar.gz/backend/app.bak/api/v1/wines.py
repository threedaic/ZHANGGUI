"""
存酒管理 API 路由
前缀: /api/v1
"""
from fastapi import APIRouter, Depends, Request, Query
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.schemas.wine import (
    WineCreate,
    WineResponse,
    WineStaffRetrieve,
    WineSelfRetrieve,
    WineRetrieveResponse,
    WineH5Info,
    WineH5ConfirmRequest,
    InventoryCheckItem,
    WineBatchCreate,
)
from app.repositories.wine import WineRepository
from app.services.wine import store_wine, staff_retrieve, self_retrieve
from app.utils.pagination import PageParams, PageResult
from app.utils.exceptions import NotFoundError, ForbiddenError
from loguru import logger

router = APIRouter()


def _get_store_id(request: Request) -> int:
    store_id = getattr(request.state, "store_id", None)
    if store_id is None:
        raise ForbiddenError("无法获取门店信息")
    return store_id


# ==================== 存酒 ====================

@router.post("/wines")
async def create_wine(body: WineCreate, request: Request, db: AsyncSession = Depends(get_db)):
    """服务员存酒：填表 → 出标签 + 发短信"""
    store_id = _get_store_id(request)
    try:
        wine = await store_wine(
            session=db, store_id=store_id,
            customer_name=body.customer_name,
            phone=body.phone,
            wine_name=body.wine_name,
            remaining_ml=body.remaining_ml,
            quantity=body.quantity,
            cabinet_no=body.cabinet_no,
            notes=body.notes,
        )
        await db.commit()
        return {"code": 0, "message": "ok", "data": WineResponse.model_validate(wine).model_dump()}
    except Exception as e:
        logger.error(f"存酒失败: {e}", exc_info=True)
        await db.rollback()
        return {"code": 500, "message": f"服务器错误: {str(e)}", "data": None}


@router.post("/wines/batch")
async def create_wine_batch(body: WineBatchCreate, request: Request, db: AsyncSession = Depends(get_db)):
    """一次存多种酒：客人信息共享，每种酒独立酒名/容量/数量"""
    store_id = _get_store_id(request)
    try:
        results = []
        for item in body.wines:
            for _ in range(max(item.quantity, 1)):
                wine = await store_wine(
                    session=db, store_id=store_id,
                    customer_name=body.customer_name,
                    phone=body.phone,
                    wine_name=item.wine_name,
                    remaining_ml=item.remaining_ml,
                    quantity=1,
                    notes=body.notes,
                )
                results.append(wine)
        await db.commit()
        return {
            "code": 0, "message": "ok",
            "data": {
                "count": len(results),
                "bottle_labels": [w.bottle_label for w in results],
            },
        }
    except Exception as e:
        logger.error(f"批量存酒失败: {e}", exc_info=True)
        await db.rollback()
        return {"code": 500, "message": f"服务器错误: {str(e)}", "data": None}


# ==================== 列表查询 ====================

@router.get("/wines")
async def list_wines(
    request: Request,
    status: str | None = Query(None),
    keyword: str | None = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    """存酒列表，支持状态筛选、关键词搜索、分页"""
    store_id = _get_store_id(request)
    repo = WineRepository(db, store_id)
    items, total = await repo.list_wines(
        status=status,
        keyword=keyword,
        params=PageParams(page=page, page_size=page_size),
    )
    result = PageResult(
        items=[WineResponse.model_validate(w).model_dump() for w in items],
        total=total,
        page=page,
        page_size=page_size,
        total_pages=(total + page_size - 1) // page_size,
    )
    return {"code": 0, "message": "ok", "data": result.model_dump()}


# ==================== H5 查酒信息（公开） ====================

@router.get("/wines/h5/{bottle_label}")
async def h5_wine_info(bottle_label: str, db: AsyncSession = Depends(get_db)):
    """客人点短信链接打开 H5 页面，查存酒信息。无需登录。"""
    from sqlalchemy import select
    from app.models.wine_storage import WineStorage
    stmt = select(WineStorage).where(WineStorage.bottle_label == bottle_label)
    result = await db.execute(stmt)
    wine = result.scalar_one_or_none()

    if not wine:
        raise NotFoundError("未找到该存酒记录")

    return {
        "code": 0,
        "message": "ok",
        "data": WineH5Info.model_validate(wine).model_dump(),
    }


# ==================== H5 客人自助取酒 ====================

@router.post("/wines/h5/confirm")
async def h5_confirm_retrieve(body: WineH5ConfirmRequest, db: AsyncSession = Depends(get_db)):
    """客人自助取酒：选取出量 + 桌号 → 扣减 → 云打印机出小票"""
    wine = await self_retrieve(
        session=db,
        bottle_label=body.bottle_label,
        retrieve_ml=body.retrieve_ml,
        table_no=body.table_no,
    )
    await db.commit()
    return {
        "code": 0,
        "message": "已通知服务员，请稍候",
        "data": {"bottle_label": body.bottle_label, "status": wine.status, "remaining_ml": wine.remaining_ml},
    }


# ==================== 公开：客人查自己的存酒 ====================

@router.get("/wines/guest")
async def guest_my_wines(phone: str = Query(...), db: AsyncSession = Depends(get_db)):
    """
    客人输入手机号查看所有存酒。公开接口，无需登录。
    用于公众号菜单页面。
    """
    from sqlalchemy import select
    from app.models.wine_storage import WineStorage
    stmt = select(WineStorage).where(WineStorage.phone == phone).order_by(WineStorage.date_stored.desc())
    result = await db.execute(stmt)
    wines = result.scalars().all()

    return {
        "code": 0,
        "message": "ok",
        "data": [
            {
                "bottle_label": w.bottle_label,
                "wine_name": w.wine_name,
                "initial_ml": w.initial_ml,
                "remaining_ml": w.remaining_ml,
                "date_stored": w.date_stored,
                "status": w.status,
            }
            for w in wines
        ],
    }


# ==================== 服务员取酒 ====================

@router.post("/wines/retrieve")
async def retrieve_wine_api(
    body: WineStaffRetrieve,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """服务员取酒：输瓶身码 + 取酒量 + 桌号 → 扣减 → 发短信"""
    store_id = _get_store_id(request)
    wine = await staff_retrieve(
        session=db,
        store_id=store_id,
        bottle_label=body.bottle_label,
        retrieve_ml=body.retrieve_ml,
        table_no=body.table_no,
    )
    await db.commit()
    return {"code": 0, "message": "ok", "data": WineRetrieveResponse.model_validate(wine).model_dump()}


# ==================== 盘点 ====================

@router.get("/wines/inventory/summary")
async def inventory_summary(request: Request, db: AsyncSession = Depends(get_db)):
    """存酒盘点汇总"""
    store_id = _get_store_id(request)
    repo = WineRepository(db, store_id)
    summary = await repo.get_inventory()
    return {"code": 0, "message": "ok", "data": summary}


@router.get("/wines/inventory/items")
async def inventory_items(
    request: Request,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    """盘点明细：所有在存状态"""
    store_id = _get_store_id(request)
    repo = WineRepository(db, store_id)
    items, total = await repo.list_wines(
        status="stored",
        params=PageParams(page=page, page_size=page_size),
    )
    result = PageResult(
        items=[InventoryCheckItem(
            bottle_label=w.bottle_label,
            customer_name=w.customer_name,
            wine_name=w.wine_name,
            remaining_ml=w.remaining_ml,
            status=w.status,
        ).model_dump() for w in items],
        total=total,
        page=page,
        page_size=page_size,
        total_pages=(total + page_size - 1) // page_size,
    )
    return {"code": 0, "message": "ok", "data": result.model_dump()}


# ==================== 详情 ====================

@router.get("/wines/{wine_id}")
async def get_wine(wine_id: int, request: Request, db: AsyncSession = Depends(get_db)):
    """单条存酒记录详情"""
    store_id = _get_store_id(request)
    repo = WineRepository(db, store_id)
    wine = await repo.get_by_id(wine_id)
    if not wine:
        raise NotFoundError("存酒记录不存在")
    return {"code": 0, "message": "ok", "data": WineResponse.model_validate(wine).model_dump()}
