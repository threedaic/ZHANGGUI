"""
工资计算 API 路由
/api/v1/payroll/

GET    /monthly        月度工资汇总
GET    /records/{id}   工资详情
POST   /generate       生成工资
POST   /finalize       确认工资条
POST   /mark-paid      标记已发放
"""
from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas.auth import APIResponse
from app.schemas.payroll import (
    PayrollGenerateRequest,
    PayrollFinalizeRequest,
    PayrollMarkPaidRequest,
)
from app.services.payroll import PayrollService
from app.utils.deps import get_store_id, require_role, get_employee_id, require_employee_id

router = APIRouter()


# ==================== 工资生成 ====================

@router.post("/generate", summary="生成月度工资(店长)")
async def generate_payroll(
    request: Request,
    body: PayrollGenerateRequest,
    db: AsyncSession = Depends(get_db),
):
    require_role(request, ["boss", "store_manager"])
    store_id = get_store_id(request)
    service = PayrollService(db, store_id)
    records = await service.generate(body.period, body.employee_ids)

    return APIResponse(
        message=f"已生成 {len(records)} 条工资记录",
        data={
            "period": body.period,
            "count": len(records),
            "employees": [
                {"employee_id": r.employee_id, "net_pay": r.net_pay, "status": r.status}
                for r in records
            ],
        },
    )


# ==================== 工资查询 ====================

@router.get("/monthly", summary="门店月度工资汇总")
async def list_monthly(
    request: Request,
    period: str = Query(..., description="月份 2026-06"),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    store_id = get_store_id(request)
    service = PayrollService(db, store_id)
    data = await service.get_monthly(period=period, page=page, page_size=page_size)
    return APIResponse(data=data)


@router.get("/records/{record_id}", summary="工资记录详情")
async def get_record(
    request: Request,
    record_id: int,
    db: AsyncSession = Depends(get_db),
):
    store_id = get_store_id(request)
    service = PayrollService(db, store_id)
    data = await service.get_detail(record_id)
    return APIResponse(data=data)


@router.get("/my", summary="员工查看自己的工资")
async def my_payroll(
    request: Request,
    period: str | None = Query(None),
    db: AsyncSession = Depends(get_db),
):
    employee_id = require_employee_id(request)
    store_id = get_store_id(request)
    service = PayrollService(db, store_id)

    from app.utils.pagination import PageParams
    repo = service.repo
    params = PageParams(page=1, page_size=50)
    records, total = await repo.get_records(
        employee_id=employee_id, period=period, page=params
    )

    if not records:
        return APIResponse(data=[])

    emp_info = await repo.get_employee_info([employee_id])
    emp = emp_info.get(employee_id, {"name": "", "role": ""})

    items = []
    for r in records:
        items.append({
            "id": r.id,
            "employee_id": r.employee_id,
            "period": r.period,
            "base_salary": r.base_salary,
            "kpi_coefficient": r.kpi_coefficient,
            "commission_total": r.commission_total,
            "deduction_total": r.deduction_total,
            "net_pay": r.net_pay,
            "status": r.status,
            "generated_at": r.generated_at,
            "finalized_at": r.finalized_at,
            "paid_at": r.paid_at,
            "employee_name": emp["name"],
            "employee_role": emp["role"],
        })

    return APIResponse(data=items)


# ==================== 工资确认 ====================

@router.post("/finalize", summary="确认工资条(店长)")
async def finalize_payroll(
    request: Request,
    body: PayrollFinalizeRequest,
    db: AsyncSession = Depends(get_db),
):
    require_role(request, ["boss", "store_manager"])
    store_id = get_store_id(request)
    issuer_id = require_employee_id(request)
    service = PayrollService(db, store_id)
    count = await service.finalize(body.record_ids, body.notes)

    # 为每位员工创建签收任务
    from app.services.sign_task import SignTaskService
    sign_service = SignTaskService(db, store_id)
    tasks_created = 0
    try:
        for record_id in body.record_ids:
            record = await service.repo.get_record_by_id(record_id)
            if record:
                period_label = record.period.replace("-", "年") + "月"
                emp_id = record.employee_id
                # 查员工姓名
                from sqlalchemy import select
                from app.models.employee import Employee
                emp_result = await db.execute(
                    select(Employee.name).where(Employee.id == emp_id)
                )
                emp_name = emp_result.scalar_one_or_none() or f"员工{emp_id}"
                title = f"工资单 - {period_label}"

                await sign_service.create_task(
                    employee_id=emp_id,
                    task_type="salary_slip",
                    title=title,
                    ref_type="payroll_record",
                    ref_id=record.id,
                    issued_by=issuer_id,
                    extra={
                        "period": record.period,
                        "net_pay": record.net_pay,
                        "employee_name": emp_name,
                    },
                )
                tasks_created += 1
    except Exception as e:
        from loguru import logger
        logger.warning(f"工资单签收任务创建部分失败: {e}")

    return APIResponse(message=f"已确认 {count} 条工资记录，{tasks_created} 个签收任务已推送")


@router.post("/mark-paid", summary="标记已发放(店长)")
async def mark_paid(
    request: Request,
    body: PayrollMarkPaidRequest,
    db: AsyncSession = Depends(get_db),
):
    require_role(request, ["boss", "store_manager"])
    store_id = get_store_id(request)
    service = PayrollService(db, store_id)
    count = await service.mark_paid(body.record_ids, body.paid_at)
    return APIResponse(message=f"已标记 {count} 条工资为已发放")
