"""
统一审批 API

路由映射：
GET  /              审批列表
POST /              发起审批
GET  /{approval_id} 审批详情
PUT  /{approval_id}/approve 审批通过
PUT  /{approval_id}/reject  审批驳回
"""
from datetime import date
from fastapi import APIRouter, Depends, Request, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.services.approval_service import ApprovalService
from app.repositories.approval import ApprovalRepository
from app.schemas.approval import ApprovalCreateRequest, ApprovalReviewRequest
from app.utils.deps import get_store_id, get_user_id, get_employee_id, require_role, make_response
from app.utils.pagination import PageParams, paginate
from app.utils.exceptions import ValidationError

router = APIRouter()


TYPE_LABELS = {
    "leave": "请假",
    "makeup": "补卡",
    "swap": "调班",
    "overtime": "加班",
    "expense": "报销",
}


def _approval_to_dict(approval, name_map: dict) -> dict:
    return {
        "id": approval.id,
        "employee_id": approval.employee_id,
        "employee_name": name_map.get(approval.employee_id, ""),
        "type": approval.type,
        "type_label": TYPE_LABELS.get(approval.type, approval.type),
        "status": approval.status,
        "start_date": str(approval.start_date) if approval.start_date else None,
        "end_date": str(approval.end_date) if approval.end_date else None,
        "reason": approval.reason,
        "extra": approval.extra,
        "created_at": str(approval.created_at) if approval.created_at else None,
    }


@router.get("")
async def list_approvals(
    request: Request,
    status: str | None = Query(None, description="pending/approved/rejected"),
    approval_type: str | None = Query(None, alias="type"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    """审批列表（员工看自己，店长/老板看全店）"""
    store_id = get_store_id(request)
    role = getattr(request.state, "role", "staff")
    employee_id = getattr(request.state, "employee_id", None)

    repo = ApprovalRepository(db, store_id)
    params = PageParams(page=page, page_size=page_size)

    query_employee_id = None
    if role not in ("boss", "store_manager"):
        query_employee_id = employee_id

    approvals, total = await repo.list_approvals(
        employee_id=query_employee_id,
        status=status,
        approval_type=approval_type,
        page=params,
    )

    emp_ids = list(set(a.employee_id for a in approvals))
    name_map = await repo.get_employee_name_map(emp_ids)

    items = [_approval_to_dict(a, name_map) for a in approvals]
    result = paginate(items, total, params)
    return make_response(request=request, data=result.model_dump())


@router.post("")
async def create_approval(
    request: Request,
    body: ApprovalCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    """发起审批"""
    store_id = get_store_id(request)
    employee_id = get_employee_id(request)

    start_date = date.fromisoformat(body.start_date) if body.start_date else None
    end_date = date.fromisoformat(body.end_date) if body.end_date else None

    svc = ApprovalService(db, store_id)
    approval = await svc.create_approval(
        employee_id=employee_id,
        approval_type=body.type,
        start_date=start_date,
        end_date=end_date,
        reason=body.reason,
        extra=body.extra,
    )

    name_map = await svc.repo.get_employee_name_map([approval.employee_id])
    return make_response(
        request=request,
        message="审批已提交",
        data=_approval_to_dict(approval, name_map),
    )


@router.get("/{approval_id}")
async def get_approval(
    request: Request,
    approval_id: int,
    db: AsyncSession = Depends(get_db),
):
    """审批详情"""
    store_id = get_store_id(request)
    repo = ApprovalRepository(db, store_id)
    approval = await repo.get_approval_by_id(approval_id)
    if not approval:
        from app.utils.exceptions import NotFoundError
        raise NotFoundError("审批记录不存在")
    name_map = await repo.get_employee_name_map([approval.employee_id])
    return make_response(request=request, data=_approval_to_dict(approval, name_map))


@router.put("/{approval_id}/approve")
async def approve_approval(
    request: Request,
    approval_id: int,
    db: AsyncSession = Depends(get_db),
):
    """审批通过"""
    require_role(request, ["boss", "store_manager"])
    store_id = get_store_id(request)
    user_id = get_user_id(request)

    svc = ApprovalService(db, store_id)
    approval = await svc.approve(approval_id, user_id)
    name_map = await svc.repo.get_employee_name_map([approval.employee_id])
    return make_response(request=request, message="审批已通过", data=_approval_to_dict(approval, name_map))


@router.put("/{approval_id}/reject")
async def reject_approval(
    request: Request,
    approval_id: int,
    db: AsyncSession = Depends(get_db),
):
    """审批驳回"""
    require_role(request, ["boss", "store_manager"])
    store_id = get_store_id(request)
    user_id = get_user_id(request)

    svc = ApprovalService(db, store_id)
    approval = await svc.reject(approval_id, user_id)
    name_map = await svc.repo.get_employee_name_map([approval.employee_id])
    return make_response(request=request, message="审批已驳回", data=_approval_to_dict(approval, name_map))
