from contextlib import asynccontextmanager
from datetime import date
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import select, text
from loguru import logger
from app.config import get_settings
from app.database import engine, AsyncSessionLocal
from app.models import Base
from app.models.user import User
from app.models.company import Company
from app.models.store import Store
from app.utils.security import hash_password
from app.utils.redis_client import init_redis, close_redis
from app.utils.exceptions import AppError
from app.utils.exceptions import app_error_handler, unhandled_error_handler
from app.api.v1.auth import router as auth_router
from app.api.v1.kpi import router as kpi_router
from app.api.v1.schedules import router as schedule_router
from app.api.v1.wines import router as wines_router
from app.api.v1.tables import router as tables_router
from app.api.v1.bookings import router as bookings_router
from app.api.v1.attendance import router as attendance_router
from app.api.v1.approval import router as approval_router
from app.api.v1.notifications import router as notification_router
from app.api.v1.contracts import router as contracts_router
from app.api.v1.antifraud import router as antifraud_router
from app.api.v1.payroll import router as payroll_router
from app.api.v1.dashboard import router as dashboard_router
from app.api.v1.ai import router as ai_router
from app.api.v1.ratings import router as ratings_router
from app.api.v1.leaves import router as leaves_router
from app.api.v1.store import router as store_router
from app.api.v1.audit import router as audit_router
from app.api.v1.butler import router as butler_router
from app.api.v1.sign_tasks import router as sign_tasks_router
from app.api.v1.penalties import router as penalties_router
from app.middleware.rls import RLSMiddleware
from app.middleware.audit import AuditMiddleware
from app.middleware.rate_limit import RateLimitMiddleware
from app.tasks.scheduler import init_scheduler, shutdown_scheduler

import os

# Log path configurable via environment (m-008 fix)
_log_path = os.getenv("LOG_PATH", "logs/crush-zhanggui.log")
logger.add(_log_path, rotation="10 MB", retention="7 days")

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: create tables + seed data + connect Redis + start scheduler
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        await seed_default_data(conn)
    await init_redis()
    await init_scheduler()
    from app.utils.audit_logger import init_audit_logger
    init_audit_logger()
    logger.info(f"{settings.APP_NAME} v{settings.APP_VERSION} started")
    yield
    # Shutdown
    shutdown_scheduler()
    from app.utils.http_client import http_client
    await http_client.close()
    await close_redis()
    await engine.dispose()


async def seed_default_data(conn):
    """Insert demo data if tables are empty."""
    result = await conn.execute(select(User).limit(1))
    if result.scalar_one_or_none() is not None:
        return

    # Company
    await conn.execute(
        text(
            "INSERT INTO companies (name, brand, tax_id, status) "
            "VALUES ('北京跨时餐饮有限公司', 'Crush', '91110105MADYP9JH2X', 'active')"
        )
    )

    # Store
    await conn.execute(
        text(
            "INSERT INTO stores (company_id, name, store_code, address, city, status) "
            "VALUES (1, '北京三里屯店', 'BJ-SLT-001', "
            "'北京市朝阳区工人体育场北路4号80号楼一层113室', '北京', 'active')"
        )
    )

    # Admin user (boss role) — must change password on first login
    await conn.execute(
        text(
            "INSERT INTO users (username, password_hash, role, is_active, must_change_password) "
            "VALUES (:u, :p, 'boss', true, true)"
        ),
        {
            "u": settings.SEED_BOSS_USERNAME,
            "p": hash_password(settings.SEED_BOSS_PASSWORD),
        }
    )
    await conn.commit()

    # Seed default butler checklists for store_id=1
    await seed_default_checklists(conn)


async def seed_default_checklists(conn):
    """Insert default butler checklists if none exist for store_id=1."""
    result = await conn.execute(
        text("SELECT id FROM closing_checklist_templates WHERE store_id = 1 LIMIT 1")
    )
    if result.scalar_one_or_none() is not None:
        return

    default_templates = [
        {
            "name": "店长闭店检查单",
            "session_type": "closing",
            "role_tag": "store_manager",
            "sort_order": 1,
            "items": [
                ("确认所有客人已离场", "photo"),
                ("检查洗手间是否有人", "checkbox"),
                ("核对当日营业额", "checkbox"),
                ("现金存入保险柜", "checkbox"),
                ("锁闭大门", "photo"),
                ("关闭所有灯光", "photo"),
                ("关闭音响", "photo"),
                ("关闭招牌", "photo"),
                ("检查后厨是否关闭", "photo"),
                ("设防/开启警报", "checkbox"),
            ],
        },
        {
            "name": "吧台长闭店检查单",
            "session_type": "closing",
            "role_tag": "bartender",
            "sort_order": 2,
            "items": [
                ("清空冰槽（烧冰）", "photo"),
                ("清洁吧台台面", "photo"),
                ("清洁苏打枪", "photo"),
                ("储存剩余水果和装饰物", "photo"),
                ("新开酒瓶标注日期", "photo"),
                ("清洗杯具并晾干", "photo"),
                ("清洁地面和地漏", "photo"),
                ("倒垃圾", "photo"),
            ],
        },
        {
            "name": "服务员闭店检查单",
            "session_type": "closing",
            "role_tag": "server",
            "sort_order": 3,
            "items": [
                ("清理所有桌面", "photo"),
                ("椅子归位", "photo"),
                ("扫地", "photo"),
                ("拖地", "photo"),
                ("清空垃圾桶并换袋", "photo"),
                ("清洁卫生间", "photo"),
            ],
        },
        {
            "name": "店长开店检查单",
            "session_type": "opening",
            "role_tag": "store_manager",
            "sort_order": 1,
            "items": [
                ("开门前检查门外是否有杂物", "photo"),
                ("检查店内是否有异常（异味、漏水等）", "checkbox"),
                ("开启灯光", "photo"),
                ("开启音响", "photo"),
                ("开启招牌灯", "photo"),
                ("检查POS机是否正常", "photo"),
                ("准备现金抽屉", "checkbox"),
                ("开晨会/班前会", "checkbox"),
            ],
        },
    ]

    for tpl in default_templates:
        result = await conn.execute(
            text(
                "INSERT INTO closing_checklist_templates (store_id, name, session_type, role_tag, sort_order, is_active) "
                "VALUES (1, :name, :session_type, :role_tag, :sort_order, true) RETURNING id"
            ),
            {
                "name": tpl["name"],
                "session_type": tpl["session_type"],
                "role_tag": tpl["role_tag"],
                "sort_order": tpl["sort_order"],
            },
        )
        tpl_id = result.scalar_one()

        for i, (item_name, item_type) in enumerate(tpl["items"]):
            await conn.execute(
                text(
                    "INSERT INTO closing_checklist_items (template_id, item_name, item_type, required_photo, sort_order) "
                    "VALUES (:template_id, :item_name, :item_type, :required_photo, :sort_order)"
                ),
                {
                    "template_id": tpl_id,
                    "item_name": item_name,
                    "item_type": item_type,
                    "required_photo": item_type == "photo",
                    "sort_order": i + 1,
                },
            )
    await conn.commit()


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    lifespan=lifespan,
)

# Middleware: order matters
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
    allow_headers=["Authorization", "Content-Type", "X-Request-ID"],
)
app.add_middleware(GZipMiddleware, minimum_size=1024)
app.add_middleware(RateLimitMiddleware)
app.add_middleware(RLSMiddleware)
app.add_middleware(AuditMiddleware)

# Exception handlers
app.add_exception_handler(AppError, app_error_handler)
app.add_exception_handler(Exception, unhandled_error_handler)

# Request body size limit (I-002: 10 MB max)
MAX_BODY_SIZE = 10 * 1024 * 1024

@app.middleware("http")
async def limit_body_size(request: Request, call_next):
    content_length = request.headers.get("content-length")
    if content_length and int(content_length) > MAX_BODY_SIZE:
        return JSONResponse(
            status_code=413,
            content={"code": 41300, "message": "请求体过大，最大 10 MB", "data": None, "request_id": None},
        )
    return await call_next(request)

# Routes
app.include_router(auth_router, prefix="/api/v1/auth", tags=["auth"])
app.include_router(kpi_router, prefix="/api/v1/kpi", tags=["KPI考核"])
app.include_router(schedule_router, prefix="/api/v1/schedules", tags=["排班管理"])
app.include_router(wines_router, prefix="/api/v1", tags=["存酒管理"])
app.include_router(tables_router, prefix="/api/v1/tables", tags=["桌位管理"])
app.include_router(bookings_router, prefix="/api/v1/bookings", tags=["订桌预约"])
app.include_router(ratings_router, prefix="/api/v1/ratings", tags=["桌面评分码"])
app.include_router(attendance_router, prefix="/api/v1/attendance", tags=["考勤管理"])
app.include_router(approval_router, prefix="/api/v1/approvals", tags=["审批管理"])
app.include_router(notification_router, prefix="/api/v1/notifications", tags=["消息通知"])
app.include_router(contracts_router, prefix="/api/v1/contracts", tags=["合同系统"])
app.include_router(antifraud_router, prefix="/api/v1/antifraud", tags=["防飞单"])
app.include_router(payroll_router, prefix="/api/v1/payroll", tags=["工资计算"])
app.include_router(dashboard_router, prefix="/api/v1/dashboard", tags=["数据看板"])
app.include_router(ai_router, prefix="/api/v1/ai", tags=["小C AI助手"])
app.include_router(store_router, prefix="/api/v1/store", tags=["门店配置"])
app.include_router(leaves_router, prefix="/api/v1", tags=["假期余额"])
app.include_router(audit_router, prefix="/api/v1/audit", tags=["操作日志"])
app.include_router(butler_router, prefix="/api/v1/butler", tags=["开闭店管理"])
app.include_router(sign_tasks_router, prefix="/api/v1/sign-tasks", tags=["签收任务"])
app.include_router(penalties_router, prefix="/api/v1/penalties", tags=["处罚通知"])


@app.get("/health", tags=["system"])
async def health_check():
    try:
        async with AsyncSessionLocal() as session:
            await session.execute(text("SELECT 1"))
        from app.utils.redis_client import get_redis
        redis = await get_redis()
        await redis.ping()
        return {"status": "healthy", "db": "ok", "redis": "ok"}
    except Exception as e:
        # In production, hide internal details (m-002 fix)
        is_prod = settings.APP_ENV == "production"
        error_detail = "service degraded" if is_prod else str(e)
        return {"status": "degraded", "error": error_detail}
