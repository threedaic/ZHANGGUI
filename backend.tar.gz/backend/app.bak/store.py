"""门店配置 API 路由。

前缀: /api/v1/store (由 main.py 提供)

端点:
  GET  ""              → 获取当前门店基本信息
  GET  "/settings"     → 获取当前门店完整设置
  PUT  "/settings"     → 更新门店设置
  PUT  "/wework"       → 更新企微配置
  POST   "/wework/sync-contacts"      → 同步企微通讯录，仅boss
  GET  "/employees"    → 获取门店员工列表
  PUT  "/employees/{id}/role" → 更新员工角色
"""

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.database import get_db
from app.models.store import Store, StoreSettings
from app.models.employee import Employee
from app.utils.deps import get_store_id, require_role
from app.utils.exceptions import NotFoundError
from app.schemas.store import StoreSettingsUpdate, WeworkConfigUpdate, EmployeeRoleUpdate

router = APIRouter()


@router.get("")
async def get_store_info(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """获取当前门店基本信息。"""
    store_id = get_store_id(request)
    stmt = select(Store).where(Store.id == store_id)
    result = await db.execute(stmt)
    store = result.scalar_one_or_none()
    if not store:
        raise NotFoundError("门店不存在")

    return {
        "code": 0, "message": "ok",
        "data": {
            "id": store.id,
            "name": store.name,
            "store_code": store.store_code,
            "address": store.address,
            "city": store.city,
            "status": store.status,
            "daily_booking_limit": store.daily_booking_limit,
            "wework_status": store.wework_status,
            "wework_corp_id": store.wework_corp_id,
            "wework_agent_id": store.wework_agent_id,
            "wework_department_id": store.wework_department_id,
        },
    }


@router.get("/settings")
async def get_store_settings(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """获取当前门店的完整设置（排班规则 + 通用参数 + 合同配置）。"""
    store_id = get_store_id(request)
    stmt = select(StoreSettings).where(StoreSettings.store_id == store_id)
    result = await db.execute(stmt)
    settings = result.scalar_one_or_none()

    # 同时获取门店基本信息（用于合同默认值）
    stmt_store = select(Store).where(Store.id == store_id)
    store_result = await db.execute(stmt_store)
    store = store_result.scalar_one_or_none()

    import json

    defaults = {
        "rest_days_per_month": 4,
        "rest_allowed_weekdays": ["周日", "周一", "周二", "周三", "周四"],
        "rest_forbidden_weekdays": ["周五", "周六"],
        "max_same_position_off": 1,
        "manager_order_constraint": True,
        "holiday_policy": "comp_leave",
        "auto_schedule_enabled": False,
        "schedule_lock_after_publish": True,
        "payroll_day_of_month": 5,
        "kpi_coefficient_min": 0.60,
        "kpi_coefficient_max": 1.50,
        # 合同默认值
        "contract_initiator_ids": [],
        "contract_company_name": store.name if store else "",
        "contract_company_phone": "",
        "contract_company_address": store.address if store else "",
        "contract_base_salary": 3000.0,
        "contract_probation_months": 6,
        "contract_notice_days": 45,
        "contract_duration_years": 3,
        # 云打印机
        "printer_enabled": False,
        "printer_brand": "yilianyun",
        "printer_api_url": "",
        "printer_sn": "",
        "printer_user": "",
        "printer_ukey": "",
        "printer_label_width": 80,
        "printer_label_height": 50,
        # 群机器人
        "wecom_webhook_url": "",
    }

    if not settings:
        return {"code": 0, "message": "ok", "data": defaults}

    return {
        "code": 0, "message": "ok",
        "data": {
            "rest_days_per_month": settings.rest_days_per_month,
            "rest_allowed_weekdays": json.loads(settings.rest_allowed_weekdays) if settings.rest_allowed_weekdays else defaults["rest_allowed_weekdays"],
            "rest_forbidden_weekdays": json.loads(settings.rest_forbidden_weekdays) if settings.rest_forbidden_weekdays else defaults["rest_forbidden_weekdays"],
            "max_same_position_off": settings.max_same_position_off,
            "manager_order_constraint": settings.manager_order_constraint,
            "holiday_policy": settings.holiday_policy,
            "auto_schedule_enabled": settings.auto_schedule_enabled,
            "schedule_lock_after_publish": settings.schedule_lock_after_publish,
            "payroll_day_of_month": settings.payroll_day_of_month,
            "kpi_coefficient_min": settings.kpi_coefficient_min,
            "kpi_coefficient_max": settings.kpi_coefficient_max,
            # 合同
            "contract_initiator_ids": json.loads(settings.contract_initiator_ids) if settings.contract_initiator_ids else [],
            "contract_company_name": settings.contract_company_name or (store.name if store else ""),
            "contract_company_phone": settings.contract_company_phone or "",
            "contract_company_address": settings.contract_company_address or (store.address if store else ""),
            "contract_base_salary": settings.contract_base_salary,
            "contract_probation_months": settings.contract_probation_months,
            "contract_notice_days": settings.contract_notice_days,
            "contract_duration_years": settings.contract_duration_years,
            # 云打印机
            "printer_enabled": settings.printer_enabled,
            "printer_brand": settings.printer_brand or "yilianyun",
            "printer_api_url": settings.printer_api_url or "",
            "printer_sn": settings.printer_sn or "",
            "printer_user": settings.printer_user or "",
            "printer_ukey": settings.printer_ukey or "",
            "printer_label_width": settings.printer_label_width or 80,
            "printer_label_height": settings.printer_label_height or 50,
            # 群机器人
            "wecom_webhook_url": settings.wecom_webhook_url or "",
        },
    }


@router.put("/settings")
async def update_store_settings(
    body: StoreSettingsUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """更新门店设置。仅老板可操作。"""
    require_role(request, ["boss"])
    store_id = get_store_id(request)

    body_dict = body.model_dump(exclude_unset=True, exclude_none=True)
    import json

    stmt = select(StoreSettings).where(StoreSettings.store_id == store_id)
    result = await db.execute(stmt)
    settings = result.scalar_one_or_none()

    if not settings:
        settings = StoreSettings(store_id=store_id)
        db.add(settings)

    json_fields = {
        "rest_allowed_weekdays", "rest_forbidden_weekdays", "contract_initiator_ids",
    }

    for key, value in body_dict.items():
        if key in json_fields:
            setattr(settings, key, json.dumps(value))
        else:
            setattr(settings, key, value)

    await db.commit()
    await db.refresh(settings)

    return {"code": 0, "message": "门店设置已更新", "data": None}


@router.put("/wework")
async def update_wework_config(
    body: WeworkConfigUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """更新企微配置字段。仅老板可操作。"""
    require_role(request, ["boss"])
    store_id = get_store_id(request)

    body_dict = body.model_dump(exclude_unset=True, exclude_none=True)
    stmt = select(Store).where(Store.id == store_id)
    result = await db.execute(stmt)
    store = result.scalar_one_or_none()
    if not store:
        raise NotFoundError("门店不存在")

    wework_fields = {"wework_corp_id", "wework_agent_id", "wework_secret", "wework_token", "wework_aes_key", "wework_department_id"}
    for key, value in body_dict.items():
        if key in wework_fields:
            # AES 加密 secret 字段
            if key == "wework_secret" and value:
                from app.utils.security import encrypt_aes
                value = encrypt_aes(value)
            # 部门 ID 允许传空字符串清空配置
            if key == "wework_department_id":
                if value == "" or value is None:
                    value = None
                elif isinstance(value, str):
                    value = int(value)
            setattr(store, key, value)

    await db.commit()
    return {"code": 0, "message": "企微配置已更新", "data": None}


@router.post("/wework/sync-contacts")
async def sync_wework_contacts(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """从企微通讯录同步员工到本地 employees 表。仅老板可操作。"""
    require_role(request, ["boss"])
    store_id = get_store_id(request)

    from app.services.wework import sync_contacts
    result = await sync_contacts(db, store_id)
    return {"code": 0, "message": "通讯录同步完成", "data": result}


ROLE_OPTIONS = ["boss", "store_manager", "accountant", "bar_manager", "service_manager", "kitchen_manager", "staff"]


@router.get("/employees")
async def list_employees(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """获取当前门店所有员工列表。"""
    store_id = get_store_id(request)
    stmt = select(Employee).where(Employee.store_id == store_id).order_by(Employee.id)
    result = await db.execute(stmt)
    employees = result.scalars().all()

    return {
        "code": 0, "message": "ok",
        "data": [
            {
                "id": e.id,
                "name": e.name,
                "role": e.role,
                "wework_userid": e.wework_userid,
                "status": e.status,
                "phone": e.phone,
            }
            for e in employees
        ],
    }


@router.put("/employees/{employee_id}/role")
async def update_employee_role(
    employee_id: int,
    body: EmployeeRoleUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """更新员工角色。仅老板可操作。"""
    require_role(request, ["boss"])
    store_id = get_store_id(request)
    new_role = body.role

    if new_role not in {"boss", "store_manager", "accountant", "bar_manager", "service_manager", "kitchen_manager", "staff"}:
        return {"code": 400, "message": f"无效角色: {new_role}", "data": None}

    stmt = select(Employee).where(Employee.id == employee_id, Employee.store_id == store_id)
    result = await db.execute(stmt)
    emp = result.scalar_one_or_none()
    if not emp:
        raise NotFoundError("员工不存在")

    old_role = emp.role
    emp.role = new_role
    await db.commit()

    # 同步更新关联的 User 记录角色
    from app.models.user import User
    user_result = await db.execute(select(User).where(User.employee_id == employee_id))
    user = user_result.scalar_one_or_none()
    if user:
        user.role = new_role
        await db.commit()

    return {
        "code": 0, "message": f"{emp.name} 角色已从 {old_role} 更新为 {new_role}",
        "data": {"id": emp.id, "name": emp.name, "role": new_role},
    }
