"""门店配置 Pydantic Schema"""

from pydantic import BaseModel, Field, field_validator
from typing import Optional


class StoreSettingsUpdate(BaseModel):
    """PUT /api/v1/store/settings 请求体"""
    rest_days_per_month: Optional[int] = Field(None, ge=0, le=10)
    rest_allowed_weekdays: Optional[list[str]] = None
    rest_forbidden_weekdays: Optional[list[str]] = None
    max_same_position_off: Optional[int] = Field(None, ge=1, le=10)
    manager_order_constraint: Optional[bool] = None
    holiday_policy: Optional[str] = None
    auto_schedule_enabled: Optional[bool] = None
    schedule_lock_after_publish: Optional[bool] = None
    payroll_day_of_month: Optional[int] = Field(None, ge=1, le=28)
    kpi_coefficient_min: Optional[float] = Field(None, ge=0.0, le=1.0)
    kpi_coefficient_max: Optional[float] = Field(None, ge=1.0, le=3.0)
    contract_initiator_ids: Optional[list[int]] = None
    contract_company_name: Optional[str] = None
    contract_company_phone: Optional[str] = None
    contract_company_address: Optional[str] = None
    contract_base_salary: Optional[float] = Field(None, ge=0)
    contract_probation_months: Optional[int] = Field(None, ge=1, le=12)
    contract_notice_days: Optional[int] = Field(None, ge=1, le=90)
    contract_duration_years: Optional[int] = Field(None, ge=1, le=10)
    # 云打印机
    printer_enabled: Optional[bool] = None
    printer_brand: Optional[str] = None
    printer_api_url: Optional[str] = None
    printer_sn: Optional[str] = None
    printer_user: Optional[str] = None
    printer_ukey: Optional[str] = None
    printer_label_width: Optional[int] = Field(None, ge=30, le=110)
    printer_label_height: Optional[int] = Field(None, ge=20, le=200)
    # 群机器人
    wecom_bot_enabled: Optional[bool] = None
    wecom_webhook_url: Optional[str] = None

    @field_validator("rest_allowed_weekdays", "rest_forbidden_weekdays")
    @classmethod
    def validate_weekdays(cls, v):
        if v is None:
            return v
        valid = {"周一", "周二", "周三", "周四", "周五", "周六", "周日"}
        for d in v:
            if d not in valid:
                raise ValueError(f"无效的星期: {d}，应为 周一~周日")
        return v

    @field_validator("holiday_policy")
    @classmethod
    def validate_holiday_policy(cls, v):
        if v is None:
            return v
        valid = {"comp_leave", "double_pay", "normal"}
        if v not in valid:
            raise ValueError(f"无效的节假日策略: {v}，应为 comp_leave/double_pay/normal")
        return v


class WeworkConfigUpdate(BaseModel):
    """PUT /api/v1/store/wework 请求体"""
    wework_corp_id: Optional[str] = None
    wework_agent_id: Optional[int] = None
    wework_secret: Optional[str] = None
    wework_token: Optional[str] = None
    wework_aes_key: Optional[str] = None
    wework_department_id: Optional[int] = None


class EmployeeRoleUpdate(BaseModel):
    """PUT /api/v1/store/employees/{id}/role 请求体"""
    role: str

    @field_validator("role")
    @classmethod
    def validate_role(cls, v):
        valid = {"boss", "store_manager", "accountant", "bar_manager", "service_manager", "kitchen_manager", "staff"}
        if v not in valid:
            raise ValueError(f"无效角色: {v}")
        return v
