"""
统一审批 Pydantic 模型
"""
from pydantic import BaseModel, field_validator


class ApprovalCreateRequest(BaseModel):
    type: str  # leave / makeup / swap / overtime / expense
    start_date: str | None = None
    end_date: str | None = None
    reason: str
    extra: dict | None = None

    @field_validator("type")
    @classmethod
    def validate_type(cls, v: str) -> str:
        if v not in ("leave", "makeup", "swap", "overtime", "expense"):
            raise ValueError("审批类型必须是 leave/makeup/swap/overtime/expense")
        return v


class ApprovalReviewRequest(BaseModel):
    action: str  # approved / rejected

    @field_validator("action")
    @classmethod
    def validate_action(cls, v: str) -> str:
        if v not in ("approved", "rejected"):
            raise ValueError("action 必须是 approved 或 rejected")
        return v


class ApprovalItemResponse(BaseModel):
    id: int
    employee_id: int
    employee_name: str = ""
    type: str
    type_label: str = ""
    status: str
    start_date: str | None = None
    end_date: str | None = None
    reason: str | None = None
    extra: dict | None = None
    created_at: str | None = None
