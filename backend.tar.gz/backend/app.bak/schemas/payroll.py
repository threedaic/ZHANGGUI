"""
工资计算模块 Pydantic 模型

公式: 实发 = 合同月薪 - 考勤扣款 + 提成(10%)
每月 5 号自动生成，依赖 考勤 + KPI（占位）
"""
from pydantic import BaseModel, field_validator


# ==================== 工资记录 ====================

class PayrollRecordResponse(BaseModel):
    """工资记录响应"""
    id: int
    employee_id: int
    store_id: int
    period: str
    base_salary: float
    kpi_coefficient: float = 1.00
    commission_bottle: float = 0.0
    commission_card: float = 0.0
    commission_total: float = 0.0
    deduction_late: float = 0.0
    deduction_absent: float = 0.0
    deduction_other: float = 0.0
    deduction_total: float = 0.0
    net_pay: float
    status: str = "draft"
    generated_at: str | None = None
    finalized_at: str | None = None
    paid_at: str | None = None
    notes: str | None = None
    # 展示用关联字段
    employee_name: str = ""
    employee_role: str = ""

    model_config = {"from_attributes": True}


class PayrollRecordDetail(PayrollRecordResponse):
    """工资记录详情，含考勤明细和 KPI 系数"""
    attendance_summary: dict | None = None


# ==================== 生成/确认请求 ====================

class PayrollGenerateRequest(BaseModel):
    """触发工资生成"""
    period: str
    employee_ids: list[int] | None = None  # None = 全员

    @field_validator("period")
    @classmethod
    def validate_period(cls, v: str) -> str:
        import re
        if not re.match(r"^\d{4}-\d{2}$", v):
            raise ValueError("period 格式必须为 YYYY-MM")
        return v


class PayrollFinalizeRequest(BaseModel):
    """确认工资条"""
    record_ids: list[int]
    notes: str | None = None


class PayrollMarkPaidRequest(BaseModel):
    """标记已发放"""
    record_ids: list[int]
    paid_at: str | None = None


# ==================== 月度汇总 ====================

class PayrollMonthlyItem(BaseModel):
    """月度工资汇总行"""
    record_id: int
    employee_id: int
    employee_name: str
    employee_role: str
    base_salary: float
    kpi_coefficient: float = 1.00
    commission_total: float = 0.0
    deduction_total: float = 0.0
    net_pay: float
    status: str


class PayrollMonthlySummary(BaseModel):
    """门店月度工资汇总"""
    period: str
    store_id: int
    items: list[PayrollMonthlyItem]
    total_base_salary: float = 0.0
    total_commission: float = 0.0
    total_deduction: float = 0.0
    total_net_pay: float = 0.0
    status_summary: dict = {}
