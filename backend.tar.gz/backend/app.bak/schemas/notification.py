"""
消息通知 Pydantic 模型
"""
from pydantic import BaseModel


class NotificationItem(BaseModel):
    id: int
    type: str
    title: str
    content: str
    channel: str
    is_read: bool
    created_at: str | None = None


class NotificationSettingItem(BaseModel):
    id: int
    setting_key: str
    enabled: bool
    channel: str
    target_roles: list[str]
    schedule_time: str | None = None


class NotificationSettingSaveRequest(BaseModel):
    setting_key: str
    enabled: bool
    channel: str
    target_roles: list[str]
    schedule_time: str | None = None
