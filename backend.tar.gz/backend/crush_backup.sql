--
-- PostgreSQL database dump
--

\restrict yeEmb1fuvhl2HYJF3K6pRaqNNThCXwVuTuhMoei57gRZlZCPH16APNmeS1WFry1

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: approval_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_requests (
    id integer NOT NULL,
    store_id integer NOT NULL,
    employee_id integer NOT NULL,
    type character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    start_date date,
    end_date date,
    reason text,
    extra json,
    approver_id integer,
    approved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    reject_reason text
);

ALTER TABLE ONLY public.approval_requests FORCE ROW LEVEL SECURITY;


--
-- Name: approval_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.approval_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: approval_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.approval_requests_id_seq OWNED BY public.approval_requests.id;


--
-- Name: attendance_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_records (
    id integer NOT NULL,
    store_id integer NOT NULL,
    employee_id integer NOT NULL,
    date date NOT NULL,
    scheduled_shift character varying(20),
    clock_in text,
    clock_out text,
    status character varying(20) NOT NULL,
    late_minutes integer NOT NULL,
    early_minutes integer NOT NULL,
    source character varying(20) NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    shift_start_time character varying(8),
    shift_end_time character varying(8),
    is_overnight boolean DEFAULT false NOT NULL
);

ALTER TABLE ONLY public.attendance_records FORCE ROW LEVEL SECURITY;


--
-- Name: attendance_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attendance_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attendance_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attendance_records_id_seq OWNED BY public.attendance_records.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer,
    store_id integer,
    action character varying(30) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id integer,
    old_value text,
    new_value text,
    request_id text,
    ip_address text,
    user_agent text,
    created_at text NOT NULL
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bookings (
    id integer NOT NULL,
    store_id integer NOT NULL,
    customer_name character varying(50) NOT NULL,
    phone character varying(20),
    date text NOT NULL,
    time_slot character varying(20),
    guests_count integer NOT NULL,
    table_id integer,
    table_no character varying(10),
    source character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer
);

ALTER TABLE ONLY public.bookings FORCE ROW LEVEL SECURITY;


--
-- Name: COLUMN bookings.created_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bookings.created_by IS '创建预约的员工ID(关联个人业绩)';


--
-- Name: bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bookings_id_seq OWNED BY public.bookings.id;


--
-- Name: closing_checklist_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.closing_checklist_items (
    id integer NOT NULL,
    template_id integer NOT NULL,
    item_name character varying(100) NOT NULL,
    item_type character varying(20) NOT NULL,
    device_id integer,
    required_photo boolean NOT NULL,
    sort_order integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: closing_checklist_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.closing_checklist_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: closing_checklist_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.closing_checklist_items_id_seq OWNED BY public.closing_checklist_items.id;


--
-- Name: closing_checklist_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.closing_checklist_templates (
    id integer NOT NULL,
    store_id integer NOT NULL,
    name character varying(50) NOT NULL,
    session_type character varying(10) NOT NULL,
    role_tag character varying(30) NOT NULL,
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    created_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: closing_checklist_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.closing_checklist_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: closing_checklist_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.closing_checklist_templates_id_seq OWNED BY public.closing_checklist_templates.id;


--
-- Name: closing_item_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.closing_item_results (
    id integer NOT NULL,
    session_id integer NOT NULL,
    template_id integer,
    item_id integer,
    item_name character varying(100),
    item_type character varying(20),
    completed_by integer,
    photo_url text,
    ai_result json,
    review_status character varying(20) NOT NULL,
    review_user_id integer,
    review_comment text,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: closing_item_results_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.closing_item_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: closing_item_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.closing_item_results_id_seq OWNED BY public.closing_item_results.id;


--
-- Name: closing_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.closing_sessions (
    id integer NOT NULL,
    store_id integer NOT NULL,
    session_type character varying(10) NOT NULL,
    operator_user_id integer NOT NULL,
    status character varying(20) NOT NULL,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    total_items integer NOT NULL,
    completed_items integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: closing_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.closing_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: closing_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.closing_sessions_id_seq OWNED BY public.closing_sessions.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    brand character varying(100) NOT NULL,
    tax_id character varying(50),
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contracts (
    id integer NOT NULL,
    store_id integer NOT NULL,
    employee_id integer NOT NULL,
    contract_no character varying(50) NOT NULL,
    "position" character varying(30) NOT NULL,
    grade character varying(20) NOT NULL,
    monthly_salary double precision NOT NULL,
    base_salary double precision NOT NULL,
    meal_allowance double precision NOT NULL,
    allowance double precision NOT NULL,
    start_date date NOT NULL,
    end_date date,
    status character varying(30) NOT NULL,
    esign_flow_id character varying(100),
    signed_at timestamp with time zone,
    signed_by integer,
    template_data json,
    created_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: COLUMN contracts.contract_no; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.contract_no IS '合同编号';


--
-- Name: COLUMN contracts."position"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts."position" IS '岗位';


--
-- Name: COLUMN contracts.grade; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.grade IS '职档';


--
-- Name: COLUMN contracts.monthly_salary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.monthly_salary IS '月薪总额';


--
-- Name: COLUMN contracts.base_salary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.base_salary IS '基本工资';


--
-- Name: COLUMN contracts.meal_allowance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.meal_allowance IS '餐补';


--
-- Name: COLUMN contracts.allowance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.allowance IS '补贴 = 月薪 - 基本工资';


--
-- Name: COLUMN contracts.start_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.start_date IS '合同开始日期';


--
-- Name: COLUMN contracts.end_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.end_date IS '合同结束日期';


--
-- Name: COLUMN contracts.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.status IS 'draft/pending_sign/signed/expired/terminated';


--
-- Name: COLUMN contracts.esign_flow_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.esign_flow_id IS '腾讯电子签流程 ID';


--
-- Name: COLUMN contracts.signed_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.signed_at IS '签署完成时间';


--
-- Name: COLUMN contracts.signed_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.signed_by IS '签署人 user_id';


--
-- Name: COLUMN contracts.template_data; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.template_data IS '模板填充的完整字段（20+字段）';


--
-- Name: COLUMN contracts.created_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.contracts.created_by IS '创建人';


--
-- Name: contracts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contracts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contracts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contracts_id_seq OWNED BY public.contracts.id;


--
-- Name: daily_revenue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_revenue (
    store_id integer NOT NULL,
    date text NOT NULL,
    total_revenue double precision NOT NULL,
    total_orders integer NOT NULL,
    total_guests integer NOT NULL,
    avg_order_value double precision,
    total_discounts double precision NOT NULL,
    bottle_sales double precision NOT NULL,
    card_sales double precision NOT NULL,
    data_source character varying(30) NOT NULL,
    source_raw text,
    synced_at text NOT NULL
);

ALTER TABLE ONLY public.daily_revenue FORCE ROW LEVEL SECURITY;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    store_id integer NOT NULL,
    employee_code character varying(20) NOT NULL,
    name character varying(50) NOT NULL,
    phone character varying(20),
    role character varying(30) NOT NULL,
    base_salary double precision DEFAULT 3000 NOT NULL,
    hire_date date DEFAULT CURRENT_DATE NOT NULL,
    status character varying(20) NOT NULL,
    wework_userid character varying(100),
    skill_tags text[],
    is_first_manager boolean DEFAULT false NOT NULL,
    is_second_manager boolean DEFAULT false NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    shift_group character varying(10),
    is_third_manager boolean DEFAULT false
);

ALTER TABLE ONLY public.employees FORCE ROW LEVEL SECURITY;


--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: guest_ratings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.guest_ratings (
    id integer NOT NULL,
    store_id integer NOT NULL,
    table_no character varying(10) NOT NULL,
    food_quality integer,
    food_speed integer,
    drink_quality integer,
    drink_speed integer,
    service_attitude integer,
    service_speed integer,
    cleanliness integer,
    overall_score double precision NOT NULL,
    comment text,
    source character varying(20) NOT NULL,
    is_low_score boolean NOT NULL,
    notified boolean NOT NULL,
    notified_at text,
    store_response text,
    response_by integer,
    responded_at text,
    created_at text NOT NULL,
    CONSTRAINT ck_cleanliness CHECK (((cleanliness IS NULL) OR ((cleanliness >= 1) AND (cleanliness <= 5)))),
    CONSTRAINT ck_drink_quality CHECK (((drink_quality IS NULL) OR ((drink_quality >= 1) AND (drink_quality <= 5)))),
    CONSTRAINT ck_drink_speed CHECK (((drink_speed IS NULL) OR ((drink_speed >= 1) AND (drink_speed <= 5)))),
    CONSTRAINT ck_food_quality CHECK (((food_quality IS NULL) OR ((food_quality >= 1) AND (food_quality <= 5)))),
    CONSTRAINT ck_food_speed CHECK (((food_speed IS NULL) OR ((food_speed >= 1) AND (food_speed <= 5)))),
    CONSTRAINT ck_service_attitude CHECK (((service_attitude IS NULL) OR ((service_attitude >= 1) AND (service_attitude <= 5)))),
    CONSTRAINT ck_service_speed CHECK (((service_speed IS NULL) OR ((service_speed >= 1) AND (service_speed <= 5))))
);

ALTER TABLE ONLY public.guest_ratings FORCE ROW LEVEL SECURITY;


--
-- Name: guest_ratings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.guest_ratings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: guest_ratings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.guest_ratings_id_seq OWNED BY public.guest_ratings.id;


--
-- Name: kpi_appeals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kpi_appeals (
    id integer NOT NULL,
    result_id integer NOT NULL,
    employee_id integer NOT NULL,
    dimension character varying(50),
    reason text NOT NULL,
    evidence text,
    status character varying(20) NOT NULL,
    reviewed_by integer,
    resolution text,
    resolved_at text,
    created_at text NOT NULL
);


--
-- Name: kpi_appeals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kpi_appeals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kpi_appeals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kpi_appeals_id_seq OWNED BY public.kpi_appeals.id;


--
-- Name: kpi_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kpi_results (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    store_id integer NOT NULL,
    period character varying(7) NOT NULL,
    total_score double precision NOT NULL,
    coefficient double precision NOT NULL,
    coefficient_reason text,
    rank_in_store integer,
    status character varying(20) NOT NULL,
    confirmed_by integer,
    confirmed_at text,
    created_at text NOT NULL
);

ALTER TABLE ONLY public.kpi_results FORCE ROW LEVEL SECURITY;


--
-- Name: kpi_results_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kpi_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kpi_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kpi_results_id_seq OWNED BY public.kpi_results.id;


--
-- Name: kpi_scores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kpi_scores (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    store_id integer NOT NULL,
    period character varying(7) NOT NULL,
    dimension character varying(50) NOT NULL,
    raw_value double precision,
    raw_description text,
    normalized_score double precision NOT NULL,
    weight double precision NOT NULL,
    weighted_score double precision NOT NULL,
    data_source character varying(50),
    source_reference text,
    calculated_at text NOT NULL
);


--
-- Name: kpi_scores_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kpi_scores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kpi_scores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kpi_scores_id_seq OWNED BY public.kpi_scores.id;


--
-- Name: kpi_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kpi_templates (
    id integer NOT NULL,
    store_id integer,
    role character varying(30) NOT NULL,
    dimension character varying(50) NOT NULL,
    dimension_label character varying(50) NOT NULL,
    weight double precision NOT NULL,
    formula_type character varying(30) NOT NULL,
    formula_config text NOT NULL,
    data_source character varying(50) NOT NULL,
    is_active boolean NOT NULL,
    created_at text NOT NULL
);


--
-- Name: kpi_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kpi_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kpi_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kpi_templates_id_seq OWNED BY public.kpi_templates.id;


--
-- Name: leave_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leave_balances (
    id integer NOT NULL,
    store_id integer,
    employee_id integer,
    year integer NOT NULL,
    leave_type character varying(20) NOT NULL,
    total_days double precision DEFAULT 0,
    used_days double precision DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);

ALTER TABLE ONLY public.leave_balances FORCE ROW LEVEL SECURITY;


--
-- Name: leave_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.leave_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leave_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.leave_balances_id_seq OWNED BY public.leave_balances.id;


--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_settings (
    id integer NOT NULL,
    store_id integer NOT NULL,
    setting_key character varying(40) NOT NULL,
    enabled boolean NOT NULL,
    channel character varying(20) NOT NULL,
    target_roles json NOT NULL,
    schedule_time character varying(8),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notification_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_settings_id_seq OWNED BY public.notification_settings.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    store_id integer NOT NULL,
    user_id integer,
    type character varying(40) NOT NULL,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    channel character varying(20) NOT NULL,
    is_read boolean NOT NULL,
    extra json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: payroll_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_records (
    id integer NOT NULL,
    employee_id integer NOT NULL,
    store_id integer NOT NULL,
    period character varying(7) NOT NULL,
    base_salary double precision NOT NULL,
    kpi_coefficient double precision NOT NULL,
    commission_bottle double precision NOT NULL,
    commission_card double precision NOT NULL,
    commission_total double precision NOT NULL,
    deduction_late double precision NOT NULL,
    deduction_absent double precision NOT NULL,
    deduction_other double precision NOT NULL,
    deduction_total double precision NOT NULL,
    net_pay double precision NOT NULL,
    status character varying(20) NOT NULL,
    generated_at text NOT NULL,
    finalized_at text,
    paid_at text,
    notes text
);

ALTER TABLE ONLY public.payroll_records FORCE ROW LEVEL SECURITY;


--
-- Name: payroll_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payroll_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payroll_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payroll_records_id_seq OWNED BY public.payroll_records.id;


--
-- Name: penalty_notices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.penalty_notices (
    id integer NOT NULL,
    store_id integer NOT NULL,
    employee_id integer NOT NULL,
    penalty_type character varying(30) NOT NULL,
    amount double precision NOT NULL,
    reason text NOT NULL,
    issued_by integer NOT NULL,
    issued_at timestamp with time zone NOT NULL,
    status character varying(20) NOT NULL,
    extra json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: penalty_notices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.penalty_notices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: penalty_notices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.penalty_notices_id_seq OWNED BY public.penalty_notices.id;


--
-- Name: salary_matrix; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_matrix (
    id integer NOT NULL,
    "position" character varying(30) NOT NULL,
    grade character varying(20) NOT NULL,
    monthly_salary double precision NOT NULL,
    base_salary double precision NOT NULL,
    meal_allowance double precision NOT NULL,
    is_active boolean NOT NULL
);


--
-- Name: COLUMN salary_matrix."position"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.salary_matrix."position" IS '岗位: 店长/吧员/服务员/厨师/保洁';


--
-- Name: COLUMN salary_matrix.grade; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.salary_matrix.grade IS '职档: 学徒/正式/副职/正职';


--
-- Name: COLUMN salary_matrix.monthly_salary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.salary_matrix.monthly_salary IS '月薪总额';


--
-- Name: COLUMN salary_matrix.base_salary; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.salary_matrix.base_salary IS '基本工资，固定3000';


--
-- Name: COLUMN salary_matrix.meal_allowance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.salary_matrix.meal_allowance IS '餐补';


--
-- Name: COLUMN salary_matrix.is_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.salary_matrix.is_active IS '是否启用';


--
-- Name: salary_matrix_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.salary_matrix_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salary_matrix_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.salary_matrix_id_seq OWNED BY public.salary_matrix.id;


--
-- Name: schedule_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schedule_rules (
    id integer NOT NULL,
    store_id integer NOT NULL,
    rule_type character varying(50) NOT NULL,
    rule_config text NOT NULL,
    is_active boolean NOT NULL,
    created_at text NOT NULL
);


--
-- Name: schedule_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.schedule_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: schedule_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.schedule_rules_id_seq OWNED BY public.schedule_rules.id;


--
-- Name: schedule_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schedule_snapshots (
    id integer NOT NULL,
    store_id integer NOT NULL,
    period character varying(7) NOT NULL,
    snapshot_data text NOT NULL,
    version integer NOT NULL,
    created_by integer,
    created_at text NOT NULL
);


--
-- Name: schedule_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.schedule_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: schedule_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.schedule_snapshots_id_seq OWNED BY public.schedule_snapshots.id;


--
-- Name: schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schedules (
    id integer NOT NULL,
    store_id integer NOT NULL,
    employee_id integer NOT NULL,
    date date NOT NULL,
    shift_type character varying(20) NOT NULL,
    note text,
    created_by integer,
    version integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.schedules_id_seq OWNED BY public.schedules.id;


--
-- Name: shift_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shift_configs (
    id integer NOT NULL,
    store_id integer NOT NULL,
    shift_code character varying(20) NOT NULL,
    shift_name character varying(20) NOT NULL,
    start_time character varying(8) NOT NULL,
    end_time character varying(8) NOT NULL,
    is_overnight boolean NOT NULL,
    color character varying(8) NOT NULL,
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shift_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shift_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shift_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shift_configs_id_seq OWNED BY public.shift_configs.id;


--
-- Name: shift_swap_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shift_swap_requests (
    id integer NOT NULL,
    store_id integer NOT NULL,
    requester_id integer NOT NULL,
    swap_with_id integer NOT NULL,
    swap_date date NOT NULL,
    swap_shift character varying(20) NOT NULL,
    reason text NOT NULL,
    status character varying(20) NOT NULL,
    swap_with_confirmed_at text,
    approved_by integer,
    approved_at text,
    reject_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shift_swap_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shift_swap_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shift_swap_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shift_swap_requests_id_seq OWNED BY public.shift_swap_requests.id;


--
-- Name: sign_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sign_tasks (
    id integer NOT NULL,
    store_id integer NOT NULL,
    employee_id integer NOT NULL,
    type character varying(30) NOT NULL,
    title character varying(200) NOT NULL,
    ref_type character varying(30) NOT NULL,
    ref_id integer NOT NULL,
    status character varying(20) NOT NULL,
    signed_at timestamp with time zone,
    signature_data text,
    dispute_reason text,
    disputed_at timestamp with time zone,
    issued_by integer NOT NULL,
    issued_at timestamp with time zone NOT NULL,
    notes text,
    extra json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sign_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sign_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sign_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sign_tasks_id_seq OWNED BY public.sign_tasks.id;


--
-- Name: store_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.store_settings (
    id integer NOT NULL,
    store_id integer NOT NULL,
    rest_days_per_month integer NOT NULL,
    rest_allowed_weekdays text,
    rest_forbidden_weekdays text,
    max_same_position_off integer NOT NULL,
    manager_order_constraint boolean DEFAULT true NOT NULL,
    holiday_policy character varying(20) DEFAULT 'comp_leave'::character varying NOT NULL,
    auto_schedule_enabled boolean DEFAULT false NOT NULL,
    schedule_lock_after_publish boolean DEFAULT true NOT NULL,
    payroll_day_of_month integer NOT NULL,
    kpi_coefficient_min double precision NOT NULL,
    kpi_coefficient_max double precision NOT NULL,
    ai_api_url text,
    ai_api_key text,
    ai_model character varying(100),
    ai_temperature double precision NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    contract_initiator_ids text,
    contract_company_name character varying(100),
    contract_company_phone character varying(20),
    contract_company_address text,
    contract_base_salary double precision DEFAULT 3000.0,
    contract_probation_months integer DEFAULT 6,
    contract_notice_days integer DEFAULT 45,
    contract_duration_years integer DEFAULT 3,
    wecom_webhook_url text,
    wecom_bot_enabled boolean DEFAULT false,
    printer_enabled boolean DEFAULT false,
    printer_brand character varying(50),
    printer_api_url text,
    printer_sn character varying(100),
    printer_user character varying(100),
    printer_ukey text,
    printer_label_width integer DEFAULT 80,
    printer_label_height integer DEFAULT 50
);


--
-- Name: store_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.store_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: store_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.store_settings_id_seq OWNED BY public.store_settings.id;


--
-- Name: stores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stores (
    id integer NOT NULL,
    company_id integer NOT NULL,
    name character varying(100) NOT NULL,
    store_code character varying(20) NOT NULL,
    address text,
    city character varying(50),
    status character varying(20) NOT NULL,
    franchisee_user_id integer,
    daily_booking_limit integer,
    wework_corp_id character varying(100),
    wework_agent_id character varying(20),
    wework_secret text,
    wework_token character varying(100),
    wework_aes_key character varying(100),
    wework_status character varying(20),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    wework_department_id integer
);


--
-- Name: stores_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stores_id_seq OWNED BY public.stores.id;


--
-- Name: table_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.table_sessions (
    id integer NOT NULL,
    store_id integer NOT NULL,
    table_no character varying(10) NOT NULL,
    opened_by integer NOT NULL,
    opened_at text NOT NULL,
    closed_by integer,
    closed_at text,
    guest_count integer NOT NULL,
    crmeb_order_count integer NOT NULL,
    crmeb_total_amount double precision NOT NULL,
    wework_pay_count integer NOT NULL,
    wework_pay_amount double precision NOT NULL,
    commission_employee_id integer,
    commission_base double precision NOT NULL,
    commission_amount double precision NOT NULL,
    is_anomaly boolean NOT NULL,
    anomaly_reason text,
    status character varying(20) NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.table_sessions FORCE ROW LEVEL SECURITY;


--
-- Name: table_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.table_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: table_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.table_sessions_id_seq OWNED BY public.table_sessions.id;


--
-- Name: tables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tables (
    id integer NOT NULL,
    store_id integer NOT NULL,
    area character varying(50) NOT NULL,
    table_no character varying(10) NOT NULL,
    capacity integer NOT NULL,
    status character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.tables FORCE ROW LEVEL SECURITY;


--
-- Name: tables_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tables_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tables_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tables_id_seq OWNED BY public.tables.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    employee_id integer,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(30) NOT NULL,
    region character varying(50),
    is_active boolean NOT NULL,
    last_login timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    must_change_password boolean DEFAULT false
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: wine_storage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wine_storage (
    id integer NOT NULL,
    store_id integer NOT NULL,
    customer_name character varying(50) NOT NULL,
    phone character varying(20) NOT NULL,
    wine_name character varying(100) NOT NULL,
    bottle_label character varying(50),
    date_stored text NOT NULL,
    remaining_ml integer,
    cabinet_no character varying(20),
    status character varying(20) NOT NULL,
    retrieved_at text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    initial_ml integer DEFAULT 0,
    table_no character varying(20),
    expiry_date text,
    retrieved_by integer
);

ALTER TABLE ONLY public.wine_storage FORCE ROW LEVEL SECURITY;


--
-- Name: wine_storage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wine_storage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wine_storage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wine_storage_id_seq OWNED BY public.wine_storage.id;


--
-- Name: approval_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests ALTER COLUMN id SET DEFAULT nextval('public.approval_requests_id_seq'::regclass);


--
-- Name: attendance_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records ALTER COLUMN id SET DEFAULT nextval('public.attendance_records_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: bookings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings ALTER COLUMN id SET DEFAULT nextval('public.bookings_id_seq'::regclass);


--
-- Name: closing_checklist_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.closing_checklist_items ALTER COLUMN id SET DEFAULT nextval('public.closing_checklist_items_id_seq'::regclass);


--
-- Name: closing_checklist_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.closing_checklist_templates ALTER COLUMN id SET DEFAULT nextval('public.closing_checklist_templates_id_seq'::regclass);


--
-- Name: closing_item_results id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.closing_item_results ALTER COLUMN id SET DEFAULT nextval('public.closing_item_results_id_seq'::regclass);


--
-- Name: closing_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.closing_sessions ALTER COLUMN id SET DEFAULT nextval('public.closing_sessions_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: contracts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts ALTER COLUMN id SET DEFAULT nextval('public.contracts_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: guest_ratings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guest_ratings ALTER COLUMN id SET DEFAULT nextval('public.guest_ratings_id_seq'::regclass);


--
-- Name: kpi_appeals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_appeals ALTER COLUMN id SET DEFAULT nextval('public.kpi_appeals_id_seq'::regclass);


--
-- Name: kpi_results id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_results ALTER COLUMN id SET DEFAULT nextval('public.kpi_results_id_seq'::regclass);


--
-- Name: kpi_scores id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_scores ALTER COLUMN id SET DEFAULT nextval('public.kpi_scores_id_seq'::regclass);


--
-- Name: kpi_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_templates ALTER COLUMN id SET DEFAULT nextval('public.kpi_templates_id_seq'::regclass);


--
-- Name: leave_balances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_balances ALTER COLUMN id SET DEFAULT nextval('public.leave_balances_id_seq'::regclass);


--
-- Name: notification_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings ALTER COLUMN id SET DEFAULT nextval('public.notification_settings_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: payroll_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_records ALTER COLUMN id SET DEFAULT nextval('public.payroll_records_id_seq'::regclass);


--
-- Name: penalty_notices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalty_notices ALTER COLUMN id SET DEFAULT nextval('public.penalty_notices_id_seq'::regclass);


--
-- Name: salary_matrix id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_matrix ALTER COLUMN id SET DEFAULT nextval('public.salary_matrix_id_seq'::regclass);


--
-- Name: schedule_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedule_rules ALTER COLUMN id SET DEFAULT nextval('public.schedule_rules_id_seq'::regclass);


--
-- Name: schedule_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedule_snapshots ALTER COLUMN id SET DEFAULT nextval('public.schedule_snapshots_id_seq'::regclass);


--
-- Name: schedules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedules ALTER COLUMN id SET DEFAULT nextval('public.schedules_id_seq'::regclass);


--
-- Name: shift_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_configs ALTER COLUMN id SET DEFAULT nextval('public.shift_configs_id_seq'::regclass);


--
-- Name: shift_swap_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_swap_requests ALTER COLUMN id SET DEFAULT nextval('public.shift_swap_requests_id_seq'::regclass);


--
-- Name: sign_tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sign_tasks ALTER COLUMN id SET DEFAULT nextval('public.sign_tasks_id_seq'::regclass);


--
-- Name: store_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_settings ALTER COLUMN id SET DEFAULT nextval('public.store_settings_id_seq'::regclass);


--
-- Name: stores id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stores ALTER COLUMN id SET DEFAULT nextval('public.stores_id_seq'::regclass);


--
-- Name: table_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_sessions ALTER COLUMN id SET DEFAULT nextval('public.table_sessions_id_seq'::regclass);


--
-- Name: tables id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables ALTER COLUMN id SET DEFAULT nextval('public.tables_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: wine_storage id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wine_storage ALTER COLUMN id SET DEFAULT nextval('public.wine_storage_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
20260615
\.


--
-- Data for Name: approval_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.approval_requests (id, store_id, employee_id, type, status, start_date, end_date, reason, extra, approver_id, approved_at, created_at, updated_at, reject_reason) FROM stdin;
\.


--
-- Data for Name: attendance_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attendance_records (id, store_id, employee_id, date, scheduled_shift, clock_in, clock_out, status, late_minutes, early_minutes, source, note, created_at, updated_at, shift_start_time, shift_end_time, is_overnight) FROM stdin;
332	1	23	2026-06-18	晚班	10:00	09:59	late	895	0	wecom		2026-06-19 02:00:00.002451+00	2026-06-19 02:00:00.002451+00	19:00	03:00	t
333	1	21	2026-06-18	晚班	10:00	09:59	late	895	0	wecom		2026-06-19 02:00:00.002451+00	2026-06-19 02:00:00.002451+00	19:00	03:00	t
321	1	16	2026-06-18	白班	11:52	20:00	present	0	0	wecom		2026-06-18 05:00:00.002737+00	2026-06-19 02:00:00.002451+00	12:00	20:00	f
325	1	12	2026-06-18	晚班	18:51	03:53	present	0	0	wecom		2026-06-18 12:00:00.003139+00	2026-06-19 02:00:00.002451+00	19:00	03:00	t
326	1	24	2026-06-18	晚班	18:51	03:01	present	0	0	wecom		2026-06-18 12:00:00.003139+00	2026-06-19 02:00:00.002451+00	19:00	03:00	t
334	1	17	2026-06-18	晚班	21:19	09:59	late	134	0	wecom		2026-06-19 02:00:00.002451+00	2026-06-19 02:00:00.002451+00	19:00	03:00	t
349	1	16	2026-06-20	白班	11:58	20:00	present	0	0	wecom		2026-06-20 05:00:00.00312+00	2026-06-20 12:10:43.124557+00	12:00	20:00	f
336	1	14	2026-06-19	晚班	17:32	03:43	present	0	0	wecom		2026-06-19 12:00:00.004753+00	2026-06-20 02:00:00.002197+00	19:00	03:00	t
37	1	14	2026-06-01	\N	17:42	03:00	present	0	0	wework		2026-06-15 20:13:39.841961+00	2026-06-15 20:13:39.841961+00	\N	\N	f
38	1	18	2026-06-01	\N	18:34	03:00	present	0	0	wework		2026-06-15 20:13:39.841961+00	2026-06-15 20:13:39.841961+00	\N	\N	f
39	1	13	2026-06-01	\N	18:52	03:00	present	0	0	wework		2026-06-15 20:13:39.841961+00	2026-06-15 20:13:39.841961+00	\N	\N	f
40	1	20	2026-06-01	\N	18:53	03:00	present	0	0	wework		2026-06-15 20:13:39.841961+00	2026-06-15 20:13:39.841961+00	\N	\N	f
41	1	21	2026-06-01	\N	18:53	09:00	present	0	0	wework		2026-06-15 20:13:39.841961+00	2026-06-15 20:13:39.841961+00	\N	\N	f
42	1	23	2026-06-01	\N	18:54	03:08	present	0	0	wework		2026-06-15 20:13:39.841961+00	2026-06-15 20:13:39.841961+00	\N	\N	f
43	1	12	2026-06-01	\N	18:56	03:01	present	0	0	wework		2026-06-15 20:13:39.841961+00	2026-06-15 20:13:39.841961+00	\N	\N	f
44	1	22	2026-06-01	\N	18:58	03:09	present	0	0	wework		2026-06-15 20:13:39.841961+00	2026-06-15 20:13:39.841961+00	\N	\N	f
45	1	17	2026-06-01	\N	21:03	08:59	present	0	0	wework		2026-06-15 20:13:39.841961+00	2026-06-15 20:13:39.841961+00	\N	\N	f
46	1	15	2026-06-01	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:39.841961+00	2026-06-15 20:13:39.841961+00	\N	\N	f
47	1	8	2026-06-01	\N	08:59	\N	present	0	0	wework		2026-06-15 20:13:39.841961+00	2026-06-15 20:13:39.841961+00	\N	\N	f
48	1	19	2026-06-01	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:39.841961+00	2026-06-15 20:13:39.841961+00	\N	\N	f
49	1	16	2026-06-01	\N	08:59	11:55	present	0	0	wework		2026-06-15 20:13:39.841961+00	2026-06-15 20:13:39.841961+00	\N	\N	f
50	1	9	2026-06-01	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:39.841961+00	2026-06-15 20:13:39.841961+00	\N	\N	f
51	1	11	2026-06-01	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:39.841961+00	2026-06-15 20:13:39.841961+00	\N	\N	f
52	1	14	2026-06-02	\N	17:41	03:00	present	0	0	wework		2026-06-15 20:13:40.590743+00	2026-06-15 20:13:40.590743+00	\N	\N	f
53	1	8	2026-06-02	\N	18:46	03:00	present	0	0	wework		2026-06-15 20:13:40.590743+00	2026-06-15 20:13:40.590743+00	\N	\N	f
54	1	13	2026-06-02	\N	18:47	09:00	present	0	0	wework		2026-06-15 20:13:40.590743+00	2026-06-15 20:13:40.590743+00	\N	\N	f
55	1	18	2026-06-02	\N	18:48	09:00	present	0	0	wework		2026-06-15 20:13:40.590743+00	2026-06-15 20:13:40.590743+00	\N	\N	f
56	1	12	2026-06-02	\N	18:51	03:00	present	0	0	wework		2026-06-15 20:13:40.590743+00	2026-06-15 20:13:40.590743+00	\N	\N	f
57	1	22	2026-06-02	\N	18:55	03:00	present	0	0	wework		2026-06-15 20:13:40.590743+00	2026-06-15 20:13:40.590743+00	\N	\N	f
58	1	20	2026-06-02	\N	18:55	03:00	present	0	0	wework		2026-06-15 20:13:40.590743+00	2026-06-15 20:13:40.590743+00	\N	\N	f
59	1	23	2026-06-02	\N	18:57	09:00	present	0	0	wework		2026-06-15 20:13:40.590743+00	2026-06-15 20:13:40.590743+00	\N	\N	f
60	1	16	2026-06-02	\N	20:01	11:56	present	0	0	wework		2026-06-15 20:13:40.590743+00	2026-06-15 20:13:40.590743+00	\N	\N	f
61	1	17	2026-06-02	\N	20:59	08:59	present	0	0	wework		2026-06-15 20:13:40.590743+00	2026-06-15 20:13:40.590743+00	\N	\N	f
62	1	15	2026-06-02	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:40.590743+00	2026-06-15 20:13:40.590743+00	\N	\N	f
63	1	21	2026-06-02	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:40.590743+00	2026-06-15 20:13:40.590743+00	\N	\N	f
64	1	19	2026-06-02	\N	08:59	\N	present	0	0	wework		2026-06-15 20:13:40.590743+00	2026-06-15 20:13:40.590743+00	\N	\N	f
65	1	9	2026-06-02	\N	08:59	\N	present	0	0	wework		2026-06-15 20:13:40.590743+00	2026-06-15 20:13:40.590743+00	\N	\N	f
66	1	11	2026-06-02	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:40.590743+00	2026-06-15 20:13:40.590743+00	\N	\N	f
67	1	14	2026-06-03	\N	17:42	03:02	present	0	0	wework		2026-06-15 20:13:41.208398+00	2026-06-15 20:13:41.208398+00	\N	\N	f
68	1	12	2026-06-03	\N	18:43	03:01	present	0	0	wework		2026-06-15 20:13:41.208398+00	2026-06-15 20:13:41.208398+00	\N	\N	f
69	1	8	2026-06-03	\N	18:44	03:00	present	0	0	wework		2026-06-15 20:13:41.208398+00	2026-06-15 20:13:41.208398+00	\N	\N	f
70	1	22	2026-06-03	\N	18:53	09:00	present	0	0	wework		2026-06-15 20:13:41.208398+00	2026-06-15 20:13:41.208398+00	\N	\N	f
71	1	9	2026-06-03	\N	18:55	03:00	present	0	0	wework		2026-06-15 20:13:41.208398+00	2026-06-15 20:13:41.208398+00	\N	\N	f
72	1	20	2026-06-03	\N	18:58	03:01	present	0	0	wework		2026-06-15 20:13:41.208398+00	2026-06-15 20:13:41.208398+00	\N	\N	f
73	1	19	2026-06-03	\N	18:58	03:00	present	0	0	wework		2026-06-15 20:13:41.208398+00	2026-06-15 20:13:41.208398+00	\N	\N	f
337	1	18	2026-06-19	晚班	17:32	03:00	present	0	0	wecom		2026-06-19 12:00:00.004753+00	2026-06-20 02:00:00.002197+00	19:00	03:00	t
338	1	9	2026-06-19	晚班	17:43	03:00	present	0	0	wecom		2026-06-19 12:00:00.004753+00	2026-06-20 02:00:00.002197+00	19:00	03:00	t
339	1	13	2026-06-19	晚班	17:46	03:00	present	0	0	wecom		2026-06-19 12:00:00.004753+00	2026-06-20 02:00:00.002197+00	19:00	03:00	t
340	1	23	2026-06-19	晚班	17:51	03:26	present	0	0	wecom		2026-06-19 12:00:00.004753+00	2026-06-20 02:00:00.002197+00	19:00	03:00	t
341	1	8	2026-06-19	晚班	17:51	03:00	present	0	0	wecom		2026-06-19 12:00:00.004753+00	2026-06-20 02:00:00.002197+00	19:00	03:00	t
342	1	12	2026-06-19	晚班	17:51	04:45	present	0	0	wecom		2026-06-19 12:00:00.004753+00	2026-06-20 02:00:00.002197+00	19:00	03:00	t
74	1	16	2026-06-03	\N	20:01	11:55	present	0	0	wework		2026-06-15 20:13:41.208398+00	2026-06-15 20:13:41.208398+00	\N	\N	f
75	1	17	2026-06-03	\N	21:05	08:59	present	0	0	wework		2026-06-15 20:13:41.208398+00	2026-06-15 20:13:41.208398+00	\N	\N	f
76	1	23	2026-06-03	\N	08:59	\N	present	0	0	wework		2026-06-15 20:13:41.208398+00	2026-06-15 20:13:41.208398+00	\N	\N	f
77	1	15	2026-06-03	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:41.208398+00	2026-06-15 20:13:41.208398+00	\N	\N	f
78	1	21	2026-06-03	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:41.208398+00	2026-06-15 20:13:41.208398+00	\N	\N	f
79	1	13	2026-06-03	\N	08:59	\N	present	0	0	wework		2026-06-15 20:13:41.208398+00	2026-06-15 20:13:41.208398+00	\N	\N	f
80	1	18	2026-06-03	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:41.208398+00	2026-06-15 20:13:41.208398+00	\N	\N	f
81	1	11	2026-06-03	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:41.208398+00	2026-06-15 20:13:41.208398+00	\N	\N	f
82	1	14	2026-06-04	\N	17:38	03:12	present	0	0	wework		2026-06-15 20:13:41.781484+00	2026-06-15 20:13:41.781484+00	\N	\N	f
83	1	8	2026-06-04	\N	17:48	03:00	present	0	0	wework		2026-06-15 20:13:41.781484+00	2026-06-15 20:13:41.781484+00	\N	\N	f
84	1	13	2026-06-04	\N	18:39	03:00	present	0	0	wework		2026-06-15 20:13:41.781484+00	2026-06-15 20:13:41.781484+00	\N	\N	f
85	1	12	2026-06-04	\N	18:50	03:06	present	0	0	wework		2026-06-15 20:13:41.781484+00	2026-06-15 20:13:41.781484+00	\N	\N	f
86	1	9	2026-06-04	\N	18:52	03:00	present	0	0	wework		2026-06-15 20:13:41.781484+00	2026-06-15 20:13:41.781484+00	\N	\N	f
87	1	23	2026-06-04	\N	18:53	03:24	present	0	0	wework		2026-06-15 20:13:41.781484+00	2026-06-15 20:13:41.781484+00	\N	\N	f
88	1	19	2026-06-04	\N	18:57	03:06	present	0	0	wework		2026-06-15 20:13:41.781484+00	2026-06-15 20:13:41.781484+00	\N	\N	f
89	1	20	2026-06-04	\N	18:58	03:06	present	0	0	wework		2026-06-15 20:13:41.781484+00	2026-06-15 20:13:41.781484+00	\N	\N	f
90	1	16	2026-06-04	\N	20:00	11:57	present	0	0	wework		2026-06-15 20:13:41.781484+00	2026-06-15 20:13:41.781484+00	\N	\N	f
91	1	17	2026-06-04	\N	21:07	08:59	present	0	0	wework		2026-06-15 20:13:41.781484+00	2026-06-15 20:13:41.781484+00	\N	\N	f
92	1	15	2026-06-04	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:41.781484+00	2026-06-15 20:13:41.781484+00	\N	\N	f
93	1	21	2026-06-04	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:41.781484+00	2026-06-15 20:13:41.781484+00	\N	\N	f
94	1	22	2026-06-04	\N	08:59	\N	present	0	0	wework		2026-06-15 20:13:41.781484+00	2026-06-15 20:13:41.781484+00	\N	\N	f
95	1	18	2026-06-04	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:41.781484+00	2026-06-15 20:13:41.781484+00	\N	\N	f
96	1	11	2026-06-04	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:41.781484+00	2026-06-15 20:13:41.781484+00	\N	\N	f
97	1	9	2026-06-05	\N	17:35	03:01	present	0	0	wework		2026-06-15 20:13:42.335227+00	2026-06-15 20:13:42.335227+00	\N	\N	f
98	1	14	2026-06-05	\N	17:39	03:00	present	0	0	wework		2026-06-15 20:13:42.335227+00	2026-06-15 20:13:42.335227+00	\N	\N	f
99	1	13	2026-06-05	\N	17:45	03:00	present	0	0	wework		2026-06-15 20:13:42.335227+00	2026-06-15 20:13:42.335227+00	\N	\N	f
100	1	8	2026-06-05	\N	17:45	03:00	present	0	0	wework		2026-06-15 20:13:42.335227+00	2026-06-15 20:13:42.335227+00	\N	\N	f
101	1	23	2026-06-05	\N	17:46	03:03	present	0	0	wework		2026-06-15 20:13:42.335227+00	2026-06-15 20:13:42.335227+00	\N	\N	f
102	1	12	2026-06-05	\N	17:50	03:00	present	0	0	wework		2026-06-15 20:13:42.335227+00	2026-06-15 20:13:42.335227+00	\N	\N	f
103	1	22	2026-06-05	\N	17:50	03:03	present	0	0	wework		2026-06-15 20:13:42.335227+00	2026-06-15 20:13:42.335227+00	\N	\N	f
104	1	20	2026-06-05	\N	18:00	03:01	present	0	0	wework		2026-06-15 20:13:42.335227+00	2026-06-15 20:13:42.335227+00	\N	\N	f
105	1	19	2026-06-05	\N	18:00	03:00	present	0	0	wework		2026-06-15 20:13:42.335227+00	2026-06-15 20:13:42.335227+00	\N	\N	f
106	1	16	2026-06-05	\N	20:00	11:57	present	0	0	wework		2026-06-15 20:13:42.335227+00	2026-06-15 20:13:42.335227+00	\N	\N	f
107	1	17	2026-06-05	\N	21:05	08:59	present	0	0	wework		2026-06-15 20:13:42.335227+00	2026-06-15 20:13:42.335227+00	\N	\N	f
108	1	15	2026-06-05	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:42.335227+00	2026-06-15 20:13:42.335227+00	\N	\N	f
109	1	21	2026-06-05	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:42.335227+00	2026-06-15 20:13:42.335227+00	\N	\N	f
110	1	18	2026-06-05	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:42.335227+00	2026-06-15 20:13:42.335227+00	\N	\N	f
111	1	11	2026-06-05	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:42.335227+00	2026-06-15 20:13:42.335227+00	\N	\N	f
112	1	14	2026-06-06	\N	17:38	03:13	present	0	0	wework		2026-06-15 20:13:42.919408+00	2026-06-15 20:13:42.919408+00	\N	\N	f
113	1	20	2026-06-06	\N	17:52	03:17	present	0	0	wework		2026-06-15 20:13:42.919408+00	2026-06-15 20:13:42.919408+00	\N	\N	f
114	1	22	2026-06-06	\N	17:52	03:07	present	0	0	wework		2026-06-15 20:13:42.919408+00	2026-06-15 20:13:42.919408+00	\N	\N	f
115	1	19	2026-06-06	\N	17:52	03:17	present	0	0	wework		2026-06-15 20:13:42.919408+00	2026-06-15 20:13:42.919408+00	\N	\N	f
116	1	8	2026-06-06	\N	17:52	03:05	present	0	0	wework		2026-06-15 20:13:42.919408+00	2026-06-15 20:13:42.919408+00	\N	\N	f
117	1	12	2026-06-06	\N	17:53	09:00	present	0	0	wework		2026-06-15 20:13:42.919408+00	2026-06-15 20:13:42.919408+00	\N	\N	f
118	1	23	2026-06-06	\N	17:55	03:07	present	0	0	wework		2026-06-15 20:13:42.919408+00	2026-06-15 20:13:42.919408+00	\N	\N	f
119	1	13	2026-06-06	\N	17:56	03:05	present	0	0	wework		2026-06-15 20:13:42.919408+00	2026-06-15 20:13:42.919408+00	\N	\N	f
120	1	9	2026-06-06	\N	17:59	03:02	present	0	0	wework		2026-06-15 20:13:42.919408+00	2026-06-15 20:13:42.919408+00	\N	\N	f
121	1	16	2026-06-06	\N	20:02	11:57	present	0	0	wework		2026-06-15 20:13:42.919408+00	2026-06-15 20:13:42.919408+00	\N	\N	f
122	1	17	2026-06-06	\N	22:54	08:59	present	0	0	wework		2026-06-15 20:13:42.919408+00	2026-06-15 20:13:42.919408+00	\N	\N	f
123	1	15	2026-06-06	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:42.919408+00	2026-06-15 20:13:42.919408+00	\N	\N	f
124	1	21	2026-06-06	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:42.919408+00	2026-06-15 20:13:42.919408+00	\N	\N	f
125	1	18	2026-06-06	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:42.919408+00	2026-06-15 20:13:42.919408+00	\N	\N	f
126	1	11	2026-06-06	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:42.919408+00	2026-06-15 20:13:42.919408+00	\N	\N	f
127	1	14	2026-06-07	\N	17:47	03:01	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
128	1	13	2026-06-07	\N	18:35	03:00	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
129	1	9	2026-06-07	\N	18:51	03:00	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
130	1	22	2026-06-07	\N	18:51	09:00	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
131	1	8	2026-06-07	\N	18:52	03:00	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
132	1	23	2026-06-07	\N	18:57	03:01	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
133	1	20	2026-06-07	\N	18:57	03:02	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
134	1	19	2026-06-07	\N	18:57	03:00	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
135	1	16	2026-06-07	\N	20:00	09:00	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
136	1	17	2026-06-07	\N	21:05	08:59	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
137	1	15	2026-06-07	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
138	1	12	2026-06-07	\N	08:59	\N	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
139	1	21	2026-06-07	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
140	1	18	2026-06-07	\N	08:59	\N	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
141	1	11	2026-06-07	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
142	1	24	2026-06-07	\N	09:00	\N	present	0	0	wework		2026-06-15 20:13:43.477265+00	2026-06-15 20:13:43.477265+00	\N	\N	f
143	1	14	2026-06-08	\N	17:53	02:59	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
144	1	18	2026-06-08	\N	18:29	03:00	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
145	1	13	2026-06-08	\N	18:35	03:00	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
146	1	8	2026-06-08	\N	18:47	09:00	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
147	1	20	2026-06-08	\N	18:51	09:00	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
148	1	19	2026-06-08	\N	18:52	09:00	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
149	1	12	2026-06-08	\N	18:53	03:01	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
150	1	23	2026-06-08	\N	19:02	03:07	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
151	1	9	2026-06-08	\N	19:03	09:00	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
152	1	17	2026-06-08	\N	21:09	08:59	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
153	1	24	2026-06-08	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
154	1	15	2026-06-08	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
155	1	21	2026-06-08	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
156	1	16	2026-06-08	\N	08:59	11:56	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
157	1	22	2026-06-08	\N	08:59	\N	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
158	1	11	2026-06-08	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:44.046168+00	2026-06-15 20:13:44.046168+00	\N	\N	f
159	1	14	2026-06-09	\N	17:45	03:00	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
160	1	18	2026-06-09	\N	18:48	03:00	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
161	1	12	2026-06-09	\N	18:51	03:00	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
162	1	13	2026-06-09	\N	18:52	09:00	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
163	1	23	2026-06-09	\N	18:56	03:03	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
164	1	22	2026-06-09	\N	18:59	03:03	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
165	1	16	2026-06-09	\N	20:00	09:00	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
166	1	17	2026-06-09	\N	21:07	08:59	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
167	1	24	2026-06-09	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
168	1	15	2026-06-09	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
169	1	21	2026-06-09	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
170	1	8	2026-06-09	\N	08:59	\N	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
171	1	19	2026-06-09	\N	08:59	\N	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
172	1	20	2026-06-09	\N	08:59	\N	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
173	1	9	2026-06-09	\N	08:59	\N	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
174	1	11	2026-06-09	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:44.664082+00	2026-06-15 20:13:44.664082+00	\N	\N	f
175	1	14	2026-06-10	\N	17:57	03:04	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
176	1	18	2026-06-10	\N	18:24	03:00	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
177	1	8	2026-06-10	\N	18:50	09:00	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
178	1	12	2026-06-10	\N	18:51	03:02	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
179	1	22	2026-06-10	\N	18:55	03:04	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
180	1	9	2026-06-10	\N	18:56	03:02	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
181	1	23	2026-06-10	\N	18:58	03:04	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
182	1	20	2026-06-10	\N	18:59	03:01	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
183	1	19	2026-06-10	\N	19:00	03:01	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
184	1	17	2026-06-10	\N	21:11	08:59	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
185	1	24	2026-06-10	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
186	1	15	2026-06-10	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
187	1	21	2026-06-10	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
188	1	16	2026-06-10	\N	08:59	11:55	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
189	1	13	2026-06-10	\N	08:59	\N	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
190	1	11	2026-06-10	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:45.233645+00	2026-06-15 20:13:45.233645+00	\N	\N	f
191	1	14	2026-06-11	\N	17:41	03:38	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
192	1	18	2026-06-11	\N	18:12	03:13	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
193	1	23	2026-06-11	\N	18:51	03:06	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
194	1	13	2026-06-11	\N	18:52	03:19	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
195	1	12	2026-06-11	\N	18:54	06:08	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
196	1	20	2026-06-11	\N	18:57	03:15	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
197	1	19	2026-06-11	\N	18:57	03:15	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
198	1	22	2026-06-11	\N	18:59	03:00	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
199	1	9	2026-06-11	\N	18:59	03:00	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
200	1	16	2026-06-11	\N	20:00	11:56	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
201	1	17	2026-06-11	\N	20:56	08:59	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
202	1	24	2026-06-11	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
203	1	15	2026-06-11	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
204	1	21	2026-06-11	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
205	1	8	2026-06-11	\N	08:59	\N	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
206	1	11	2026-06-11	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:45.803106+00	2026-06-15 20:13:45.803106+00	\N	\N	f
207	1	14	2026-06-12	\N	17:34	03:06	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
208	1	18	2026-06-12	\N	17:38	03:19	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
209	1	8	2026-06-12	\N	17:47	03:16	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
210	1	12	2026-06-12	\N	17:47	03:03	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
211	1	22	2026-06-12	\N	17:53	03:00	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
212	1	23	2026-06-12	\N	17:53	03:05	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
213	1	19	2026-06-12	\N	17:58	03:01	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
214	1	20	2026-06-12	\N	17:58	03:03	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
215	1	16	2026-06-12	\N	20:01	11:55	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
216	1	17	2026-06-12	\N	20:59	08:59	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
217	1	13	2026-06-12	\N	03:20	08:59	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
218	1	9	2026-06-12	\N	03:38	08:59	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
219	1	24	2026-06-12	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
220	1	15	2026-06-12	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
221	1	21	2026-06-12	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
222	1	11	2026-06-12	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:46.342638+00	2026-06-15 20:13:46.342638+00	\N	\N	f
223	1	14	2026-06-13	\N	17:35	09:00	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
224	1	18	2026-06-13	\N	17:41	09:00	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
225	1	22	2026-06-13	\N	17:49	09:00	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
226	1	13	2026-06-13	\N	17:51	09:00	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
227	1	9	2026-06-13	\N	17:53	09:00	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
228	1	12	2026-06-13	\N	17:54	09:00	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
229	1	23	2026-06-13	\N	17:56	09:00	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
230	1	8	2026-06-13	\N	18:12	09:00	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
231	1	16	2026-06-13	\N	20:00	11:59	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
232	1	17	2026-06-13	\N	21:09	09:00	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
233	1	19	2026-06-13	\N	03:00	09:00	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
234	1	20	2026-06-13	\N	03:01	09:00	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
235	1	24	2026-06-13	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
236	1	15	2026-06-13	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
237	1	21	2026-06-13	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
238	1	11	2026-06-13	\N	08:59	09:00	present	0	0	wework		2026-06-15 20:13:46.931624+00	2026-06-15 20:13:46.931624+00	\N	\N	f
239	1	14	2026-06-14	\N	17:32	03:11	present	0	0	wework		2026-06-15 20:13:47.595324+00	2026-06-15 20:13:47.595324+00	\N	\N	f
240	1	8	2026-06-14	\N	18:48	03:00	present	0	0	wework		2026-06-15 20:13:47.595324+00	2026-06-15 20:13:47.595324+00	\N	\N	f
241	1	23	2026-06-14	\N	18:53	03:24	present	0	0	wework		2026-06-15 20:13:47.595324+00	2026-06-15 20:13:47.595324+00	\N	\N	f
242	1	9	2026-06-14	\N	18:53	03:00	present	0	0	wework		2026-06-15 20:13:47.595324+00	2026-06-15 20:13:47.595324+00	\N	\N	f
243	1	20	2026-06-14	\N	18:57	03:27	present	0	0	wework		2026-06-15 20:13:47.595324+00	2026-06-15 20:13:47.595324+00	\N	\N	f
244	1	19	2026-06-14	\N	18:57	03:25	present	0	0	wework		2026-06-15 20:13:47.595324+00	2026-06-15 20:13:47.595324+00	\N	\N	f
245	1	13	2026-06-14	\N	18:57	03:01	present	0	0	wework		2026-06-15 20:13:47.595324+00	2026-06-15 20:13:47.595324+00	\N	\N	f
246	1	16	2026-06-14	\N	20:01	\N	present	0	0	wework		2026-06-15 20:13:47.595324+00	2026-06-15 20:13:47.595324+00	\N	\N	f
247	1	17	2026-06-14	\N	21:15	\N	present	0	0	wework		2026-06-15 20:13:47.595324+00	2026-06-15 20:13:47.595324+00	\N	\N	f
322	1	14	2026-06-18	晚班	17:36	03:06	present	0	0	wecom		2026-06-18 12:00:00.003139+00	2026-06-19 02:00:00.002451+00	19:00	03:00	t
323	1	18	2026-06-18	晚班	18:32	03:00	present	0	0	wecom		2026-06-18 12:00:00.003139+00	2026-06-19 02:00:00.002451+00	19:00	03:00	t
324	1	8	2026-06-18	晚班	18:43	03:00	present	0	0	wecom		2026-06-18 12:00:00.003139+00	2026-06-19 02:00:00.002451+00	19:00	03:00	t
280	1	24	2026-06-15	晚班	10:00	09:59	late	895	0	wecom		2026-06-16 15:12:03.625362+00	2026-06-16 15:12:03.625362+00	19:00	03:00	t
281	1	23	2026-06-15	晚班	10:00	09:59	late	895	0	wecom		2026-06-16 15:12:03.625362+00	2026-06-16 15:12:03.625362+00	19:00	03:00	t
282	1	12	2026-06-15	晚班	10:00	09:59	late	895	0	wecom		2026-06-16 15:12:03.625362+00	2026-06-16 15:12:03.625362+00	19:00	03:00	t
283	1	21	2026-06-15	晚班	10:00	09:59	late	895	0	wecom		2026-06-16 15:12:03.625362+00	2026-06-16 15:12:03.625362+00	19:00	03:00	t
284	1	8	2026-06-15	晚班	10:00	09:59	late	895	0	wecom		2026-06-16 15:12:03.625362+00	2026-06-16 15:12:03.625362+00	19:00	03:00	t
285	1	17	2026-06-15	晚班	10:00	09:59	late	895	0	wecom		2026-06-16 15:12:03.625362+00	2026-06-16 15:12:03.625362+00	19:00	03:00	t
286	1	19	2026-06-15	晚班	10:00	09:59	late	895	0	wecom		2026-06-16 15:12:03.625362+00	2026-06-16 15:12:03.625362+00	19:00	03:00	t
287	1	20	2026-06-15	晚班	10:00	09:59	late	895	0	wecom		2026-06-16 15:12:03.625362+00	2026-06-16 15:12:03.625362+00	19:00	03:00	t
288	1	16	2026-06-15	白班	10:00	09:59	early	0	596	wecom		2026-06-16 15:12:03.625362+00	2026-06-16 15:12:03.625362+00	12:00	20:00	f
289	1	22	2026-06-15	晚班	10:00	09:59	late	895	0	wecom		2026-06-16 15:12:03.625362+00	2026-06-16 15:12:03.625362+00	19:00	03:00	t
290	1	13	2026-06-15	晚班	10:00	09:59	late	895	0	wecom		2026-06-16 15:12:03.625362+00	2026-06-16 15:12:03.625362+00	19:00	03:00	t
291	1	18	2026-06-15	晚班	10:00	09:59	late	895	0	wecom		2026-06-16 15:12:03.625362+00	2026-06-16 15:12:03.625362+00	19:00	03:00	t
292	1	14	2026-06-15	晚班	10:00	09:59	late	895	0	wecom		2026-06-16 15:12:03.625362+00	2026-06-16 15:12:03.625362+00	19:00	03:00	t
293	1	9	2026-06-15	晚班	10:00	09:59	late	895	0	wecom		2026-06-16 15:12:03.625362+00	2026-06-16 15:12:03.625362+00	19:00	03:00	t
294	1	24	2026-06-16	晚班	10:00	09:59	late	895	0	wecom		2026-06-17 02:00:00.003373+00	2026-06-17 02:00:00.003373+00	19:00	03:00	t
295	1	23	2026-06-16	晚班	10:00	09:59	late	895	0	wecom		2026-06-17 02:00:00.003373+00	2026-06-17 02:00:00.003373+00	19:00	03:00	t
296	1	21	2026-06-16	晚班	10:00	09:59	late	895	0	wecom		2026-06-17 02:00:00.003373+00	2026-06-17 02:00:00.003373+00	19:00	03:00	t
297	1	8	2026-06-16	晚班	10:00	09:59	late	895	0	wecom		2026-06-17 02:00:00.003373+00	2026-06-17 02:00:00.003373+00	19:00	03:00	t
298	1	17	2026-06-16	晚班	10:00	09:59	late	895	0	wecom		2026-06-17 02:00:00.003373+00	2026-06-17 02:00:00.003373+00	19:00	03:00	t
299	1	20	2026-06-16	晚班	10:00	09:59	late	895	0	wecom		2026-06-17 02:00:00.003373+00	2026-06-17 02:00:00.003373+00	19:00	03:00	t
279	1	16	2026-06-16	白班	10:00	09:59	early	0	596	wecom		2026-06-16 15:11:33.337993+00	2026-06-17 02:00:00.003373+00	12:00	20:00	f
300	1	9	2026-06-16	晚班	10:00	09:59	late	895	0	wecom		2026-06-17 02:00:00.003373+00	2026-06-17 02:00:00.003373+00	19:00	03:00	t
301	1	14	2026-06-16	晚班	02:59	09:59	late	474	0	wecom		2026-06-17 02:00:00.003373+00	2026-06-17 02:00:00.003373+00	19:00	03:00	t
302	1	13	2026-06-16	晚班	03:00	09:59	late	475	0	wecom		2026-06-17 02:00:00.003373+00	2026-06-17 02:00:00.003373+00	19:00	03:00	t
303	1	18	2026-06-16	晚班	03:00	09:59	late	475	0	wecom		2026-06-17 02:00:00.003373+00	2026-06-17 02:00:00.003373+00	19:00	03:00	t
304	1	19	2026-06-16	晚班	03:01	09:59	late	476	0	wecom		2026-06-17 02:00:00.003373+00	2026-06-17 02:00:00.003373+00	19:00	03:00	t
305	1	22	2026-06-16	晚班	03:01	09:59	late	476	0	wecom		2026-06-17 02:00:00.003373+00	2026-06-17 02:00:00.003373+00	19:00	03:00	t
306	1	12	2026-06-16	晚班	03:02	09:59	late	477	0	wecom		2026-06-17 02:00:00.003373+00	2026-06-17 02:00:00.003373+00	19:00	03:00	t
315	1	23	2026-06-17	晚班	10:00	09:59	late	895	0	wecom		2026-06-18 02:00:00.004109+00	2026-06-18 02:00:00.004109+00	19:00	03:00	t
316	1	21	2026-06-17	晚班	10:00	09:59	late	895	0	wecom		2026-06-18 02:00:00.004109+00	2026-06-18 02:00:00.004109+00	19:00	03:00	t
317	1	19	2026-06-17	晚班	10:00	09:59	late	895	0	wecom		2026-06-18 02:00:00.004109+00	2026-06-18 02:00:00.004109+00	19:00	03:00	t
318	1	13	2026-06-17	晚班	10:00	09:59	late	895	0	wecom		2026-06-18 02:00:00.004109+00	2026-06-18 02:00:00.004109+00	19:00	03:00	t
327	1	22	2026-06-18	晚班	18:54	03:22	present	0	0	wecom		2026-06-18 12:00:00.003139+00	2026-06-19 02:00:00.002451+00	19:00	03:00	t
307	1	16	2026-06-17	白班	11:57	20:03	present	0	0	wecom		2026-06-17 05:00:00.00293+00	2026-06-18 02:00:00.004109+00	12:00	20:00	f
308	1	14	2026-06-17	晚班	17:34	03:17	present	0	0	wecom		2026-06-17 12:00:00.002526+00	2026-06-18 02:00:00.004109+00	19:00	03:00	t
328	1	13	2026-06-18	晚班	18:56	03:03	present	0	0	wecom		2026-06-18 12:00:00.003139+00	2026-06-19 02:00:00.002451+00	19:00	03:00	t
309	1	8	2026-06-17	晚班	18:06	03:00	present	0	0	wecom		2026-06-17 12:00:00.002526+00	2026-06-18 02:00:00.004109+00	19:00	03:00	t
310	1	18	2026-06-17	晚班	18:41	03:00	present	0	0	wecom		2026-06-17 12:00:00.002526+00	2026-06-18 02:00:00.004109+00	19:00	03:00	t
329	1	19	2026-06-18	晚班	18:59	03:02	present	0	0	wecom		2026-06-18 12:00:00.003139+00	2026-06-19 02:00:00.002451+00	19:00	03:00	t
311	1	12	2026-06-17	晚班	18:46	03:07	present	0	0	wecom		2026-06-17 12:00:00.002526+00	2026-06-18 02:00:00.004109+00	19:00	03:00	t
312	1	22	2026-06-17	晚班	18:51	03:00	present	0	0	wecom		2026-06-17 12:00:00.002526+00	2026-06-18 02:00:00.004109+00	19:00	03:00	t
330	1	20	2026-06-18	晚班	18:59	03:02	present	0	0	wecom		2026-06-18 12:00:00.003139+00	2026-06-19 02:00:00.002451+00	19:00	03:00	t
313	1	20	2026-06-17	晚班	18:54	03:01	present	0	0	wecom		2026-06-17 12:00:00.002526+00	2026-06-18 02:00:00.004109+00	19:00	03:00	t
314	1	9	2026-06-17	晚班	19:14	03:01	late	9	0	wecom		2026-06-17 12:00:00.002526+00	2026-06-18 02:00:00.004109+00	19:00	03:00	t
319	1	17	2026-06-17	晚班	21:00	09:59	late	115	0	wecom		2026-06-18 02:00:00.004109+00	2026-06-18 02:00:00.004109+00	19:00	03:00	t
320	1	24	2026-06-17	晚班	03:09	09:59	late	484	0	wecom		2026-06-18 02:00:00.004109+00	2026-06-18 02:00:00.004109+00	19:00	03:00	t
331	1	9	2026-06-18	晚班	19:10	03:00	late	5	0	wecom		2026-06-18 12:00:00.003139+00	2026-06-19 02:00:00.002451+00	19:00	03:00	t
347	1	21	2026-06-19	晚班	10:00	09:59	late	895	0	wecom		2026-06-20 02:00:00.002197+00	2026-06-20 02:00:00.002197+00	19:00	03:00	t
335	1	16	2026-06-19	白班	11:58	20:01	present	0	0	wecom		2026-06-19 05:00:00.00311+00	2026-06-20 02:00:00.002197+00	12:00	20:00	f
343	1	24	2026-06-19	晚班	17:52	04:46	present	0	0	wecom		2026-06-19 12:00:00.004753+00	2026-06-20 02:00:00.002197+00	19:00	03:00	t
344	1	22	2026-06-19	晚班	17:53	03:05	present	0	0	wecom		2026-06-19 12:00:00.004753+00	2026-06-20 02:00:00.002197+00	19:00	03:00	t
345	1	20	2026-06-19	晚班	17:56	03:03	present	0	0	wecom		2026-06-19 12:00:00.004753+00	2026-06-20 02:00:00.002197+00	19:00	03:00	t
346	1	19	2026-06-19	晚班	17:57	03:03	present	0	0	wecom		2026-06-19 12:00:00.004753+00	2026-06-20 02:00:00.002197+00	19:00	03:00	t
348	1	17	2026-06-19	晚班	21:07	09:59	late	122	0	wecom		2026-06-20 02:00:00.002197+00	2026-06-20 02:00:00.002197+00	19:00	03:00	t
350	1	18	2026-06-20	晚班	17:32	\N	present	0	0	wecom		2026-06-20 12:00:00.002058+00	2026-06-20 12:10:43.124557+00	19:00	03:00	t
351	1	23	2026-06-20	晚班	17:36	\N	present	0	0	wecom		2026-06-20 12:00:00.002058+00	2026-06-20 12:10:43.124557+00	19:00	03:00	t
352	1	14	2026-06-20	晚班	17:38	\N	present	0	0	wecom		2026-06-20 12:00:00.002058+00	2026-06-20 12:10:43.124557+00	19:00	03:00	t
353	1	13	2026-06-20	晚班	17:40	\N	present	0	0	wecom		2026-06-20 12:00:00.002058+00	2026-06-20 12:10:43.124557+00	19:00	03:00	t
354	1	8	2026-06-20	晚班	17:47	\N	present	0	0	wecom		2026-06-20 12:00:00.002058+00	2026-06-20 12:10:43.124557+00	19:00	03:00	t
355	1	9	2026-06-20	晚班	17:47	\N	present	0	0	wecom		2026-06-20 12:00:00.002058+00	2026-06-20 12:10:43.124557+00	19:00	03:00	t
356	1	24	2026-06-20	晚班	17:49	\N	present	0	0	wecom		2026-06-20 12:00:00.002058+00	2026-06-20 12:10:43.124557+00	19:00	03:00	t
357	1	12	2026-06-20	晚班	17:50	\N	present	0	0	wecom		2026-06-20 12:00:00.002058+00	2026-06-20 12:10:43.124557+00	19:00	03:00	t
358	1	22	2026-06-20	晚班	17:54	\N	present	0	0	wecom		2026-06-20 12:00:00.002058+00	2026-06-20 12:10:43.124557+00	19:00	03:00	t
359	1	20	2026-06-20	晚班	17:57	\N	present	0	0	wecom		2026-06-20 12:00:00.002058+00	2026-06-20 12:10:43.124557+00	19:00	03:00	t
360	1	19	2026-06-20	晚班	17:57	\N	present	0	0	wecom		2026-06-20 12:00:00.002058+00	2026-06-20 12:10:43.124557+00	19:00	03:00	t
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, user_id, store_id, action, entity_type, entity_id, old_value, new_value, request_id, ip_address, user_agent, created_at) FROM stdin;
1	\N	\N	create	auth	\N	\N	\N	3f1aac7f-f6dd-45c1-a84d-71c29365d0c9	127.0.0.1	curl/7.81.0	2026-06-13T17:09:24.231727+00:00
2	\N	\N	create	auth	\N	\N	\N	cbfbfec3-5279-4cc3-a82b-209d6f34b8fd	127.0.0.1	curl/7.81.0	2026-06-13T17:09:34.821675+00:00
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bookings (id, store_id, customer_name, phone, date, time_slot, guests_count, table_id, table_no, source, status, notes, created_at, updated_at, created_by) FROM stdin;
239	1	小李	18600010996	2026-06-20		8	379	14	staff	cancelled		2026-06-20 17:21:31.33414+00	2026-06-20 18:23:19.043759+00	\N
238	1	王哥	18600010999	2026-06-20		8	378	13	staff	cancelled		2026-06-20 17:20:55.597093+00	2026-06-20 18:23:24.179777+00	\N
236	1	贝贝	18500043313	2026-06-20		8	377	12	staff	cancelled		2026-06-20 17:14:46.426161+00	2026-06-20 18:28:01.947064+00	\N
240	1	????	13800138000	2026-06-21	19:00-21:00	4	376	11	staff	cancelled	????	2026-06-20 18:32:05.169525+00	2026-06-20 18:32:05.618005+00	\N
235	1	三代	18600010997	2026-06-20		8	376	11	staff	cancelled		2026-06-20 17:06:26.203811+00	2026-06-20 18:35:42.753062+00	\N
242	1	??	13800138000	2026-06-21	\N	2	376	11	staff	cancelled	\N	2026-06-20 18:42:10.525531+00	2026-06-20 18:42:11.089867+00	\N
241	1	sand	18600009999	2026-06-20		8	376	11	staff	cancelled		2026-06-20 18:37:00.316978+00	2026-06-20 18:42:38.566399+00	\N
237	1	男哥	18500043312	2026-06-20		12	361	1	staff	cancelled		2026-06-20 17:15:42.11365+00	2026-06-20 18:44:02.625368+00	\N
243	1	123	12345678901	2026-06-20		12	361	1	staff	cancelled		2026-06-20 18:46:54.956665+00	2026-06-20 18:46:59.465802+00	\N
\.


--
-- Data for Name: closing_checklist_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.closing_checklist_items (id, template_id, item_name, item_type, device_id, required_photo, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: closing_checklist_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.closing_checklist_templates (id, store_id, name, session_type, role_tag, sort_order, is_active, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: closing_item_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.closing_item_results (id, session_id, template_id, item_id, item_name, item_type, completed_by, photo_url, ai_result, review_status, review_user_id, review_comment, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: closing_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.closing_sessions (id, store_id, session_type, operator_user_id, status, started_at, completed_at, total_items, completed_items, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.companies (id, name, brand, tax_id, status, created_at, updated_at) FROM stdin;
1	北京跨时餐饮有限公司	Crush	91110105MADYP9JH2X	active	2026-06-13 12:27:10.556917+00	2026-06-13 12:27:10.556917+00
\.


--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contracts (id, store_id, employee_id, contract_no, "position", grade, monthly_salary, base_salary, meal_allowance, allowance, start_date, end_date, status, esign_flow_id, signed_at, signed_by, template_data, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: daily_revenue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_revenue (store_id, date, total_revenue, total_orders, total_guests, avg_order_value, total_discounts, bottle_sales, card_sales, data_source, source_raw, synced_at) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.employees (id, store_id, employee_code, name, phone, role, base_salary, hire_date, status, wework_userid, skill_tags, is_first_manager, is_second_manager, notes, created_at, updated_at, shift_group, is_third_manager) FROM stdin;
8	1	WX-ChenZi	陈梓	\N	staff	0	2026-06-15	active	ChenZi	\N	f	f	\N	2026-06-15 08:16:35.445215+00	2026-06-15 08:16:35.445215+00	\N	f
14	1	WX-LuXiaoQin	路小琴	\N	staff	0	2026-06-15	active	LuXiaoQin	\N	f	f	\N	2026-06-15 08:16:35.445215+00	2026-06-15 08:16:35.445215+00	\N	f
17	1	WX-WangZiHeng	王梓蘅	\N	staff	0	2026-06-15	active	WangZiHeng	\N	f	f	\N	2026-06-15 08:16:35.445215+00	2026-06-15 08:16:35.445215+00	\N	f
18	1	WX-JinTianTia	靳恬恬	\N	staff	0	2026-06-15	active	JinTianTian_1	\N	f	f	\N	2026-06-15 08:16:35.445215+00	2026-06-15 08:16:35.445215+00	\N	f
19	1	WX-WangYaRong	王亚荣	\N	staff	0	2026-06-15	active	WangYaRong	\N	f	f	\N	2026-06-15 08:16:35.445215+00	2026-06-15 08:16:35.445215+00	\N	f
21	1	WX-max	纪长龙	\N	staff	0	2026-06-15	active	max	\N	f	f	\N	2026-06-15 08:16:35.445215+00	2026-06-15 08:16:35.445215+00	\N	f
22	1	WX-HuangXiaoL	黄小龙	\N	staff	0	2026-06-15	active	HuangXiaoLong	\N	f	f	\N	2026-06-15 08:16:35.445215+00	2026-06-15 08:16:35.445215+00	\N	f
23	1	WX-WuJiQiang	吴吉强	\N	staff	0	2026-06-15	active	WuJiQiang	\N	f	f	\N	2026-06-15 08:16:35.445215+00	2026-06-15 08:16:35.445215+00	\N	f
24	1	WX-ZhaoYongBo	赵庸博	\N	staff	0	2026-06-15	active	ZhaoYongBo	\N	f	f	\N	2026-06-15 08:16:35.445215+00	2026-06-15 08:16:35.445215+00	\N	f
7	1	WX-ZhouPengFe	周鹏飞	\N	boss	0	2026-06-15	active	ZhouPengFei	\N	f	f	\N	2026-06-15 08:16:35.445215+00	2026-06-15 09:26:18.514961+00	\N	f
11	1	WX-ZhangHanTi	卡西（设计师🧑‍🎨别踢我）	\N	boss	0	2026-06-15	active	ZhangHanTing	\N	f	f	\N	2026-06-15 08:16:35.445215+00	2026-06-15 09:26:18.514961+00	\N	f
6	1	EMP001	管理员	13800000000	boss	3000	2026-06-13	active	\N	\N	f	f	\N	2026-06-13 17:25:23.177746+00	2026-06-15 19:01:15.319213+00	\N	f
10	1	WX-bbmayo	王柏霄	\N	boss	0	2026-06-15	active	bbmayo	\N	t	f	\N	2026-06-15 08:16:35.445215+00	2026-06-15 22:26:58.656229+00	day	f
13	1	WX-ZhaoJiangX	赵疆轩	\N	staff	0	2026-06-15	active	ZhaoJiangXuan	\N	f	t	\N	2026-06-15 08:16:35.445215+00	2026-06-16 09:48:34.594237+00	\N	f
12	1	WX-WangNingBo	王宁波	\N	store_manager	0	2026-06-15	active	WangNingBo	\N	t	f	\N	2026-06-15 08:16:35.445215+00	2026-06-16 09:48:34.594237+00	\N	f
15	1	WX-QinTao	秦韬	\N	store_manager	0	2026-06-15	inactive	QinTao	\N	f	f	\N	2026-06-15 08:16:35.445215+00	2026-06-15 09:26:18.514961+00	\N	f
16	1	WX-YangYingYi	杨莹莹	\N	staff	0	2026-06-15	active	YangYingYing	\N	f	f	\N	2026-06-15 08:16:35.445215+00	2026-06-15 08:16:35.445215+00	day	f
9	1	WX-SunYu	孙宇	\N	staff	0	2026-06-15	active	SunYu	\N	f	f	\N	2026-06-15 08:16:35.445215+00	2026-06-16 18:01:07.347434+00	\N	t
20	1	WX-LiYingXiu	李营秀	\N	staff	0	2026-06-15	active	LiYingXiu	\N	f	f	\N	2026-06-15 08:16:35.445215+00	2026-06-16 18:01:07.347434+00	\N	f
\.


--
-- Data for Name: guest_ratings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.guest_ratings (id, store_id, table_no, food_quality, food_speed, drink_quality, drink_speed, service_attitude, service_speed, cleanliness, overall_score, comment, source, is_low_score, notified, notified_at, store_response, response_by, responded_at, created_at) FROM stdin;
\.


--
-- Data for Name: kpi_appeals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kpi_appeals (id, result_id, employee_id, dimension, reason, evidence, status, reviewed_by, resolution, resolved_at, created_at) FROM stdin;
\.


--
-- Data for Name: kpi_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kpi_results (id, employee_id, store_id, period, total_score, coefficient, coefficient_reason, rank_in_store, status, confirmed_by, confirmed_at, created_at) FROM stdin;
\.


--
-- Data for Name: kpi_scores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kpi_scores (id, employee_id, store_id, period, dimension, raw_value, raw_description, normalized_score, weight, weighted_score, data_source, source_reference, calculated_at) FROM stdin;
\.


--
-- Data for Name: kpi_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kpi_templates (id, store_id, role, dimension, dimension_label, weight, formula_type, formula_config, data_source, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: leave_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.leave_balances (id, store_id, employee_id, year, leave_type, total_days, used_days, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_settings (id, store_id, setting_key, enabled, channel, target_roles, schedule_time, created_at, updated_at) FROM stdin;
1	1	daily_report	t	all	["boss", "store_manager"]	23:00	2026-06-15 16:02:21.030942+00	2026-06-15 16:02:21.030942+00
2	1	attendance_alert	t	all	["boss", "store_manager"]	\N	2026-06-15 16:02:21.030942+00	2026-06-15 16:02:21.030942+00
3	1	shift_change	t	all	["staff"]	\N	2026-06-15 16:02:21.030942+00	2026-06-15 16:02:21.030942+00
4	1	approval	t	all	["boss", "store_manager", "staff"]	\N	2026-06-15 16:02:21.030942+00	2026-06-15 16:02:21.030942+00
5	1	reminder	f	all	["staff"]	\N	2026-06-15 16:02:21.030942+00	2026-06-15 16:02:21.030942+00
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, store_id, user_id, type, title, content, channel, is_read, extra, created_at, updated_at) FROM stdin;
1	1	2	daily_report	考勤日报 2026-06-16	应到 1 人，实到 1 人\n\n迟到 (0):\n无\n\n旷工 (0):\n无\n\n请假 (0):\n无	all	f	null	2026-06-17 01:30:00.005996+00	2026-06-17 01:30:00.005996+00
2	1	1	daily_report	考勤日报 2026-06-16	应到 1 人，实到 1 人\n\n迟到 (0):\n无\n\n旷工 (0):\n无\n\n请假 (0):\n无	all	f	null	2026-06-17 01:30:00.005996+00	2026-06-17 01:30:00.005996+00
3	1	3	daily_report	考勤日报 2026-06-16	应到 1 人，实到 1 人\n\n迟到 (0):\n无\n\n旷工 (0):\n无\n\n请假 (0):\n无	all	f	null	2026-06-17 01:30:00.005996+00	2026-06-17 01:30:00.005996+00
4	1	2	daily_report	考勤日报 2026-06-17	应到 8 人，实到 7 人\n\n迟到 (1):\n- 孙宇 迟到 9 分钟\n\n旷工 (0):\n无\n\n请假 (0):\n无	all	f	null	2026-06-18 01:30:00.002516+00	2026-06-18 01:30:00.002516+00
5	1	1	daily_report	考勤日报 2026-06-17	应到 8 人，实到 7 人\n\n迟到 (1):\n- 孙宇 迟到 9 分钟\n\n旷工 (0):\n无\n\n请假 (0):\n无	all	f	null	2026-06-18 01:30:00.002516+00	2026-06-18 01:30:00.002516+00
6	1	3	daily_report	考勤日报 2026-06-17	应到 8 人，实到 7 人\n\n迟到 (1):\n- 孙宇 迟到 9 分钟\n\n旷工 (0):\n无\n\n请假 (0):\n无	all	f	null	2026-06-18 01:30:00.002516+00	2026-06-18 01:30:00.002516+00
7	1	2	daily_report	考勤日报 2026-06-18	应到 11 人，实到 10 人\n\n迟到 (1):\n- 孙宇 迟到 5 分钟\n\n旷工 (0):\n无\n\n请假 (0):\n无	all	f	null	2026-06-19 01:30:00.003078+00	2026-06-19 01:30:00.003078+00
8	1	1	daily_report	考勤日报 2026-06-18	应到 11 人，实到 10 人\n\n迟到 (1):\n- 孙宇 迟到 5 分钟\n\n旷工 (0):\n无\n\n请假 (0):\n无	all	f	null	2026-06-19 01:30:00.003078+00	2026-06-19 01:30:00.003078+00
9	1	3	daily_report	考勤日报 2026-06-18	应到 11 人，实到 10 人\n\n迟到 (1):\n- 孙宇 迟到 5 分钟\n\n旷工 (0):\n无\n\n请假 (0):\n无	all	f	null	2026-06-19 01:30:00.003078+00	2026-06-19 01:30:00.003078+00
10	1	2	daily_report	考勤日报 2026-06-19	应到 12 人，实到 12 人\n\n迟到 (0):\n无\n\n旷工 (0):\n无\n\n请假 (0):\n无	all	f	null	2026-06-20 01:30:00.003242+00	2026-06-20 01:30:00.003242+00
11	1	1	daily_report	考勤日报 2026-06-19	应到 12 人，实到 12 人\n\n迟到 (0):\n无\n\n旷工 (0):\n无\n\n请假 (0):\n无	all	f	null	2026-06-20 01:30:00.003242+00	2026-06-20 01:30:00.003242+00
12	1	3	daily_report	考勤日报 2026-06-19	应到 12 人，实到 12 人\n\n迟到 (0):\n无\n\n旷工 (0):\n无\n\n请假 (0):\n无	all	f	null	2026-06-20 01:30:00.003242+00	2026-06-20 01:30:00.003242+00
\.


--
-- Data for Name: payroll_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_records (id, employee_id, store_id, period, base_salary, kpi_coefficient, commission_bottle, commission_card, commission_total, deduction_late, deduction_absent, deduction_other, deduction_total, net_pay, status, generated_at, finalized_at, paid_at, notes) FROM stdin;
\.


--
-- Data for Name: penalty_notices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.penalty_notices (id, store_id, employee_id, penalty_type, amount, reason, issued_by, issued_at, status, extra, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: salary_matrix; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salary_matrix (id, "position", grade, monthly_salary, base_salary, meal_allowance, is_active) FROM stdin;
\.


--
-- Data for Name: schedule_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schedule_rules (id, store_id, rule_type, rule_config, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: schedule_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schedule_snapshots (id, store_id, period, snapshot_data, version, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schedules (id, store_id, employee_id, date, shift_type, note, created_by, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shift_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shift_configs (id, store_id, shift_code, shift_name, start_time, end_time, is_overnight, color, sort_order, is_active, created_at, updated_at) FROM stdin;
2	1	day	白班	12:00	20:00	f	#FB0079	1	t	2026-06-15 16:02:21.030942+00	2026-06-15 16:02:21.030942+00
3	1	night	晚班	19:00	03:00	t	#333333	2	t	2026-06-15 16:02:21.030942+00	2026-06-15 16:02:21.030942+00
\.


--
-- Data for Name: shift_swap_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shift_swap_requests (id, store_id, requester_id, swap_with_id, swap_date, swap_shift, reason, status, swap_with_confirmed_at, approved_by, approved_at, reject_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sign_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sign_tasks (id, store_id, employee_id, type, title, ref_type, ref_id, status, signed_at, signature_data, dispute_reason, disputed_at, issued_by, issued_at, notes, extra, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: store_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.store_settings (id, store_id, rest_days_per_month, rest_allowed_weekdays, rest_forbidden_weekdays, max_same_position_off, manager_order_constraint, holiday_policy, auto_schedule_enabled, schedule_lock_after_publish, payroll_day_of_month, kpi_coefficient_min, kpi_coefficient_max, ai_api_url, ai_api_key, ai_model, ai_temperature, created_at, updated_at, contract_initiator_ids, contract_company_name, contract_company_phone, contract_company_address, contract_base_salary, contract_probation_months, contract_notice_days, contract_duration_years, wecom_webhook_url, wecom_bot_enabled, printer_enabled, printer_brand, printer_api_url, printer_sn, printer_user, printer_ukey, printer_label_width, printer_label_height) FROM stdin;
3	1	4	\N	\N	1	t	comp_leave	f	t	5	0.6	1.5	https://api.deepseek.com/v1/chat/completions	sk-b61999af66cd4c4aba6ecbf82b3e19ff	deepseek-chat	0.7	2026-06-13 17:24:10.917489+00	2026-06-13 17:24:10.917489+00	\N	\N	\N	\N	3000	6	45	3	https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=781d905e-c45e-4e46-940e-0e5f8d22346c	f	f	\N	\N	\N	\N	\N	80	50
\.


--
-- Data for Name: stores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stores (id, company_id, name, store_code, address, city, status, franchisee_user_id, daily_booking_limit, wework_corp_id, wework_agent_id, wework_secret, wework_token, wework_aes_key, wework_status, created_at, updated_at, wework_department_id) FROM stdin;
1	1	北京三里屯店	BJ-SLT-001	北京市朝阳区工人体育场北路4号80号楼一层113室	北京	active	\N	\N	ww792f86455cb6ea81	1000003	gAAAAABqL7A7iffpMMxkI1waAds5GxAGWzw2Px7efixP1fwrYgeESv4uu3zSb_5pvAH00liRPIWdyIy3H0PkS21oiXQ_8J7ilarTM2O2IeEZqZ1tBjp6gsWS-ZgyWzjXIv3P7MWXW3wG	\N	\N	\N	2026-06-13 12:27:10.556917+00	2026-06-15 07:56:43.069026+00	3
\.


--
-- Data for Name: table_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.table_sessions (id, store_id, table_no, opened_by, opened_at, closed_by, closed_at, guest_count, crmeb_order_count, crmeb_total_amount, wework_pay_count, wework_pay_amount, commission_employee_id, commission_base, commission_amount, is_anomaly, anomaly_reason, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tables; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tables (id, store_id, area, table_no, capacity, status, created_at, updated_at) FROM stdin;
376	1	大桌	11	8	active	2026-06-20 17:04:17.104683+00	2026-06-20 17:04:17.104683+00
377	1	大桌	12	8	active	2026-06-20 17:04:21.23498+00	2026-06-20 17:04:21.23498+00
378	1	大桌	13	8	active	2026-06-20 17:04:24.543753+00	2026-06-20 17:04:24.543753+00
379	1	大桌	14	8	active	2026-06-20 17:04:32.153666+00	2026-06-20 17:04:32.153666+00
361	1	包间	1	12	active	2026-06-20 16:29:57.526302+00	2026-06-20 16:29:57.526302+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, employee_id, username, password_hash, role, region, is_active, last_login, created_at, updated_at, must_change_password) FROM stdin;
3	12	王宁波	$2b$12$fMsXKq/rGmLGio5lHZvm3eaD5htbfoDYX.bXsmXqjYXU1RiViInIW	store_manager	\N	t	\N	2026-06-16 15:02:25.55888+00	2026-06-16 15:02:25.55888+00	f
4	13	赵疆轩	$2b$12$xOpteK0wm11d/EsHIIN31Of9ZWtVx13Bo1Yt.dgBy5l7PMAYVoc62	staff	\N	t	\N	2026-06-16 15:07:43.143119+00	2026-06-16 15:07:43.143119+00	f
2	7	周鹏飞	b2.4LSTCIhDiyvHidMEYjGMZm6K	boss	\N	t	\N	2026-06-15 16:00:57.977882+00	2026-06-15 16:00:57.977882+00	f
1	6	admin	$2b$12$SuE3sDr8PAPY/i.KqctIyuhP7LhmEd4zRosN/8uZVOF36Wv8zRVxq	boss	\N	t	\N	2026-06-13 12:27:10.556917+00	2026-06-15 19:01:15.323129+00	f
\.


--
-- Data for Name: wine_storage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wine_storage (id, store_id, customer_name, phone, wine_name, bottle_label, date_stored, remaining_ml, cabinet_no, status, retrieved_at, notes, created_at, updated_at, initial_ml, table_no, expiry_date, retrieved_by) FROM stdin;
8	1	李四	13809978888	芝华士12年	C001-4367	2026-06-21	562	3	stored	\N	\N	2026-06-20 16:09:39.641942+00	2026-06-20 16:09:39.641942+00	562	\N	2026-12-18 00:00:00	\N
7	1	周鹏飞	18600010997	喜力啤酒	C001-2212	2026-06-21	0	2	retrieved	2026-06-21T00:18:36.602071	\N	2026-06-20 16:07:02.019798+00	2026-06-20 16:18:36.596245+00	750	\N	2026-12-18 00:00:00	\N
6	1	周鹏飞	18600010997	百威啤酒	C001-5968	2026-06-20	0	1	retrieved	2026-06-21T00:18:40.391921	\N	2026-06-20 15:46:01.929513+00	2026-06-20 16:18:40.390039+00	750	\N	2026-12-17 00:00:00	\N
10	1	李四	13809978888	芝华士12年	C001-8271	2026-06-21	1	1	stored	\N	\N	2026-06-20 16:10:52.099084+00	2026-06-20 16:33:21.48217+00	562	A3	2026-12-18 00:00:00	\N
9	1	Lisi	13809978888	Beer	C001-4477	2026-06-21	375	4	stored	\N	\N	2026-06-20 16:09:46.050467+00	2026-06-20 16:34:29.847122+00	750	B2	2026-12-18 00:00:00	\N
11	1	王五	13900000001	麦卡伦12年	C001-6314	2026-06-21	175	4	stored	\N	\N	2026-06-20 16:35:00.529959+00	2026-06-20 16:37:11.522569+00	750	B1	2026-12-18 00:00:00	\N
\.


--
-- Name: approval_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.approval_requests_id_seq', 1, false);


--
-- Name: attendance_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attendance_records_id_seq', 360, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 2, true);


--
-- Name: bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bookings_id_seq', 248, true);


--
-- Name: closing_checklist_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.closing_checklist_items_id_seq', 1, false);


--
-- Name: closing_checklist_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.closing_checklist_templates_id_seq', 1, false);


--
-- Name: closing_item_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.closing_item_results_id_seq', 1, false);


--
-- Name: closing_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.closing_sessions_id_seq', 1, false);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.companies_id_seq', 1, true);


--
-- Name: contracts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contracts_id_seq', 1, false);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.employees_id_seq', 24, true);


--
-- Name: guest_ratings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.guest_ratings_id_seq', 99, true);


--
-- Name: kpi_appeals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kpi_appeals_id_seq', 1, false);


--
-- Name: kpi_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kpi_results_id_seq', 1, false);


--
-- Name: kpi_scores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kpi_scores_id_seq', 1, false);


--
-- Name: kpi_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kpi_templates_id_seq', 1, false);


--
-- Name: leave_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.leave_balances_id_seq', 1, false);


--
-- Name: notification_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_settings_id_seq', 5, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 12, true);


--
-- Name: payroll_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payroll_records_id_seq', 1, false);


--
-- Name: penalty_notices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.penalty_notices_id_seq', 1, false);


--
-- Name: salary_matrix_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.salary_matrix_id_seq', 220, true);


--
-- Name: schedule_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.schedule_rules_id_seq', 1, false);


--
-- Name: schedule_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.schedule_snapshots_id_seq', 1, false);


--
-- Name: schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.schedules_id_seq', 2, true);


--
-- Name: shift_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shift_configs_id_seq', 3, true);


--
-- Name: shift_swap_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shift_swap_requests_id_seq', 1, false);


--
-- Name: sign_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sign_tasks_id_seq', 1, false);


--
-- Name: store_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.store_settings_id_seq', 3, true);


--
-- Name: stores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stores_id_seq', 1, true);


--
-- Name: table_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.table_sessions_id_seq', 1, false);


--
-- Name: tables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tables_id_seq', 379, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: wine_storage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wine_storage_id_seq', 36, true);


--
-- Name: alembic_version alembic_version_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkey PRIMARY KEY (version_num);


--
-- Name: approval_requests approval_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_pkey PRIMARY KEY (id);


--
-- Name: attendance_records attendance_records_employee_id_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_employee_id_date_key UNIQUE (employee_id, date);


--
-- Name: attendance_records attendance_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: closing_checklist_items closing_checklist_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.closing_checklist_items
    ADD CONSTRAINT closing_checklist_items_pkey PRIMARY KEY (id);


--
-- Name: closing_checklist_templates closing_checklist_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.closing_checklist_templates
    ADD CONSTRAINT closing_checklist_templates_pkey PRIMARY KEY (id);


--
-- Name: closing_item_results closing_item_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.closing_item_results
    ADD CONSTRAINT closing_item_results_pkey PRIMARY KEY (id);


--
-- Name: closing_sessions closing_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.closing_sessions
    ADD CONSTRAINT closing_sessions_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: contracts contracts_contract_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_contract_no_key UNIQUE (contract_no);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (id);


--
-- Name: daily_revenue daily_revenue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_revenue
    ADD CONSTRAINT daily_revenue_pkey PRIMARY KEY (store_id, date);


--
-- Name: employees employees_employee_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_employee_code_key UNIQUE (employee_code);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: guest_ratings guest_ratings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guest_ratings
    ADD CONSTRAINT guest_ratings_pkey PRIMARY KEY (id);


--
-- Name: kpi_appeals kpi_appeals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_appeals
    ADD CONSTRAINT kpi_appeals_pkey PRIMARY KEY (id);


--
-- Name: kpi_results kpi_results_employee_id_period_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_results
    ADD CONSTRAINT kpi_results_employee_id_period_key UNIQUE (employee_id, period);


--
-- Name: kpi_results kpi_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_results
    ADD CONSTRAINT kpi_results_pkey PRIMARY KEY (id);


--
-- Name: kpi_scores kpi_scores_employee_id_period_dimension_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_scores
    ADD CONSTRAINT kpi_scores_employee_id_period_dimension_key UNIQUE (employee_id, period, dimension);


--
-- Name: kpi_scores kpi_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_scores
    ADD CONSTRAINT kpi_scores_pkey PRIMARY KEY (id);


--
-- Name: kpi_templates kpi_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_templates
    ADD CONSTRAINT kpi_templates_pkey PRIMARY KEY (id);


--
-- Name: leave_balances leave_balances_employee_id_year_leave_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_balances
    ADD CONSTRAINT leave_balances_employee_id_year_leave_type_key UNIQUE (employee_id, year, leave_type);


--
-- Name: leave_balances leave_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_balances
    ADD CONSTRAINT leave_balances_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_store_id_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_store_id_setting_key_key UNIQUE (store_id, setting_key);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: payroll_records payroll_records_employee_id_period_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_records
    ADD CONSTRAINT payroll_records_employee_id_period_key UNIQUE (employee_id, period);


--
-- Name: payroll_records payroll_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_records
    ADD CONSTRAINT payroll_records_pkey PRIMARY KEY (id);


--
-- Name: penalty_notices penalty_notices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalty_notices
    ADD CONSTRAINT penalty_notices_pkey PRIMARY KEY (id);


--
-- Name: salary_matrix salary_matrix_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_matrix
    ADD CONSTRAINT salary_matrix_pkey PRIMARY KEY (id);


--
-- Name: schedule_rules schedule_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedule_rules
    ADD CONSTRAINT schedule_rules_pkey PRIMARY KEY (id);


--
-- Name: schedule_snapshots schedule_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedule_snapshots
    ADD CONSTRAINT schedule_snapshots_pkey PRIMARY KEY (id);


--
-- Name: schedules schedules_employee_id_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_employee_id_date_key UNIQUE (employee_id, date);


--
-- Name: schedules schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_pkey PRIMARY KEY (id);


--
-- Name: shift_configs shift_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_configs
    ADD CONSTRAINT shift_configs_pkey PRIMARY KEY (id);


--
-- Name: shift_configs shift_configs_store_id_shift_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_configs
    ADD CONSTRAINT shift_configs_store_id_shift_code_key UNIQUE (store_id, shift_code);


--
-- Name: shift_swap_requests shift_swap_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_swap_requests
    ADD CONSTRAINT shift_swap_requests_pkey PRIMARY KEY (id);


--
-- Name: sign_tasks sign_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sign_tasks
    ADD CONSTRAINT sign_tasks_pkey PRIMARY KEY (id);


--
-- Name: store_settings store_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_settings
    ADD CONSTRAINT store_settings_pkey PRIMARY KEY (id);


--
-- Name: store_settings store_settings_store_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_settings
    ADD CONSTRAINT store_settings_store_id_key UNIQUE (store_id);


--
-- Name: stores stores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_pkey PRIMARY KEY (id);


--
-- Name: stores stores_store_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_store_code_key UNIQUE (store_code);


--
-- Name: table_sessions table_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_sessions
    ADD CONSTRAINT table_sessions_pkey PRIMARY KEY (id);


--
-- Name: tables tables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_pkey PRIMARY KEY (id);


--
-- Name: salary_matrix uq_salary_matrix_position_grade; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_matrix
    ADD CONSTRAINT uq_salary_matrix_position_grade UNIQUE ("position", grade);


--
-- Name: tables uq_store_table; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT uq_store_table UNIQUE (store_id, table_no);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: wine_storage wine_storage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wine_storage
    ADD CONSTRAINT wine_storage_pkey PRIMARY KEY (id);


--
-- Name: approval_requests approval_requests_approver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES public.users(id);


--
-- Name: approval_requests approval_requests_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: approval_requests approval_requests_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: attendance_records attendance_records_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: attendance_records attendance_records_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_records
    ADD CONSTRAINT attendance_records_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: bookings bookings_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.employees(id);


--
-- Name: bookings bookings_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: bookings bookings_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_table_id_fkey FOREIGN KEY (table_id) REFERENCES public.tables(id);


--
-- Name: closing_checklist_items closing_checklist_items_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.closing_checklist_items
    ADD CONSTRAINT closing_checklist_items_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.closing_checklist_templates(id) ON DELETE CASCADE;


--
-- Name: closing_checklist_templates closing_checklist_templates_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.closing_checklist_templates
    ADD CONSTRAINT closing_checklist_templates_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: closing_item_results closing_item_results_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.closing_item_results
    ADD CONSTRAINT closing_item_results_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.closing_checklist_items(id) ON DELETE SET NULL;


--
-- Name: closing_item_results closing_item_results_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.closing_item_results
    ADD CONSTRAINT closing_item_results_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.closing_sessions(id) ON DELETE CASCADE;


--
-- Name: closing_item_results closing_item_results_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.closing_item_results
    ADD CONSTRAINT closing_item_results_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.closing_checklist_templates(id) ON DELETE SET NULL;


--
-- Name: closing_sessions closing_sessions_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.closing_sessions
    ADD CONSTRAINT closing_sessions_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: contracts contracts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: contracts contracts_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: contracts contracts_signed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_signed_by_fkey FOREIGN KEY (signed_by) REFERENCES public.users(id);


--
-- Name: contracts contracts_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: daily_revenue daily_revenue_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_revenue
    ADD CONSTRAINT daily_revenue_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: employees employees_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: guest_ratings guest_ratings_response_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guest_ratings
    ADD CONSTRAINT guest_ratings_response_by_fkey FOREIGN KEY (response_by) REFERENCES public.users(id);


--
-- Name: guest_ratings guest_ratings_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.guest_ratings
    ADD CONSTRAINT guest_ratings_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: kpi_appeals kpi_appeals_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_appeals
    ADD CONSTRAINT kpi_appeals_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: kpi_appeals kpi_appeals_result_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_appeals
    ADD CONSTRAINT kpi_appeals_result_id_fkey FOREIGN KEY (result_id) REFERENCES public.kpi_results(id);


--
-- Name: kpi_appeals kpi_appeals_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_appeals
    ADD CONSTRAINT kpi_appeals_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: kpi_results kpi_results_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_results
    ADD CONSTRAINT kpi_results_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.users(id);


--
-- Name: kpi_results kpi_results_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_results
    ADD CONSTRAINT kpi_results_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: kpi_results kpi_results_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_results
    ADD CONSTRAINT kpi_results_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: kpi_scores kpi_scores_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_scores
    ADD CONSTRAINT kpi_scores_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: kpi_scores kpi_scores_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_scores
    ADD CONSTRAINT kpi_scores_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: kpi_templates kpi_templates_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_templates
    ADD CONSTRAINT kpi_templates_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: leave_balances leave_balances_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_balances
    ADD CONSTRAINT leave_balances_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: leave_balances leave_balances_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leave_balances
    ADD CONSTRAINT leave_balances_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: notification_settings notification_settings_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: notifications notifications_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payroll_records payroll_records_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_records
    ADD CONSTRAINT payroll_records_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: payroll_records payroll_records_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_records
    ADD CONSTRAINT payroll_records_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: penalty_notices penalty_notices_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalty_notices
    ADD CONSTRAINT penalty_notices_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: penalty_notices penalty_notices_issued_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalty_notices
    ADD CONSTRAINT penalty_notices_issued_by_fkey FOREIGN KEY (issued_by) REFERENCES public.employees(id);


--
-- Name: penalty_notices penalty_notices_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.penalty_notices
    ADD CONSTRAINT penalty_notices_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: schedule_rules schedule_rules_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedule_rules
    ADD CONSTRAINT schedule_rules_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: schedule_snapshots schedule_snapshots_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedule_snapshots
    ADD CONSTRAINT schedule_snapshots_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: schedule_snapshots schedule_snapshots_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedule_snapshots
    ADD CONSTRAINT schedule_snapshots_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: schedules schedules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: schedules schedules_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: schedules schedules_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schedules
    ADD CONSTRAINT schedules_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: shift_configs shift_configs_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_configs
    ADD CONSTRAINT shift_configs_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: shift_swap_requests shift_swap_requests_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_swap_requests
    ADD CONSTRAINT shift_swap_requests_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: shift_swap_requests shift_swap_requests_requester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_swap_requests
    ADD CONSTRAINT shift_swap_requests_requester_id_fkey FOREIGN KEY (requester_id) REFERENCES public.employees(id);


--
-- Name: shift_swap_requests shift_swap_requests_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_swap_requests
    ADD CONSTRAINT shift_swap_requests_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: shift_swap_requests shift_swap_requests_swap_with_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shift_swap_requests
    ADD CONSTRAINT shift_swap_requests_swap_with_id_fkey FOREIGN KEY (swap_with_id) REFERENCES public.employees(id);


--
-- Name: sign_tasks sign_tasks_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sign_tasks
    ADD CONSTRAINT sign_tasks_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: sign_tasks sign_tasks_issued_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sign_tasks
    ADD CONSTRAINT sign_tasks_issued_by_fkey FOREIGN KEY (issued_by) REFERENCES public.employees(id);


--
-- Name: sign_tasks sign_tasks_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sign_tasks
    ADD CONSTRAINT sign_tasks_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: store_settings store_settings_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_settings
    ADD CONSTRAINT store_settings_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id) ON DELETE CASCADE;


--
-- Name: stores stores_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: table_sessions table_sessions_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_sessions
    ADD CONSTRAINT table_sessions_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.employees(id);


--
-- Name: table_sessions table_sessions_commission_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_sessions
    ADD CONSTRAINT table_sessions_commission_employee_id_fkey FOREIGN KEY (commission_employee_id) REFERENCES public.employees(id);


--
-- Name: table_sessions table_sessions_opened_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_sessions
    ADD CONSTRAINT table_sessions_opened_by_fkey FOREIGN KEY (opened_by) REFERENCES public.employees(id);


--
-- Name: table_sessions table_sessions_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_sessions
    ADD CONSTRAINT table_sessions_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: tables tables_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: users users_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE SET NULL;


--
-- Name: wine_storage wine_storage_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wine_storage
    ADD CONSTRAINT wine_storage_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: approval_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approval_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: attendance_records; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.attendance_records ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: bookings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

--
-- Name: companies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;

--
-- Name: contracts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.contracts ENABLE ROW LEVEL SECURITY;

--
-- Name: daily_revenue; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.daily_revenue ENABLE ROW LEVEL SECURITY;

--
-- Name: employees; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;

--
-- Name: guest_ratings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.guest_ratings ENABLE ROW LEVEL SECURITY;

--
-- Name: kpi_appeals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kpi_appeals ENABLE ROW LEVEL SECURITY;

--
-- Name: kpi_results; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kpi_results ENABLE ROW LEVEL SECURITY;

--
-- Name: kpi_scores; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kpi_scores ENABLE ROW LEVEL SECURITY;

--
-- Name: kpi_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kpi_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: leave_balances; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.leave_balances ENABLE ROW LEVEL SECURITY;

--
-- Name: notification_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notification_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: payroll_records; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payroll_records ENABLE ROW LEVEL SECURITY;

--
-- Name: salary_matrix; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.salary_matrix ENABLE ROW LEVEL SECURITY;

--
-- Name: schedule_rules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.schedule_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: schedule_snapshots; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.schedule_snapshots ENABLE ROW LEVEL SECURITY;

--
-- Name: schedules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.schedules ENABLE ROW LEVEL SECURITY;

--
-- Name: shift_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.shift_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: shift_swap_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.shift_swap_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: approval_requests store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.approval_requests USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: attendance_records store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.attendance_records USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: audit_logs store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.audit_logs USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: bookings store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.bookings USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: companies store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.companies USING (true);


--
-- Name: contracts store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.contracts USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: daily_revenue store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.daily_revenue USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: employees store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.employees USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: guest_ratings store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.guest_ratings USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: kpi_results store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.kpi_results USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: kpi_scores store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.kpi_scores USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: kpi_templates store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.kpi_templates USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: leave_balances store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.leave_balances USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: notification_settings store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.notification_settings USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: notifications store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.notifications USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: payroll_records store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.payroll_records USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: schedule_rules store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.schedule_rules USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: schedule_snapshots store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.schedule_snapshots USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: schedules store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.schedules USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: shift_configs store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.shift_configs USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: shift_swap_requests store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.shift_swap_requests USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: store_settings store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.store_settings USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: table_sessions store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.table_sessions USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: tables store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.tables USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text)));


--
-- Name: users store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.users USING (true);


--
-- Name: wine_storage store_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY store_isolation ON public.wine_storage USING (((store_id = (current_setting('app.current_store_id'::text))::integer) OR (current_setting('app.role'::text) = 'boss'::text) OR (current_setting('app.current_store_id'::text) = '0'::text)));


--
-- Name: store_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.store_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: table_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.table_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: tables; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tables ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: wine_storage; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.wine_storage ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict yeEmb1fuvhl2HYJF3K6pRaqNNThCXwVuTuhMoei57gRZlZCPH16APNmeS1WFry1

