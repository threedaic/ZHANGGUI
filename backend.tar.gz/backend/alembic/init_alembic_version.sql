-- 初始化 alembic_version 表并标记当前版本
CREATE TABLE IF NOT EXISTS alembic_version (
    version_num VARCHAR(32) NOT NULL,
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);

-- 清除旧版本（如果有）
DELETE FROM alembic_version;

-- 标记当前版本为 crush_2_0_schema
INSERT INTO alembic_version (version_num) VALUES ('crush_2_0_schema');

SELECT * FROM alembic_version;
