-- ============================================================
-- Crush 2.0 RLS 全量启用脚本
-- 为所有含 store_id 的业务表启用行级安全策略
-- 变量: app.current_store_id (门店隔离) / app.current_user_role (admin 豁免)
-- ============================================================

-- 先确保 must_change_password 字段存在
ALTER TABLE sys_users ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN DEFAULT FALSE;

-- ============================================================
-- shared_* 表
-- ============================================================

-- shared_stores (无 store_id，不需要门店隔离策略，仅 admin 豁免)
ALTER TABLE shared_stores ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS admin_all_access ON shared_stores;
CREATE POLICY admin_all_access ON shared_stores
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- shared_employees
ALTER TABLE shared_employees ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON shared_employees;
CREATE POLICY store_isolation ON shared_employees
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON shared_employees;
CREATE POLICY admin_all_access ON shared_employees
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- shared_members
ALTER TABLE shared_members ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON shared_members;
CREATE POLICY store_isolation ON shared_members
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON shared_members;
CREATE POLICY admin_all_access ON shared_members
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- shared_member_levels
ALTER TABLE shared_member_levels ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS shared_member_levels_store_isolation ON shared_member_levels;
CREATE POLICY shared_member_levels_store_isolation ON shared_member_levels
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS shared_member_levels_admin_all_access ON shared_member_levels;
CREATE POLICY shared_member_levels_admin_all_access ON shared_member_levels
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- shared_categories
ALTER TABLE shared_categories ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS shared_categories_store_isolation ON shared_categories;
CREATE POLICY shared_categories_store_isolation ON shared_categories
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS shared_categories_admin_all_access ON shared_categories;
CREATE POLICY shared_categories_admin_all_access ON shared_categories
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- shared_products
ALTER TABLE shared_products ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON shared_products;
CREATE POLICY store_isolation ON shared_products
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON shared_products;
CREATE POLICY admin_all_access ON shared_products
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- shared_tables
ALTER TABLE shared_tables ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON shared_tables;
CREATE POLICY store_isolation ON shared_tables
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON shared_tables;
CREATE POLICY admin_all_access ON shared_tables
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- shared_store_settings
ALTER TABLE shared_store_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS shared_store_settings_admin_all_access ON shared_store_settings;
CREATE POLICY shared_store_settings_admin_all_access ON shared_store_settings
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- shared_devices
ALTER TABLE shared_devices ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS shared_devices_store_isolation ON shared_devices;
CREATE POLICY shared_devices_store_isolation ON shared_devices
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS shared_devices_admin_all_access ON shared_devices;
CREATE POLICY shared_devices_admin_all_access ON shared_devices
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- shared_franchisees
ALTER TABLE shared_franchisees ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON shared_franchisees;
CREATE POLICY store_isolation ON shared_franchisees
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON shared_franchisees;
CREATE POLICY admin_all_access ON shared_franchisees
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- ============================================================
-- sys_* 表
-- ============================================================

-- sys_users (全局表，仅 admin)
ALTER TABLE sys_users ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS sys_users_admin_all_access ON sys_users;
CREATE POLICY sys_users_admin_all_access ON sys_users
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- sys_configs
ALTER TABLE sys_configs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON sys_configs;
CREATE POLICY store_isolation ON sys_configs
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON sys_configs;
CREATE POLICY admin_all_access ON sys_configs
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- sys_audit_logs
ALTER TABLE sys_audit_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON sys_audit_logs;
CREATE POLICY store_isolation ON sys_audit_logs
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON sys_audit_logs;
CREATE POLICY admin_all_access ON sys_audit_logs
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- sys_notifications
ALTER TABLE sys_notifications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON sys_notifications;
CREATE POLICY store_isolation ON sys_notifications
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON sys_notifications;
CREATE POLICY admin_all_access ON sys_notifications
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- sys_notification_settings
ALTER TABLE sys_notification_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON sys_notification_settings;
CREATE POLICY store_isolation ON sys_notification_settings
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON sys_notification_settings;
CREATE POLICY admin_all_access ON sys_notification_settings
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- sys_printers
ALTER TABLE sys_printers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON sys_printers;
CREATE POLICY store_isolation ON sys_printers
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON sys_printers;
CREATE POLICY admin_all_access ON sys_printers
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- ============================================================
-- att_* 表 (考勤)
-- ============================================================

-- att_schedules
ALTER TABLE att_schedules ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON att_schedules;
CREATE POLICY store_isolation ON att_schedules
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON att_schedules;
CREATE POLICY admin_all_access ON att_schedules
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- att_schedule_rules
ALTER TABLE att_schedule_rules ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON att_schedule_rules;
CREATE POLICY store_isolation ON att_schedule_rules
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON att_schedule_rules;
CREATE POLICY admin_all_access ON att_schedule_rules
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- att_schedule_snapshots
ALTER TABLE att_schedule_snapshots ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON att_schedule_snapshots;
CREATE POLICY store_isolation ON att_schedule_snapshots
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON att_schedule_snapshots;
CREATE POLICY admin_all_access ON att_schedule_snapshots
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- att_records
ALTER TABLE att_records ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON att_records;
CREATE POLICY store_isolation ON att_records
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON att_records;
CREATE POLICY admin_all_access ON att_records
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- att_shift_configs
ALTER TABLE att_shift_configs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON att_shift_configs;
CREATE POLICY store_isolation ON att_shift_configs
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON att_shift_configs;
CREATE POLICY admin_all_access ON att_shift_configs
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- att_swap_requests
ALTER TABLE att_swap_requests ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON att_swap_requests;
CREATE POLICY store_isolation ON att_swap_requests
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON att_swap_requests;
CREATE POLICY admin_all_access ON att_swap_requests
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- att_approvals
ALTER TABLE att_approvals ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON att_approvals;
CREATE POLICY store_isolation ON att_approvals
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON att_approvals;
CREATE POLICY admin_all_access ON att_approvals
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- att_leave_balances
ALTER TABLE att_leave_balances ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON att_leave_balances;
CREATE POLICY store_isolation ON att_leave_balances
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON att_leave_balances;
CREATE POLICY admin_all_access ON att_leave_balances
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- ============================================================
-- hr_* 表 (人事/KPI)
-- ============================================================

-- hr_kpi_templates
ALTER TABLE hr_kpi_templates ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON hr_kpi_templates;
CREATE POLICY store_isolation ON hr_kpi_templates
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON hr_kpi_templates;
CREATE POLICY admin_all_access ON hr_kpi_templates
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- hr_kpi_scores
ALTER TABLE hr_kpi_scores ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON hr_kpi_scores;
CREATE POLICY store_isolation ON hr_kpi_scores
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON hr_kpi_scores;
CREATE POLICY admin_all_access ON hr_kpi_scores
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- hr_kpi_results
ALTER TABLE hr_kpi_results ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON hr_kpi_results;
CREATE POLICY store_isolation ON hr_kpi_results
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON hr_kpi_results;
CREATE POLICY admin_all_access ON hr_kpi_results
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- hr_kpi_appeals
ALTER TABLE hr_kpi_appeals ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON hr_kpi_appeals;
CREATE POLICY store_isolation ON hr_kpi_appeals
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON hr_kpi_appeals;
CREATE POLICY admin_all_access ON hr_kpi_appeals
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- hr_penalty_notices
ALTER TABLE hr_penalty_notices ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON hr_penalty_notices;
CREATE POLICY store_isolation ON hr_penalty_notices
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON hr_penalty_notices;
CREATE POLICY admin_all_access ON hr_penalty_notices
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- hr_performance
ALTER TABLE hr_performance ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON hr_performance;
CREATE POLICY store_isolation ON hr_performance
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON hr_performance;
CREATE POLICY admin_all_access ON hr_performance
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- hr_rankings
ALTER TABLE hr_rankings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON hr_rankings;
CREATE POLICY store_isolation ON hr_rankings
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON hr_rankings;
CREATE POLICY admin_all_access ON hr_rankings
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- hr_guest_ratings
ALTER TABLE hr_guest_ratings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON hr_guest_ratings;
CREATE POLICY store_isolation ON hr_guest_ratings
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON hr_guest_ratings;
CREATE POLICY admin_all_access ON hr_guest_ratings
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- ============================================================
-- pos_* 表 (收银)
-- ============================================================

-- pos_orders
ALTER TABLE pos_orders ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON pos_orders;
CREATE POLICY store_isolation ON pos_orders
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON pos_orders;
CREATE POLICY admin_all_access ON pos_orders
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- pos_order_items
ALTER TABLE pos_order_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON pos_order_items;
CREATE POLICY store_isolation ON pos_order_items
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON pos_order_items;
CREATE POLICY admin_all_access ON pos_order_items
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- pos_payments
ALTER TABLE pos_payments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON pos_payments;
CREATE POLICY store_isolation ON pos_payments
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON pos_payments;
CREATE POLICY admin_all_access ON pos_payments
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- pos_payment_methods
ALTER TABLE pos_payment_methods ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS pos_payment_methods_store_isolation ON pos_payment_methods;
CREATE POLICY pos_payment_methods_store_isolation ON pos_payment_methods
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS pos_payment_methods_admin_all_access ON pos_payment_methods;
CREATE POLICY pos_payment_methods_admin_all_access ON pos_payment_methods
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- pos_bookings
ALTER TABLE pos_bookings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON pos_bookings;
CREATE POLICY store_isolation ON pos_bookings
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS pos_bookings_admin_all_access ON pos_bookings;
CREATE POLICY pos_bookings_admin_all_access ON pos_bookings
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- pos_table_sessions
ALTER TABLE pos_table_sessions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS pos_table_sessions_store_isolation ON pos_table_sessions;
CREATE POLICY pos_table_sessions_store_isolation ON pos_table_sessions
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS pos_table_sessions_admin_all_access ON pos_table_sessions;
CREATE POLICY pos_table_sessions_admin_all_access ON pos_table_sessions
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- pos_order_logs
ALTER TABLE pos_order_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS pos_order_logs_store_isolation ON pos_order_logs;
CREATE POLICY pos_order_logs_store_isolation ON pos_order_logs
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS pos_order_logs_admin_all_access ON pos_order_logs;
CREATE POLICY pos_order_logs_admin_all_access ON pos_order_logs
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- pos_daily_reconciliations
ALTER TABLE pos_daily_reconciliations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS pos_daily_reconciliations_store_isolation ON pos_daily_reconciliations;
CREATE POLICY pos_daily_reconciliations_store_isolation ON pos_daily_reconciliations
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS pos_daily_reconciliations_admin_all_access ON pos_daily_reconciliations;
CREATE POLICY pos_daily_reconciliations_admin_all_access ON pos_daily_reconciliations
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- pos_refunds
ALTER TABLE pos_refunds ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON pos_refunds;
CREATE POLICY store_isolation ON pos_refunds
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON pos_refunds;
CREATE POLICY admin_all_access ON pos_refunds
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- pos_desk_notes
ALTER TABLE pos_desk_notes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON pos_desk_notes;
CREATE POLICY store_isolation ON pos_desk_notes
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON pos_desk_notes;
CREATE POLICY admin_all_access ON pos_desk_notes
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- pos_discount_approvals
ALTER TABLE pos_discount_approvals ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON pos_discount_approvals;
CREATE POLICY store_isolation ON pos_discount_approvals
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON pos_discount_approvals;
CREATE POLICY admin_all_access ON pos_discount_approvals
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- pos_member_transactions
ALTER TABLE pos_member_transactions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON pos_member_transactions;
CREATE POLICY store_isolation ON pos_member_transactions
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON pos_member_transactions;
CREATE POLICY admin_all_access ON pos_member_transactions
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- ============================================================
-- fin_* / wage_* / wine_* / game_* / butler_* / sig_* 表
-- ============================================================

-- fin_daily_revenue
ALTER TABLE fin_daily_revenue ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON fin_daily_revenue;
CREATE POLICY store_isolation ON fin_daily_revenue
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON fin_daily_revenue;
CREATE POLICY admin_all_access ON fin_daily_revenue
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- wage_contracts
ALTER TABLE wage_contracts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON wage_contracts;
CREATE POLICY store_isolation ON wage_contracts
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON wage_contracts;
CREATE POLICY admin_all_access ON wage_contracts
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- wage_salary_matrix
ALTER TABLE wage_salary_matrix ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON wage_salary_matrix;
CREATE POLICY store_isolation ON wage_salary_matrix
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON wage_salary_matrix;
CREATE POLICY admin_all_access ON wage_salary_matrix
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- wage_salary_rules
ALTER TABLE wage_salary_rules ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON wage_salary_rules;
CREATE POLICY store_isolation ON wage_salary_rules
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON wage_salary_rules;
CREATE POLICY admin_all_access ON wage_salary_rules
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- wage_periods
ALTER TABLE wage_periods ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON wage_periods;
CREATE POLICY store_isolation ON wage_periods
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON wage_periods;
CREATE POLICY admin_all_access ON wage_periods
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- wage_records
ALTER TABLE wage_records ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON wage_records;
CREATE POLICY store_isolation ON wage_records
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON wage_records;
CREATE POLICY admin_all_access ON wage_records
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- wage_record_items
ALTER TABLE wage_record_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON wage_record_items;
CREATE POLICY store_isolation ON wage_record_items
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON wage_record_items;
CREATE POLICY admin_all_access ON wage_record_items
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- wage_items_config
ALTER TABLE wage_items_config ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON wage_items_config;
CREATE POLICY store_isolation ON wage_items_config
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON wage_items_config;
CREATE POLICY admin_all_access ON wage_items_config
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- wage_wework_payments
ALTER TABLE wage_wework_payments ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON wage_wework_payments;
CREATE POLICY store_isolation ON wage_wework_payments
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON wage_wework_payments;
CREATE POLICY admin_all_access ON wage_wework_payments
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- wine_stored_bottles
ALTER TABLE wine_stored_bottles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON wine_stored_bottles;
CREATE POLICY store_isolation ON wine_stored_bottles
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON wine_stored_bottles;
CREATE POLICY admin_all_access ON wine_stored_bottles
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- wine_stocktakes
ALTER TABLE wine_stocktakes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON wine_stocktakes;
CREATE POLICY store_isolation ON wine_stocktakes
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON wine_stocktakes;
CREATE POLICY admin_all_access ON wine_stocktakes
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- wine_stocktake_items
ALTER TABLE wine_stocktake_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON wine_stocktake_items;
CREATE POLICY store_isolation ON wine_stocktake_items
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON wine_stocktake_items;
CREATE POLICY admin_all_access ON wine_stocktake_items
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- game_templates
ALTER TABLE game_templates ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON game_templates;
CREATE POLICY store_isolation ON game_templates
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON game_templates;
CREATE POLICY admin_all_access ON game_templates
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- game_sessions
ALTER TABLE game_sessions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON game_sessions;
CREATE POLICY store_isolation ON game_sessions
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON game_sessions;
CREATE POLICY admin_all_access ON game_sessions
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- game_participants
ALTER TABLE game_participants ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON game_participants;
CREATE POLICY store_isolation ON game_participants
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON game_participants;
CREATE POLICY admin_all_access ON game_participants
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- game_prizes
ALTER TABLE game_prizes ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON game_prizes;
CREATE POLICY store_isolation ON game_prizes
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON game_prizes;
CREATE POLICY admin_all_access ON game_prizes
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- butler_sessions
ALTER TABLE butler_sessions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON butler_sessions;
CREATE POLICY store_isolation ON butler_sessions
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON butler_sessions;
CREATE POLICY admin_all_access ON butler_sessions
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- butler_checklist_templates
ALTER TABLE butler_checklist_templates ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON butler_checklist_templates;
CREATE POLICY store_isolation ON butler_checklist_templates
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON butler_checklist_templates;
CREATE POLICY admin_all_access ON butler_checklist_templates
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- butler_checklist_items
ALTER TABLE butler_checklist_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON butler_checklist_items;
CREATE POLICY store_isolation ON butler_checklist_items
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON butler_checklist_items;
CREATE POLICY admin_all_access ON butler_checklist_items
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- butler_item_results
ALTER TABLE butler_item_results ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON butler_item_results;
CREATE POLICY store_isolation ON butler_item_results
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON butler_item_results;
CREATE POLICY admin_all_access ON butler_item_results
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- sig_tasks
ALTER TABLE sig_tasks ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS store_isolation ON sig_tasks;
CREATE POLICY store_isolation ON sig_tasks
    USING (store_id = current_setting('app.current_store_id', true)::uuid);
DROP POLICY IF EXISTS admin_all_access ON sig_tasks;
CREATE POLICY admin_all_access ON sig_tasks
    FOR ALL
    USING (current_setting('app.current_user_role', true) = 'admin')
    WITH CHECK (current_setting('app.current_user_role', true) = 'admin');

-- ============================================================
-- 验证
-- ============================================================
-- SELECT tablename, rowsecurity FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename;
-- SELECT count(*) as total_policies FROM pg_policies WHERE schemaname = 'public';
