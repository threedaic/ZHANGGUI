-- 统一推送模块迁移
-- 1. notification_settings 表新增 push_to_group 字段
-- 2. 为所有推送类型补全默认配置行

-- 1. 新增 push_to_group 字段
ALTER TABLE notification_settings ADD COLUMN IF NOT EXISTS push_to_group BOOLEAN DEFAULT FALSE;

-- 2. 为所有推送类型补全默认配置（对每个 store_id 插入缺失的 setting_key）
-- 使用 ON CONFLICT 避免重复插入

-- 插入所有标准推送类型的默认配置（仅对已存在的 store）
INSERT INTO notification_settings (store_id, setting_key, enabled, channel, push_to_group, target_roles, schedule_time, created_at, updated_at)
SELECT s.id, k.key, k.enabled, k.channel, k.push_to_group, k.roles, k.schedule_time, NOW(), NOW()
FROM stores s
CROSS JOIN (VALUES
    -- 考勤类
    ('daily_report',          TRUE,  'all', TRUE,  '["boss","store_manager"]'::jsonb, '23:00'),
    ('attendance_alert',      TRUE,  'all', TRUE,  '["boss","store_manager"]'::jsonb, NULL),
    ('shift_status',          TRUE,  'all', FALSE, '["boss","store_manager"]'::jsonb, NULL),
    ('shift_change',          TRUE,  'all', FALSE, '["staff"]'::jsonb,               NULL),
    -- 审批类
    ('approval',              TRUE,  'all', FALSE, '["boss","store_manager","staff"]'::jsonb, NULL),
    ('approval_pending',      TRUE,  'all', FALSE, '["boss","store_manager"]'::jsonb, NULL),
    ('approval_result',       TRUE,  'all', FALSE, '["staff"]'::jsonb,               NULL),
    -- 签收类
    ('sign_remind',           TRUE,  'all', FALSE, '["staff"]'::jsonb,               NULL),
    ('sign_dispute',          TRUE,  'all', FALSE, '["boss","store_manager"]'::jsonb, NULL),
    -- 处罚
    ('penalty_notice',        TRUE,  'all', FALSE, '["staff"]'::jsonb,               NULL),
    -- 开闭店检查单
    ('butler_opening_overdue', TRUE, 'all', TRUE,  '["boss","store_manager"]'::jsonb, '11:00'),
    ('butler_closing_overdue', TRUE, 'all', TRUE,  '["boss","store_manager"]'::jsonb, '23:00'),
    ('butler_manual_review',  TRUE,  'all', TRUE,  '["boss","store_manager"]'::jsonb, NULL),
    -- 告警类（原 wecom_notify.notify_alert 调用方）
    ('antifraud_alert',       TRUE,  'all', TRUE,  '["boss","store_manager"]'::jsonb, NULL),
    ('rating_alert',          TRUE,  'all', TRUE,  '["boss","store_manager"]'::jsonb, NULL),
    ('wine_stocktake_alert',  TRUE,  'all', TRUE,  '["boss","store_manager"]'::jsonb, NULL),
    ('system_error',          TRUE,  'all', TRUE,  '["boss"]'::jsonb,                 NULL),
    -- 上班提醒
    ('reminder',              FALSE, 'all', FALSE, '["staff"]'::jsonb,               NULL)
) AS k(key, enabled, channel, push_to_group, roles, schedule_time)
ON CONFLICT (store_id, setting_key) DO NOTHING;

-- 3. 为已存在的配置行补全 push_to_group 默认值（NULL -> FALSE）
UPDATE notification_settings SET push_to_group = FALSE WHERE push_to_group IS NULL;

-- 4. 为已存在的告警类配置设置 push_to_group = TRUE（迁移原有行为）
UPDATE notification_settings SET push_to_group = TRUE
WHERE setting_key IN ('daily_report', 'attendance_alert', 'butler_opening_overdue', 'butler_closing_overdue', 'butler_manual_review')
  AND push_to_group IS FALSE;
