-- 存酒流程优化迁移
-- 2026-06-17: 新增 initial_ml, table_no 字段
ALTER TABLE wine_storage ADD COLUMN IF NOT EXISTS initial_ml INTEGER DEFAULT 0;
ALTER TABLE wine_storage ADD COLUMN IF NOT EXISTS table_no VARCHAR(20);

-- 已有数据: initial_ml 设为当前 remaining_ml
UPDATE wine_storage SET initial_ml = remaining_ml WHERE initial_ml = 0 AND remaining_ml IS NOT NULL;

-- 云打印机配置字段 (store_settings 表)
ALTER TABLE store_settings ADD COLUMN IF NOT EXISTS printer_enabled BOOLEAN DEFAULT FALSE;
ALTER TABLE store_settings ADD COLUMN IF NOT EXISTS printer_brand VARCHAR(50);
ALTER TABLE store_settings ADD COLUMN IF NOT EXISTS printer_api_url TEXT;
ALTER TABLE store_settings ADD COLUMN IF NOT EXISTS printer_sn VARCHAR(100);
ALTER TABLE store_settings ADD COLUMN IF NOT EXISTS printer_user VARCHAR(100);
ALTER TABLE store_settings ADD COLUMN IF NOT EXISTS printer_ukey TEXT;
ALTER TABLE store_settings ADD COLUMN IF NOT EXISTS printer_label_width INTEGER DEFAULT 80;
ALTER TABLE store_settings ADD COLUMN IF NOT EXISTS printer_label_height INTEGER DEFAULT 50;
