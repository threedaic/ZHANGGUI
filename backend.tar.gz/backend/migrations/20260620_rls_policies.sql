-- PostgreSQL Row-Level Security 策略
-- 执行: docker exec -i crush-zhanggui-db psql -U crush -d crush_zhanggui < migrations/20260620_rls_policies.sql

-- ============ 1. 创建非超级用户应用账号 ============
-- 超级用户绕过 RLS，所以必须用非超级用户连接数据库
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'crush_app') THEN
        CREATE ROLE crush_app LOGIN PASSWORD 'crush_app_prod_change_me';
    END IF;
END
$$;
GRANT CONNECT ON DATABASE crush_zhanggui TO crush_app;
GRANT USAGE ON SCHEMA public TO crush_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO crush_app;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO crush_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO crush_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE ON SEQUENCES TO crush_app;

-- ============ 2. 启用 + 强制 RLS ============
-- ENABLE 开启 RLS，FORCE 让表主也不能绕过
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees FORCE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance_records FORCE ROW LEVEL SECURITY;
ALTER TABLE schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE schedule_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE schedule_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE shift_swap_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE shift_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE approval_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE approval_requests FORCE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE kpi_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE kpi_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE kpi_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE kpi_results FORCE ROW LEVEL SECURITY;
ALTER TABLE kpi_appeals ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll_records FORCE ROW LEVEL SECURITY;
ALTER TABLE salary_matrix ENABLE ROW LEVEL SECURITY;
ALTER TABLE contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_revenue ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_revenue FORCE ROW LEVEL SECURITY;
ALTER TABLE guest_ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE guest_ratings FORCE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings FORCE ROW LEVEL SECURITY;
ALTER TABLE tables ENABLE ROW LEVEL SECURITY;
ALTER TABLE tables FORCE ROW LEVEL SECURITY;
ALTER TABLE table_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE table_sessions FORCE ROW LEVEL SECURITY;
ALTER TABLE wine_storage ENABLE ROW LEVEL SECURITY;
ALTER TABLE wine_storage FORCE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE leave_balances ENABLE ROW LEVEL SECURITY;
ALTER TABLE leave_balances FORCE ROW LEVEL SECURITY;
ALTER TABLE store_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;

-- ============ 3. RLS 隔离策略 ============
-- 策略: 当前门店数据 = store_id 匹配 或 boss 角色全店可见
-- 对没有 store_id 的表(users, companies)，所有人可读

CREATE POLICY store_isolation ON employees
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON users
    FOR ALL USING (true);

CREATE POLICY store_isolation ON attendance_records
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON approvals
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON approval_requests
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON bookings
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON tables
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON table_sessions
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON daily_revenue
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON payroll_records
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON guest_ratings
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON kpi_results
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON wine_storage
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON leave_balances
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON contracts
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON kpi_templates
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON kpi_scores
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON kpi_appeals
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON salary_matrix
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON schedules
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON schedule_snapshots
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON schedule_rules
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON shift_swap_requests
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON shift_configs
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON notifications
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON notification_settings
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON audit_logs
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON store_settings
    FOR ALL USING (store_id = current_setting('app.current_store_id')::int
                    OR current_setting('app.role') = 'boss');

CREATE POLICY store_isolation ON companies
    FOR ALL USING (true);
